@echo off
setlocal
cd /d "%~dp0"
set PYTHONUTF8=1
where py >nul 2>nul
if errorlevel 1 (
  echo Python launcher not found. Install Python 3.11 x64 from python.org first.
  echo Then run this file again.
  pause
  exit /b 1
)
py -3.11 packaging\build_windows.py
set BUILD_RESULT=%ERRORLEVEL%
if not "%BUILD_RESULT%"=="0" (
  echo Build failed. See work\build-windows.log and the message above.
) else (
  echo Build succeeded. See the outputs folder.
)
pause
exit /b %BUILD_RESULT%
