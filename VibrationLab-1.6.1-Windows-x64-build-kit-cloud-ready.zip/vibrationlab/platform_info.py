"""Platform-specific user-facing wording."""
import platform


def multiselect_key():
    return 'Command' if platform.system()=='Darwin' else 'Ctrl'


def platform_description():
    system=platform.system()
    if system=='Windows': return f'Windows {platform.release()} · {platform.machine()}'
    if system=='Darwin': return f'macOS · {platform.machine()}'
    return f'{system} · {platform.machine()}'
