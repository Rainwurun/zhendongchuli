"""Acceptance checks runnable inside the packaged application."""
import json
import platform
import tempfile
from pathlib import Path
import numpy as np
from .core.analysis import fft_spectrum,welch_psd,band_rms_from_psd,convert_acceleration
from .core.data_import import load_txt
from .version import VERSION,DEVELOPER


def run_checks(window,output):
    checks={}
    from PySide6 import QtWidgets,QtTest,QtCore
    from .ui.native_menus import ParameterDialog
    window.show(); QtWidgets.QApplication.processEvents()
    checks['window_local_menu']=not window.menuBar().isNativeMenuBar()
    opened=[]
    for action in window.menuBar().actions():
        QtTest.QTest.mouseClick(window.menuBar(),QtCore.Qt.LeftButton,pos=window.menuBar().actionGeometry(action).center())
        QtWidgets.QApplication.processEvents()
        opened.append(action.menu().isVisible()); action.menu().hide()
    checks['all_six_menus_mouse_click']=len(opened)==6 and all(opened)
    target=next(menu for menu in window.menu_references if menu.title()=='主峰筛选')
    setting=next(action for action in target.actions() if action.text()=='设置参数…')
    dialogs=[]
    def dismiss():
        dialog=QtWidgets.QApplication.activeModalWidget()
        dialogs.append(isinstance(dialog,ParameterDialog))
        if dialog: dialog.reject()
    QtCore.QTimer.singleShot(50,dismiss); setting.trigger()
    checks['settings_dialog_opens_and_closes']=dialogs==[True]
    def safe_menu(menu):
        return all(not isinstance(a,QtWidgets.QWidgetAction) and (not a.menu() or safe_menu(a.menu())) for a in menu.actions())
    checks['native_menu_standard_actions_only']=all(safe_menu(a.menu()) for a in window.menuBar().actions() if a.menu())
    checks['all_36_parameter_controls_migrated']=len(window.legacy_parameter_actions)==36
    fs=2048; n=8192; t=np.arange(n)/fs
    x=9.80665*np.sin(2*np.pi*128*t)
    f,amplitude=fft_spectrum(x,fs)
    checks['fft_128hz']=bool(f[np.argmax(amplitude)]==128)
    checks['fft_amplitude']=bool(np.isclose(amplitude.max(),9.80665,rtol=.001))
    f,p=welch_psd(convert_acceleration(x,'m/s²','g'),fs,nperseg=2048)
    _,rms=band_rms_from_psd(f,p,100,160)
    checks['psd_band_rms']=bool(np.isclose(rms,1/np.sqrt(2),rtol=.001))
    rng=np.random.default_rng(42); noise=rng.normal(size=65536)
    f,p=welch_psd(noise,fs,nperseg=2048)
    _,rms_noise=band_rms_from_psd(f,p)
    checks['noise_psd_energy']=bool(np.isclose(rms_noise,np.std(noise),rtol=.04))
    with tempfile.TemporaryDirectory() as directory:
        file=Path(directory)/'signal.txt'
        lines=[]
        for i in range(n):
            ns=round(i*1e9/fs); seconds,frac=divmod(ns,1000000000)
            lines.append(f'2026-10-22,00:00:{seconds:02d}.{frac:09d},0,{x[i]},{2*x[i]}')
        file.write_text('\n'.join(lines),encoding='utf-8'); ds=load_txt(file)
        checks['txt_nanosecond_import']=ds.channels.shape==(n,2)
        checks['sampling_2048hz']=bool(np.isclose(ds.sampling.sample_rate_hz,fs,rtol=1e-5))
        window.datasets=[ds]; window.files.addItem('signal.txt'); window.files.setCurrentRow(0)
        window.unit.setCurrentText('g'); window.mode.setCurrentText('PSD'); window.channels.item(1).setSelected(True); window.multi_mode.setCurrentText('分图'); window.analyze()
        checks['gui_multichannel_spectrum']=len(window.current_result)==2
        window.rms_low.setValue(100); window.rms_high.setValue(160); window.calculate_band_rms()
        checks['gui_rms_table']=window.rms_table.rowCount()==2
        window.peak_minimum.setValue(.1); window.unit.setCurrentText('m/s²')
        checks['threshold_conversion']=bool(np.isclose(window.peak_minimum.value(),.980665))
        from .ui.export_dialog import ExportDialog
        source=str(ds.path.resolve())
        window.saved_selections=[dict(kind='time',name='阶段一',source=source,low=1,high=2),dict(kind='frequency',name='主频段',source='',low=100,high=160)]
        dialog=ExportDialog(ds.channel_names,window,saved_selections=window.saved_selections,source=source)
        dialog.apply_preset('工程记录')
        dialog.segments.cellWidget(0,5).setCurrentIndex(1); dialog.segments.cellWidget(0,6).setCurrentIndex(1)
        preview=window.preview_segment_rms(dialog)
        checks['saved_selection_rms_preview']=bool(np.isclose(preview[0][4],1/np.sqrt(2),rtol=.001))
        window.export_segmented_results(Path(directory)/'named-segments.csv',dialog,[0,1],['频段 RMS'])
        checks['saved_selection_export']=('阶段一 / 主频段' in (Path(directory)/'named-segments.csv').read_text(encoding='utf-8-sig'))
    report=dict(version=VERSION,developer=DEVELOPER,architecture=platform.machine(),checks=checks,passed=all(checks.values()),sine_band_rms_g=rms)
    Path(output).write_text(json.dumps(report,indent=2,ensure_ascii=False),encoding='utf-8')
    return 0 if report['passed'] else 1
