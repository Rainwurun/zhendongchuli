"""Reusable image layouts rendered by Qt for raster and vector outputs."""
import html
import json
import numpy as np
import pyqtgraph as pg
from PySide6 import QtCore,QtGui,QtWidgets,QtSvg

DEFAULT=dict(width=1600,height=1000,dpi=200,margin=30,title_size=20,axis_size=16,tick_size=13,legend_size=13,info_size=13,font='Arial',info_position='副标题',decimals=3,scientific=False,ticks=6,grid=True,shade=True,alpha=35,columns=1,layout='独立图片',show_info=True,show_peak=True,info_x=.03,info_y=.95)


class NumberAxis(pg.AxisItem):
    def __init__(self,orientation,style): super().__init__(orientation); self.number_style=style
    def tickStrings(self,values,scale,spacing):
        return [format(v*scale,f'.{self.number_style["decimals"]}{"e" if self.number_style["scientific"] else "f"}') for v in values]


def make_figure(jobs,style,dark=False,ranges=None):
    bg='#20242a' if dark else '#ffffff'; fg='#ffffff' if dark else '#20242a'
    view=pg.GraphicsLayoutWidget(); view.setBackground(bg); view.resize(style['width'],style['height'])
    view.ci.layout.setContentsMargins(*([style['margin']]*4)); view.ci.layout.setSpacing(20)
    view.info_items=[]; plots=[]
    columns=style['columns'] if style['layout']!='独立图片' else 1
    for i,job in enumerate(jobs):
        r,c=divmod(i,columns); base=r*3
        title=f"{('('+chr(97+i)+') ') if len(jobs)>1 else ''}{job['segment']} | {job['channel']} | {job['kind']} | {job['start']:g}–{job['end']:g} s"
        view.addLabel(html.escape(title),row=base,col=c,size=f"{style['title_size']}pt",color=fg)
        info=f"RMS = {job['rms']:.6g} {job['unit']} | {job['low']:g}–{job['high']:g} Hz"
        if style['show_info'] and style['info_position']=='副标题': view.addLabel(html.escape(info),row=base+1,col=c,size=f"{style['info_size']}pt",color=fg)
        plot=view.addPlot(row=base+2,col=c,axisItems={key:NumberAxis(key,style) for key in ('bottom','left')})
        plots.append((plot,None))
        plot.plot(job['x'],job['y'],pen=pg.mkPen('#1598b1',width=2),name=job['channel'])
        legend=plot.addLegend(labelTextSize=f"{style['legend_size']}pt",labelTextColor=fg)
        legend.anchor((1,1),(1,1),offset=(-8,-8))
        for curve in plot.listDataItems(): legend.addItem(curve,curve.name())
        plot.setLabel('bottom','时间' if job['kind']=='时域' else '频率',units='s' if job['kind']=='时域' else 'Hz',**{'font-size':f"{style['axis_size']}pt",'color':fg,'font-family':style['font']})
        plot.setLabel('left',job['kind'],units=job['label'],**{'font-size':f"{style['axis_size']}pt",'color':fg,'font-family':style['font']})
        group=ranges.get(job['kind'],[job]) if ranges else [job]
        xmin=min(float(j['x'][0]) for j in group); xmax=max(float(j['x'][-1]) for j in group)
        ymin=min(float(np.min(j['y'])) for j in group); ymax=max(float(np.max(j['y'])) for j in group)
        span=max(ymax-ymin,abs(ymax)*.05,1e-12); ymax+=span*.18; ymin-=span*.06
        plots[-1]=(plot,(xmin,xmax,ymin,ymax))
        plot.setXRange(xmin,xmax,padding=.02); plot.setYRange(ymin,ymax,padding=0)
        for name in ('bottom','left'):
            axis=plot.getAxis(name); axis.enableAutoSIPrefix(False); axis.setTextPen(fg); axis.setPen(fg)
            font=QtGui.QFont(style['font'],style['tick_size']); axis.setStyle(tickFont=font)
            spacing=((xmax-xmin) if name=='bottom' else (ymax-ymin))/style['ticks']
            if spacing>0: axis.setTickSpacing(spacing,spacing/2)
        plot.showGrid(x=style['grid'],y=style['grid'],alpha=.2)
        if style['shade'] and job['kind']!='时域':
            region=pg.LinearRegionItem((job['low'],job['high']),movable=False,brush=pg.mkBrush(60,150,230,style['alpha'])); region.setZValue(-5); plot.addItem(region)
        if style['show_info'] and style['info_position']!='副标题':
            text=pg.TextItem(info,color=fg,anchor=(0,0)); text.setFont(QtGui.QFont(style['font'],style['info_size']))
            text.setPos(xmin+(xmax-xmin)*style['info_x'],ymin+(ymax-ymin)*style['info_y']); text.setFlag(QtWidgets.QGraphicsItem.ItemIsMovable,True); plot.addItem(text)
            view.info_items.append((text,(xmin,xmax,ymin,ymax)))
        if style['show_peak'] and job['kind']!='时域':
            index=int(np.argmax(job['y'])); x=float(job['x'][index]); y=float(job['y'][index])
            plot.addItem(pg.ArrowItem(pos=(x,y),angle=-90,brush='#d85b35'))
            text=pg.TextItem(f'{x:.6g} Hz\n{y:.6g} {job["label"]}',color=fg,anchor=(.5,1)); text.setFont(QtGui.QFont(style['font'],style['info_size'])); text.setPos(x,y+span*.08); plot.addItem(text)
    view.setFont(QtGui.QFont(style['font'],style['tick_size']))
    view.setAttribute(QtCore.Qt.WA_DontShowOnScreen,True); view.show(); QtWidgets.QApplication.processEvents()
    view.ci.layout.activate(); QtWidgets.QApplication.processEvents()
    for plot,(xmin,xmax,ymin,ymax) in plots:
        plot.setXRange(xmin,xmax,padding=.02); plot.setYRange(ymin,ymax,padding=0); plot.getViewBox().updateMatrix()
        for key in ('bottom','left'): plot.getAxis(key).picture=None; plot.getAxis(key).update()
    QtWidgets.QApplication.processEvents()
    return view


def write_figure(view,path,style):
    extension=path.suffix.lower(); w,h=style['width'],style['height']
    if extension=='.png':
        device=QtGui.QImage(w,h,QtGui.QImage.Format_ARGB32); device.fill(QtCore.Qt.white)
    elif extension=='.svg':
        device=QtSvg.QSvgGenerator(); device.setFileName(str(path)); device.setSize(QtCore.QSize(w,h)); device.setViewBox(QtCore.QRect(0,0,w,h)); device.setResolution(view.logicalDpiX())
    else:
        device=QtGui.QPdfWriter(str(path)); device.setResolution(view.logicalDpiX()); device.setPageSize(QtGui.QPageSize(QtCore.QSizeF(w/style['dpi']*25.4,h/style['dpi']*25.4),QtGui.QPageSize.Millimeter)); device.setPageMargins(QtCore.QMarginsF(0,0,0,0))
    painter=QtGui.QPainter(device)
    if not painter.isActive(): raise ValueError('无法创建图片输出设备')
    if extension=='.pdf': painter.scale(device.width()/w,device.height()/h)
    view.render(painter,QtCore.QRectF(0,0,w,h),view.viewport().rect()); painter.end()
    if extension=='.png':
        device.setDotsPerMeterX(round(style['dpi']/0.0254)); device.setDotsPerMeterY(round(style['dpi']/0.0254))
    if extension=='.png' and not device.save(str(path)): raise ValueError('PNG 保存失败')


class ImageStyleDialog(QtWidgets.QDialog):
    def __init__(self,style,parent):
        super().__init__(parent); self.setWindowTitle('图片样式模板'); self.resize(520,700); self.controls={}
        outer=QtWidgets.QVBoxLayout(self); scroll=QtWidgets.QScrollArea(); scroll.setWidgetResizable(True); outer.addWidget(scroll); body=QtWidgets.QWidget(); scroll.setWidget(body); form=QtWidgets.QFormLayout(body)
        preset=QtWidgets.QComboBox(); preset.addItems(['选择尺寸预设','报告单栏','报告双栏','演示文稿']); form.addRow('尺寸预设',preset)
        labels={'width':'宽度 px','height':'高度 px','dpi':'PNG 分辨率 DPI','margin':'外边距 px','title_size':'标题字号 pt','axis_size':'坐标轴名称字号 pt','tick_size':'刻度字号 pt','legend_size':'图例字号 pt','info_size':'信息字号 pt','decimals':'小数位数','ticks':'主刻度约数','alpha':'阴影透明度 0–255','columns':'拼版列数'}
        for key,label in labels.items():
            spin=QtWidgets.QSpinBox(); spin.setRange(0,8000)
            if key in ('width','height'): spin.setRange(600,8000)
            elif key=='dpi': spin.setRange(72,600)
            elif key=='columns': spin.setRange(1,4)
            elif key=='decimals': spin.setRange(0,10)
            elif key=='alpha': spin.setRange(0,255)
            elif key in ('ticks',) or key.endswith('_size'): spin.setRange(2,72)
            spin.setValue(style[key]); form.addRow(label,spin); self.controls[key]=spin
        font=QtWidgets.QFontComboBox(); font.setCurrentFont(QtGui.QFont(style['font'])); form.addRow('字体',font); self.controls['font']=font
        for key,label,items in [('layout','通道排版',['独立图片','多通道拼版']),('info_position','RMS 信息位置',['副标题','图内可拖动信息框'])]:
            combo=QtWidgets.QComboBox(); combo.addItems(items); combo.setCurrentText(style[key]); self.controls[key]=combo; form.addRow(label,combo)
        for key,label in [('scientific','刻度科学计数法'),('grid','显示网格'),('shade','显示积分阴影'),('show_info','显示 RMS 信息'),('show_peak','显示引线峰值')]:
            box=QtWidgets.QCheckBox(label); box.setChecked(style[key]); form.addRow(box); self.controls[key]=box
        self.original=dict(style)
        def set_size(index):
            if index:
                w,h=[(1200,900),(1800,1200),(1920,1080)][index-1]; self.controls['width'].setValue(w); self.controls['height'].setValue(h)
        preset.currentIndexChanged.connect(set_size)
        saved=QtWidgets.QComboBox(); form.addRow('已保存模板',saved)
        settings=QtCore.QSettings('VibrationLab','VibrationLab')
        try: self.templates=json.loads(settings.value('image/templates','{}'))
        except (TypeError,ValueError): self.templates={}
        saved.addItems(self.templates)
        def store():
            name,ok=QtWidgets.QInputDialog.getText(self,'保存模板','模板名称：')
            if ok and name.strip():
                self.templates[name.strip()]=self.values(); settings.setValue('image/templates',json.dumps(self.templates)); saved.clear(); saved.addItems(self.templates)
        def load():
            value=self.templates.get(saved.currentText())
            if not value: return
            self.original=dict(DEFAULT,**value)
            for key,control in self.controls.items():
                if key not in value: continue
                if isinstance(control,QtWidgets.QFontComboBox): control.setCurrentFont(QtGui.QFont(value[key]))
                elif isinstance(control,QtWidgets.QComboBox): control.setCurrentText(value[key])
                elif isinstance(control,QtWidgets.QCheckBox): control.setChecked(value[key])
                else: control.setValue(value[key])
        for text,callback in [('保存为模板',store),('加载所选模板',load)]:
            button=QtWidgets.QPushButton(text); button.clicked.connect(callback); form.addRow(button)
        buttons=QtWidgets.QDialogButtonBox(QtWidgets.QDialogButtonBox.Ok|QtWidgets.QDialogButtonBox.Cancel); buttons.accepted.connect(self.accept); buttons.rejected.connect(self.reject); outer.addWidget(buttons)
    def values(self):
        result=dict(self.original)
        for key,control in self.controls.items():
            if isinstance(control,QtWidgets.QFontComboBox): result[key]=control.currentFont().family()
            elif isinstance(control,QtWidgets.QComboBox): result[key]=control.currentText()
            elif isinstance(control,QtWidgets.QCheckBox): result[key]=control.isChecked()
            else: result[key]=control.value()
        return result
