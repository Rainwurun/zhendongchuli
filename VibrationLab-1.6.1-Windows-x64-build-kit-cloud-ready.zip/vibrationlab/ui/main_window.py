from pathlib import Path
import json
import numpy as np
from PySide6 import QtWidgets, QtCore, QtGui
import pyqtgraph as pg
from pyqtgraph.exporters import ImageExporter
from vibrationlab.core.data_import import load_txt
from vibrationlab.core.analysis import apply_filter, band_rms_from_psd, convert_acceleration, convert_acceleration_psd, fft_spectrum, find_spectral_peaks, resample_uniform, time_statistics, welch_psd
from vibrationlab.core.export import export_series, export_time_domain, metadata_for
from vibrationlab.core.export_bundle import export_bundle,export_named_segments
from vibrationlab.core.export_table import prepare_table
from .export_dialog import ExportDialog
from .plot_interactions import PlotInteractions
from .native_menus import install_native_menus
from .selection_dialog import SelectionDialog
from .interaction_studio import InteractionStudio, validate_workspace
from vibrationlab.core.selection_library import validate_selections
from vibrationlab.version import VERSION, DEVELOPER, COPYRIGHT
from vibrationlab.platform_info import multiselect_key,platform_description

LIGHT_STYLE = "QWidget { background:#f6f7f9; color:#20242a; font-size:13px; } QLineEdit,QComboBox,QSpinBox,QDoubleSpinBox,QListWidget,QTextEdit { background:white; border:1px solid #c8cdd4; border-radius:4px; padding:4px; } QPushButton { background:#1769aa; color:white; border:0; border-radius:4px; padding:7px; } QPushButton:hover { background:#0d578f; } QToolBar { border:0; spacing:6px; } QToolButton { padding:6px; }"
DARK_STYLE = "QWidget { background:#20242a; color:#e6e9ed; font-size:13px; } QLineEdit,QComboBox,QSpinBox,QDoubleSpinBox,QListWidget,QTextEdit { background:#2b3038; border:1px solid #4b535f; border-radius:4px; padding:4px; } QPushButton { background:#2878b8; color:white; border:0; border-radius:4px; padding:7px; } QPushButton:hover { background:#3b91d1; } QToolBar { border:0; spacing:6px; } QToolButton { padding:6px; }"

class ImportWorker(QtCore.QThread):
    loaded=QtCore.Signal(object)
    failed=QtCore.Signal(str)
    def __init__(self,names,parent=None):
        super().__init__(parent); self.names=names
    def run(self):
        for name in self.names:
            try: self.loaded.emit(load_txt(name))
            except Exception as exc: self.failed.emit(f'{name}\n{exc}')

class AnalysisWorker(QtCore.QThread):
    ready=QtCore.Signal(object)
    failed=QtCore.Signal(str)
    def __init__(self,ds,indexes,options,parent=None):
        super().__init__(parent); self.ds=ds; self.indexes=indexes; self.options=options
    def run(self):
        try:
            o=self.options; t=self.ds.time_s
            if o['end'] and o['end']<=o['start']: raise ValueError('结束时间必须大于起始时间')
            mask=t>=o['start']
            if o['end']: mask &= t<=o['end']
            if mask.sum()<2: raise ValueError('选定时间区间少于两个采样点')
            output={}
            for idx in self.indexes:
                x=convert_acceleration(self.ds.channels[mask,idx],o['source'],'m/s²'); fs=o['fs']
                if o['resample']: x,fs=resample_uniform(x,fs,o['resample'])
                x=apply_filter(x,fs,o['filter'],o['low'],o['high'])
                if o['mode']=='时域': result=None
                elif o['mode']=='FFT': result=fft_spectrum(x,fs,o['window'])
                else: result=welch_psd(x,fs,o['window'],o['segment'],o['overlap'])
                output[idx]=(x,fs,result)
            self.ready.emit(output)
        except Exception as exc: self.failed.emit(str(exc))

class MainWindow(QtWidgets.QMainWindow):
    def __init__(self):
        super().__init__(); self.setWindowTitle(f"VibrationLab {VERSION} · rain"); self.resize(1420, 860)
        # Keep controls in the window and avoid Cocoa native-menu registration
        # while the legacy menus are being reorganized during startup.
        self.menuBar().setNativeMenuBar(False)
        self.datasets=[]; self.current=None; self.current_result=[]; self.multi_plots=[]
        self.settings=QtCore.QSettings('VibrationLab','VibrationLab')
        self.source_units={}; self.channel_styles={}; self.channel_line_styles={}
        self.interactions=PlotInteractions(self); self.selection_bounds=None; self.saved_selections=[]
        self.interaction_workspace=dict(notes=[],queue=[]); self.studio=None
        self._build_ui(); self.theme.setCurrentText(self.settings.value('theme','浅色')); self.apply_theme(self.theme.currentText())
        self.previous_unit=self.unit.currentText(); self.unit.currentTextChanged.connect(self.convert_peak_thresholds)
        self.organize_menus()
        install_native_menus(self)
        measurement=next(a.menu() for a in self.menuBar().actions() if a.text()=='测量')
        measurement.addAction('保存当前选区…',self.save_current_selection)
        measurement.addAction('已保存选区管理…',self.manage_selections)
        for toolbar in self.findChildren(QtWidgets.QToolBar):
            if toolbar.windowTitle()=='图表交互':
                toolbar.addWidget(self.plot_tool_status)
                toolbar.addAction('保存选区',self.save_current_selection)
                toolbar.addSeparator()
                action=toolbar.addAction('时频联动工作台',self.open_interaction_studio)
                action.setToolTip('多选区、时频联动、多段对比、工程标注和图表导出任务。')
                cursor=toolbar.addAction('双游标'); cursor.setCheckable(True)
                cursor.toggled.connect(self.cursor_enabled.setChecked); self.cursor_enabled.toggled.connect(cursor.setChecked)
                toolbar.addAction('复制读数',lambda:QtWidgets.QApplication.clipboard().setText(self.measurement.text()))
        measurement.addAction('时频联动工作台…',self.open_interaction_studio)
        self.analysis_state=QtWidgets.QLabel('等待导入数据'); self.statusBar().addPermanentWidget(self.analysis_state,1)

    def organize_menus(self):
        """Promote existing actions to conventional two-level menus."""
        self.main_bar.hide()
        groups={title:self.menuBar().addMenu(title) for title in ['文件','分析','测量','数据处理','视图','帮助']}
        self.menu_references=list(groups.values())
        categories={}
        def destination(title,section):
            key=(title,section)
            if key not in categories:
                categories[key]=groups[title].addMenu(section); self.menu_references.append(categories[key])
            return categories[key]
        for menu,title in [(self.data_menu,'文件'),(self.analysis_menu,'分析'),(self.processing_menu,'数据处理'),(self.display_menu,'视图')]:
            for action in list(menu.actions()):
                widget=action.defaultWidget() if isinstance(action,QtWidgets.QWidgetAction) else None
                text=' '.join(label.text() for label in widget.findChildren(QtWidgets.QLabel)) if widget else action.text()
                target,section=title,'参数设置'
                if title=='文件':
                    section='导入与导出' if '导入' in text or '导出' in text else '分析配置'
                    if '原始数据' in text: target,section='数据处理','采样与单位'
                elif title=='分析':
                    if '峰' in text: target,section='测量','主峰筛选'
                    elif '有效值' in text: target,section='测量','频段总有效值'
                    elif 'PSD' in text or '窗函数' in text or '谱密度' in text: section='频谱参数'
                    else: section='分析类型与区间'
                elif title=='数据处理': section='滤波' if '滤波' in text else '采样与单位'
                elif title=='视图':
                    section='曲线样式' if any(s in text for s in ['线宽','线型','数据点','配色','颜色','网格']) else '坐标与布局'
                    if '风格' in text: section='界面主题'
                menu.removeAction(action); destination(target,section).addAction(action)
        groups['文件'].addAction('导出数据…',self.export_configured)
        groups['测量'].addAction('计算频段总有效值',self.calculate_band_rms)
        for name,control in [('双游标',self.cursor_enabled),('游标吸附',self.cursor_snap)]: self.add_menu_field(destination('测量','游标测量'),name,control)
        for toolbar in self.findChildren(QtWidgets.QToolBar):
            if toolbar.windowTitle()!='图表交互': continue
            for action in list(toolbar.actions()):
                if isinstance(action,QtWidgets.QWidgetAction): toolbar.removeAction(action)
                elif action.text() in ['选区 FFT','选区 PSD','添加备注','坐标范围']:
                    toolbar.removeAction(action); destination('测量' if '选区' in action.text() or '备注' in action.text() else '视图','选区与标注' if '范围' not in action.text() else '坐标与布局').addAction(action)
            toolbar.insertAction(toolbar.actions()[0],toolbar.addAction('计算',self.analyze))
            toolbar.addAction('复位视图',self.reset_current_view)
        groups['帮助'].addAction('使用说明',self.show_help)
        groups['帮助'].addAction('关于 VibrationLab',lambda:QtWidgets.QMessageBox.about(self,'关于 VibrationLab',f'VibrationLab {VERSION}\n振动信号工程分析软件\n开发人员：{DEVELOPER}\n{COPYRIGHT}\n平台：{platform_description()}\n版本规则：主版本.功能版本.修订版本'))

    def show_help(self):
        from .help_dialog import HelpDialog
        if not hasattr(self,'help_dialog'): self.help_dialog=HelpDialog(self)
        self.help_dialog.show(); self.help_dialog.raise_()

    def open_interaction_studio(self):
        if not self.current:
            QtWidgets.QMessageBox.information(self,'图表交互工作台','请先导入数据并选择通道。'); return
        if self.studio is None: self.studio=InteractionStudio(self)
        self.studio.setStyleSheet(self.styleSheet()); self.studio.show(); self.studio.raise_(); self.studio.refresh()

    def convert_peak_thresholds(self,unit):
        old=self.previous_unit; self.previous_unit=unit
        for control in (self.peak_minimum,self.peak_prominence):
            value=control.value()
            if self.mode.currentText()=='PSD' and self.spectral_display.currentIndex()==1: converted=float(convert_acceleration_psd([value],old,unit)[0])
            else: converted=float(convert_acceleration([value],old,unit)[0])
            blocker=QtCore.QSignalBlocker(control); control.setValue(converted); del blocker
        self.analyze()

    def _build_ui(self):
        self.main_bar=self.addToolBar("功能")
        self.main_bar.setMovable(False)
        self.data_menu=self.add_menu_button("数据")
        self.analysis_menu=self.add_menu_button("分析")
        self.processing_menu=self.add_menu_button("采样与处理")
        self.display_menu=self.add_menu_button("显示")
        root=QtWidgets.QWidget(); layout=QtWidgets.QHBoxLayout(root); self.setCentralWidget(root)
        left=QtWidgets.QVBoxLayout(); layout.addLayout(left,1)
        left.addWidget(QtWidgets.QLabel("数据文件")); self.files=QtWidgets.QListWidget(); left.addWidget(self.files)
        left.addWidget(QtWidgets.QLabel(f"通道（{multiselect_key()} 多选 / Shift 连选）")); self.channels=QtWidgets.QListWidget(); self.channels.setSelectionMode(QtWidgets.QAbstractItemView.ExtendedSelection); left.addWidget(self.channels)
        chart=QtWidgets.QVBoxLayout(); layout.addLayout(chart,4)
        self.chart_stack=QtWidgets.QStackedWidget(); chart.addWidget(self.chart_stack)
        self.plot=pg.PlotWidget(); self.plot.showGrid(x=True,y=True,alpha=.25); self.configure_axis_units(self.plot); self.chart_stack.addWidget(self.plot)
        self.multi_scroll=QtWidgets.QScrollArea(); self.multi_scroll.setWidgetResizable(True)
        self.multi_host=QtWidgets.QWidget(); self.multi_layout=QtWidgets.QVBoxLayout(self.multi_host); self.multi_layout.setContentsMargins(0,0,0,0); self.multi_scroll.setWidget(self.multi_host); self.chart_stack.addWidget(self.multi_scroll)
        self.cursor_readout=QtWidgets.QLabel("游标：将鼠标移至图中读取坐标")
        self.cursor_readout.setToolTip("实时显示鼠标所在位置的横轴和纵轴数值。")
        chart.addWidget(self.cursor_readout)
        self.measurement=QtWidgets.QLabel('双游标与选区测量：等待数据'); self.measurement.setWordWrap(True); chart.addWidget(self.measurement)
        tools=self.addToolBar('图表交互'); tools.setMovable(False)
        self.plot_tool_group=QtGui.QActionGroup(self); self.plot_tool_group.setExclusive(True)
        self.plot_tool_status=QtWidgets.QLabel('当前：平移')
        for name,callback,tip in [('平移',lambda:self.set_plot_mouse_mode(False),'拖动图表进行平移。'),('框选放大',lambda:self.set_plot_mouse_mode(True),'在图中拖出矩形放大局部。'),('返回视图',self.interactions.previous_view,'返回上一步坐标范围。'),('拖动选区',self.interactions.select_band,'创建可拖动的区间：拖动中间移动，拖动边界改变范围。'),('选区 FFT',lambda:self.analyze_selection('FFT'),'用时域选区计算 FFT。'),('选区 PSD',lambda:self.analyze_selection('PSD'),'用时域选区计算 PSD。'),('坐标范围',self.set_axis_ranges,'精确输入当前图的横纵坐标范围。'),('添加备注',self.interactions.annotate,'在图表中心添加文字备注。')]:
            action=tools.addAction(name); action.triggered.connect(callback); action.setToolTip(tip)
            if name in ('平移','框选放大','拖动选区'):
                action.setCheckable(True); self.plot_tool_group.addAction(action)
                action.setChecked(name=='平移')
                action.triggered.connect(lambda checked=False,label=name:self.plot_tool_status.setText('当前：'+label))
        tools.addWidget(self.plot_tool_status)
        self.cursor_enabled=QtWidgets.QCheckBox('双游标'); tools.addWidget(self.cursor_enabled)
        self.cursor_enabled.toggled.connect(lambda enabled:self.interactions.add_cursors() if enabled else self.interactions.remove_cursors())
        self.cursor_snap=self.combo(['数据点','谱峰']); tools.addWidget(self.cursor_snap); self.cursor_snap.setToolTip('双游标吸附到最近的数据点或局部谱峰。')
        self.export_overlays=QtWidgets.QCheckBox('截图包含游标/标注'); self.export_overlays.setChecked(True); self.add_menu_field(self.display_menu,'截图叠加层',self.export_overlays)
        self.mode=self.combo(["时域","FFT","PSD"]); self.unit=self.combo(["m/s²","g","mm/s²"]); self.window=self.combo(["hann","boxcar"]); self.multi_mode=self.combo(["叠加","分图"]); self.axes_link=self.combo(["独立","统一横轴","统一横纵轴","统一纵轴"]); self.spectral_display=self.combo(["ASD（PSD 开根号）","PSD（功率谱密度）"])
        self.add_menu_field(self.analysis_menu,"分析类型",self.mode); self.add_menu_field(self.analysis_menu,"显示单位",self.unit); self.add_menu_field(self.analysis_menu,"窗函数",self.window); self.add_menu_field(self.analysis_menu,"谱密度显示",self.spectral_display); self.add_menu_field(self.display_menu,"多通道显示",self.multi_mode); self.add_menu_field(self.display_menu,"多视图尺度",self.axes_link)
        self.start_time=self.double_spin(0,1e12,0,6); self.end_time=self.double_spin(0,1e12,0,6); self.freq_max=self.double_spin(0,1e9,0,3)
        self.add_menu_field(self.analysis_menu,"起始时间 (s)",self.start_time); self.add_menu_field(self.analysis_menu,"结束时间 (s)",self.end_time); self.add_menu_field(self.display_menu,"最大频率 (Hz)",self.freq_max)
        self.freq_min=self.double_spin(0,1e9,0,3); self.add_menu_field(self.display_menu,'最小频率 (Hz)',self.freq_min)
        self.frequency_auto=self.combo(['自动范围','手动范围']); self.add_menu_field(self.display_menu,'频率范围模式',self.frequency_auto)
        self.source_unit=self.combo(['m/s²','g','mm/s²']); self.add_menu_field(self.data_menu,'原始数据单位',self.source_unit)
        self.line_width=self.double_spin(.5,6,1,1); self.line_style=self.combo(['实线','虚线','点线']); self.markers=self.combo(['无','圆点','方点']); self.palette=self.combo(['工程配色','鲜明配色','灰度']); self.grid=self.combo(['显示网格','隐藏网格'])
        for label,control in [('线宽',self.line_width),('线型',self.line_style),('数据点',self.markers),('曲线配色',self.palette),('网格',self.grid)]: self.add_menu_field(self.display_menu,label,control)
        custom=self.display_menu.addAction('设置当前通道颜色'); custom.triggered.connect(self.choose_channel_color)
        self.nperseg=self.int_spin(2,10_000_000,1024); self.overlap=self.int_spin(0,99,50); self.fs_override=self.double_spin(0,1e9,0,3,"自动"); self.resample_fs=self.double_spin(0,1e9,0,3,"不重采样")
        self.add_menu_field(self.analysis_menu,"PSD 分段",self.nperseg); self.add_menu_field(self.analysis_menu,"PSD 重叠 (%)",self.overlap); self.add_menu_field(self.processing_menu,"手动采样率",self.fs_override); self.add_menu_field(self.processing_menu,"重采样率",self.resample_fs)
        self.peak_distance=self.double_spin(0,1e9,0,3); self.peak_prominence=self.double_spin(0,1e99,0,6)
        self.add_menu_field(self.analysis_menu,"峰值最小间距 (Hz)",self.peak_distance); self.add_menu_field(self.analysis_menu,"峰值最小突出度",self.peak_prominence)
        self.peak_count=self.int_spin(1,10000,10); self.peak_minimum=self.double_spin(0,1e99,0,8)
        self.add_menu_field(self.analysis_menu,'最多显示峰值数（每通道）',self.peak_count); self.add_menu_field(self.analysis_menu,'最低峰值',self.peak_minimum)
        self.x_scale=self.combo(['线性','对数']); self.y_scale=self.combo(['线性','对数'])
        self.add_menu_field(self.display_menu,'频率轴尺度',self.x_scale); self.add_menu_field(self.display_menu,'幅值轴尺度',self.y_scale)
        self.data_menu.addAction('保存分析配置',self.save_configuration)
        self.data_menu.addAction('加载分析配置',self.load_configuration)
        self.rms_low=self.double_spin(0,1e9,0,3); self.rms_high=self.double_spin(0,1e9,0,3)
        self.add_menu_field(self.analysis_menu,"总有效值下限 (Hz)",self.rms_low); self.add_menu_field(self.analysis_menu,"总有效值上限 (Hz)",self.rms_high)
        self.filter_kind=self.combo(["none","lowpass","highpass","bandpass"]); self.filter_low=self.double_spin(0,1e9,0,3); self.filter_high=self.double_spin(0,1e9,0,3)
        self.add_menu_field(self.processing_menu,"滤波类型",self.filter_kind); self.add_menu_field(self.processing_menu,"滤波下限",self.filter_low); self.add_menu_field(self.processing_menu,"滤波上限",self.filter_high)
        self.run_btn=QtWidgets.QPushButton("计算 / 更新图表"); self.rms_btn=QtWidgets.QPushButton("计算区间总有效值"); self.export_btn=QtWidgets.QPushButton("导出当前 CSV"); self.export_all_btn=QtWidgets.QPushButton("导出全部通道 CSV"); self.main_bar.addWidget(self.run_btn); self.main_bar.addWidget(self.rms_btn); self.main_bar.addWidget(self.export_btn); self.main_bar.addWidget(self.export_all_btn)
        self.results=QtWidgets.QTableWidget(0,3); self.results.setHorizontalHeaderLabels(["通道","峰值频率 (Hz)","数值"]); self.results.horizontalHeader().setStretchLastSection(True)
        self.info=QtWidgets.QTextEdit(); self.info.setReadOnly(True)
        self.rms_summary=QtWidgets.QLabel("区间总有效值：等待 PSD 分析")
        self.rms_summary.setWordWrap(True)
        self.rms_table=QtWidgets.QTableWidget(0,4); self.rms_table.setHorizontalHeaderLabels(['通道','频段 (Hz)','均方值 (g²)','总有效值 RMS (g)']); self.rms_table.setMaximumHeight(130)
        result_panel=QtWidgets.QWidget(); result_layout=QtWidgets.QVBoxLayout(result_panel); result_layout.setContentsMargins(0,0,0,0); result_layout.addWidget(self.results); result_layout.addWidget(self.rms_summary)
        bottom=QtWidgets.QWidget(); bottom_layout=QtWidgets.QHBoxLayout(bottom); bottom_layout.setContentsMargins(3,3,3,3); bottom_layout.addWidget(self.info,2); bottom_layout.addWidget(result_panel,3)
        result_layout.addWidget(self.rms_table)
        dock=QtWidgets.QDockWidget("分析结果与处理记录",self); dock.setWidget(bottom); dock.setFeatures(QtWidgets.QDockWidget.NoDockWidgetFeatures); self.addDockWidget(QtCore.Qt.BottomDockWidgetArea,dock)
        action=self.data_menu.addAction("导入 TXT"); action.triggered.connect(self.import_files); image_action=self.data_menu.addAction("导出当前图表 PNG"); image_action.triggered.connect(self.export_image); reset=self.main_bar.addAction("复位视图"); reset.triggered.connect(self.reset_current_view); self.theme=self.combo(["浅色","深色"]); self.add_menu_field(self.display_menu,"界面风格",self.theme)
        action.setToolTip("导入逗号分隔的振动 TXT 文件；第四列起自动识别为加速度通道。")
        image_action.setToolTip("将当前显示的图表保存为 PNG 图片。分图模式保存第一个通道图表。")
        reset.setToolTip("恢复图表的自动坐标范围。")
        self.theme.setToolTip("切换浅色或深色界面，便于适应不同工作环境。")
        self.files.setToolTip("显示已导入数据文件；选择文件后可查看其通道和采样质量。")
        self.channels.setToolTip(f"选择要分析的通道。按住 {multiselect_key()} 键多选，Shift 连续选择。")
        self.plot.setToolTip("滚轮缩放；左键拖动平移；鼠标停留可读取当前坐标。")
        self.set_tips()
        self.plot.scene().sigMouseMoved.connect(self.update_cursor)
        self.files.currentRowChanged.connect(self.select_file); self.channels.itemSelectionChanged.connect(self.analyze)
        controls=(self.mode,self.unit,self.window,self.multi_mode,self.axes_link,self.spectral_display,self.start_time,self.end_time,self.freq_max,self.nperseg,self.overlap,self.peak_distance,self.peak_prominence,self.rms_low,self.rms_high,self.fs_override,self.resample_fs,self.filter_kind,self.filter_low,self.filter_high)
        for control in controls:
            (control.currentIndexChanged if isinstance(control,QtWidgets.QComboBox) else control.valueChanged).connect(self.analyze)
        self.theme.addItems(['深蓝','暖灰','高对比度'])
        for control in (self.freq_min,self.frequency_auto,self.line_width,self.line_style,self.markers,self.palette,self.grid,self.peak_count,self.peak_minimum,self.x_scale,self.y_scale):
            (control.currentIndexChanged if isinstance(control,QtWidgets.QComboBox) else control.valueChanged).connect(self.analyze)
        self.source_unit.currentTextChanged.connect(self.source_unit_changed)
        self.results.cellClicked.connect(self.locate_peak)
        self.peak_count.setToolTip('每个通道最多显示的合格局部峰值数量；按幅值由大到小排序。')
        self.peak_minimum.setToolTip('隐藏低于此数值的峰；单位与当前频谱纵轴一致。')
        self.x_scale.setToolTip('频谱频率轴可用对数尺度；零频率不在对数图中显示。')
        self.y_scale.setToolTip('对数纵轴仅显示正值；时域保留线性坐标。')
        for widget,text in [(self.freq_min,'频谱横轴下限，仅影响显示。'),(self.frequency_auto,'自动显示完整频率范围，或使用手动上下限。'),(self.source_unit,'当前文件中原始加速度数值的单位；更改后会重新计算。'),(self.line_width,'设置曲线线宽。'),(self.line_style,'设置曲线实线、虚线或点线。'),(self.markers,'显示或隐藏采样点标记。'),(self.palette,'选择多通道曲线的颜色方案。'),(self.grid,'显示或隐藏图表网格。')]: widget.setToolTip(text)
        self.theme.currentTextChanged.connect(self.apply_theme); self.run_btn.clicked.connect(self.analyze); self.rms_btn.clicked.connect(self.calculate_band_rms); self.export_btn.setText('导出设置'); self.export_btn.clicked.connect(self.export_configured); self.export_all_btn.hide()

    @staticmethod
    def combo(items):
        c=QtWidgets.QComboBox(); c.addItems(items); return c
    @staticmethod
    def double_spin(minimum,maximum,value,decimals,special=None):
        c=QtWidgets.QDoubleSpinBox(); c.setRange(minimum,maximum); c.setValue(value); c.setDecimals(decimals)
        if special: c.setSpecialValueText(special)
        return c
    @staticmethod
    def int_spin(minimum,maximum,value):
        c=QtWidgets.QSpinBox(); c.setRange(minimum,maximum); c.setValue(value); return c
    @staticmethod
    def add_field(layout,label,control): layout.addWidget(QtWidgets.QLabel(label)); layout.addWidget(control)

    def add_menu_button(self, name):
        menu=QtWidgets.QMenu(name, self)
        button=QtWidgets.QToolButton(); button.setText(name); button.setMenu(menu); button.setPopupMode(QtWidgets.QToolButton.InstantPopup)
        self.main_bar.addWidget(button)
        return menu

    @staticmethod
    def add_menu_field(menu, label, control):
        row=QtWidgets.QWidget(); layout=QtWidgets.QHBoxLayout(row); layout.setContentsMargins(8,4,8,4)
        caption=QtWidgets.QLabel(label + "："); layout.addWidget(caption); layout.addWidget(control)
        action=QtWidgets.QWidgetAction(menu); action.setDefaultWidget(row); menu.addAction(action)

    def set_tips(self):
        tips={
            self.mode:"选择时域曲线、单边幅值 FFT 或 Welch PSD 分析。",
            self.unit:"仅改变显示和导出单位；内部原始数据保持 m/s²。",
            self.multi_mode:"叠加会将已选通道绘制在同一坐标图；分图会为每个已选通道建立独立图表。",
            self.axes_link:"分图模式下控制坐标尺度。统一横纵轴可直接比较各通道的幅值大小。",
            self.spectral_display:"ASD 是 PSD 的平方根，单位为加速度/√Hz；PSD 单位为加速度²/Hz。",
            self.window:"FFT 与 PSD 使用的窗函数。Hann 窗适合降低谱泄漏；boxcar 为矩形窗。",
            self.start_time:"从导入文件起点开始计算的分析起始时间。0 表示文件起点。",
            self.end_time:"从导入文件起点开始计算的分析结束时间。0 表示文件末尾。",
            self.freq_max:"限制 FFT 或 PSD 图的显示横轴范围，不影响实际计算。",
            self.nperseg:"Welch PSD 每个分段的采样点数；更长分段有更高频率分辨率。",
            self.overlap:"相邻 Welch PSD 分段的重叠比例。",
            self.peak_distance:"相邻自动识别谱峰之间允许的最小频率距离；0 使用一个频率分辨率。",
            self.peak_prominence:"谱峰相对周边的最小突出程度；提高它可过滤较小的局部峰。",
            self.rms_low:"计算总有效值时使用的积分频率下限。0 表示 PSD 的起始频率。",
            self.rms_high:"计算总有效值时使用的积分频率上限。0 表示 PSD 的最高频率。",
            self.fs_override:"覆盖时间戳估算的采样频率，仅影响当前分析，不改原始时间戳。",
            self.resample_fs:"将当前分析区间重采样到指定频率；0 表示不进行重采样。",
            self.filter_kind:"选择不滤波、低通、高通或带通滤波。滤波只作用于当前分析信号。",
            self.filter_low:"高通或带通滤波的下截止频率。",
            self.filter_high:"低通或带通滤波的上截止频率。",
            self.run_btn:"按当前参数重新计算所有已选通道。",
            self.rms_btn:"对当前 PSD 曲线在设定频段积分，并输出每个通道的总有效值（g RMS）。",
            self.export_btn:"将当前选择的第一个通道分析结果及参数元数据导出为 CSV。",
            self.export_all_btn:"为当前已选的每个通道分别导出一个 CSV 文件，并在文件名附加通道名。",
            self.results:"列出满足数量、最低峰值、间距及突出度设置的局部谱峰。点击某行可在图中标记。",
        }
        for widget, tip in tips.items(): widget.setToolTip(tip)

    def value_unit(self):
        return self.spectral_unit(self.unit.currentText()) if self.mode.currentText()=='PSD' else self.unit.currentText()

    def update_cursor(self, position, plot=None):
        plot=plot or self.plot
        if not plot.sceneBoundingRect().contains(position): return
        point=plot.getPlotItem().vb.mapSceneToView(position)
        x,y=point.x(),point.y()
        if plot.getPlotItem().ctrl.logXCheck.isChecked(): x=10**x
        if plot.getPlotItem().ctrl.logYCheck.isChecked(): y=10**y
        self.cursor_readout.setText(f"游标：x = {x:.6g} {'s' if self.mode.currentText()=='时域' else 'Hz'}，y = {y:.6g} {self.value_unit()}")

    def apply_theme(self,name):
        dark=name in ('深色','深蓝','高对比度')
        background={'浅色':'#ffffff','深色':'#20242a','深蓝':'#102238','暖灰':'#ece7df','高对比度':'#000000'}.get(name,'#ffffff')
        style=DARK_STYLE if dark else LIGHT_STYLE
        if name=='深蓝': style=style.replace('#20242a','#102238').replace('#2b3038','#18334e')
        if name=='暖灰': style=style.replace('#f6f7f9','#ece7df')
        if name=='高对比度': style=style.replace('#20242a','#000000').replace('#e6e9ed','#ffffff')
        self.setStyleSheet(style); self.plot.setBackground(background)
        self.settings.setValue('theme',name)
        pen="#e6e9ed" if dark else "#20242a"
        self.plot.getPlotItem().getAxis("bottom").setTextPen(pen); self.plot.getPlotItem().getAxis("left").setTextPen(pen)
        for plot in self.multi_plots:
            plot.setBackground(background)
            for axis in ('bottom','left'): plot.getAxis(axis).setTextPen(pen)
        if self.studio is not None:
            self.studio.setStyleSheet(style)
            if self.studio.isVisible(): self.studio.render()

    def choose_channel_color(self):
        if not self.current or self.channels.currentRow()<0: return
        colour=QtWidgets.QColorDialog.getColor(parent=self)
        if colour.isValid():
            self.channel_styles[(str(self.current.path),self.channels.currentRow())]=colour.name(); self.analyze()

    def source_unit_changed(self,unit):
        if self.current: self.source_units[str(self.current.path)]=unit
        self.analyze()

    def reset_current_view(self):
        if self.chart_stack.currentIndex() == 0:
            self.plot.autoRange()
        else:
            for plot in self.multi_plots:
                plot.autoRange()

    def clear_multi_plots(self):
        self.multi_plots=[]
        while self.multi_layout.count():
            item=self.multi_layout.takeAt(0)
            if item.widget(): item.widget().deleteLater()

    def analysis_plots(self, count):
        self.interactions.reset()
        self.peak_annotations=[]
        separate=count > 1 and self.multi_mode.currentText() == "分图"
        self.clear_multi_plots()
        if not separate:
            self.chart_stack.setCurrentIndex(0); self.plot.clear(); self.configure_axis_units(self.plot)
            return [self.plot]
        self.chart_stack.setCurrentIndex(1)
        dark=self.theme.currentText() in ('深色','深蓝','高对比度')
        for _ in range(count):
            plot=pg.PlotWidget(); plot.showGrid(x=True,y=True,alpha=.25); plot.setBackground("#20242a" if dark else "#ffffff"); self.configure_axis_units(plot)
            pen="#e6e9ed" if dark else "#20242a"; plot.getPlotItem().getAxis("bottom").setTextPen(pen); plot.getPlotItem().getAxis("left").setTextPen(pen)
            plot.setMinimumHeight(210); plot.setToolTip("滚轮缩放；左键拖动平移。")
            plot.scene().sigMouseMoved.connect(lambda position,p=plot:self.update_cursor(position,p))
            self.multi_layout.addWidget(plot); self.multi_plots.append(plot)
        if self.axes_link.currentText() in ("统一横轴", "统一横纵轴"):
            for plot in self.multi_plots[1:]: plot.setXLink(self.multi_plots[0])
        if self.axes_link.currentText() in ("统一横纵轴","统一纵轴"):
            for plot in self.multi_plots[1:]: plot.setYLink(self.multi_plots[0])
        return self.multi_plots

    @staticmethod
    def configure_axis_units(plot):
        plot.getPlotItem().getAxis("bottom").enableAutoSIPrefix(False)
        plot.getPlotItem().getAxis("left").enableAutoSIPrefix(False)

    def import_files(self):
        names,_=QtWidgets.QFileDialog.getOpenFileNames(self,"导入设备 TXT 文件","","TXT 文件 (*.txt);;所有文件 (*)")
        if not names: return
        unit,ok=QtWidgets.QInputDialog.getItem(self,'确认原始数据单位','设备文件中加速度数值的单位：',['m/s²','g','mm/s²'],0,False)
        if not ok: return
        if hasattr(self,'import_worker') and self.import_worker.isRunning(): return
        for name in names: self.source_units[str(Path(name))]=unit
        self.import_worker=ImportWorker(names,self)
        self.import_worker.loaded.connect(self.accept_dataset)
        self.import_worker.failed.connect(lambda message: QtWidgets.QMessageBox.warning(self,'导入失败',message))
        self.import_worker.finished.connect(lambda:self.statusBar().showMessage('文件加载完成'))
        self.statusBar().showMessage('正在后台加载文件…'); self.import_worker.start()

    def accept_dataset(self,ds):
        self.datasets.append(ds); self.files.addItem(ds.path.name)
        if self.files.currentRow()<0: self.files.setCurrentRow(0)

    def closeEvent(self,event):
        if self.studio is not None and self.studio.worker is not None and self.studio.worker.isRunning():
            self.statusBar().showMessage('请等待交互工作台计算结束再关闭窗口'); event.ignore(); return
        if self.studio is not None:
            self.studio.timer.stop(); self.studio.close()
        if hasattr(self,'import_worker') and self.import_worker.isRunning():
            self.statusBar().showMessage('请等待文件加载结束再关闭窗口'); event.ignore(); return
        if hasattr(self,'analysis_worker') and self.analysis_worker.isRunning():
            self.statusBar().showMessage('请等待分析完成再关闭窗口'); event.ignore(); return
        super().closeEvent(event)

    def select_file(self,row):
        if not 0<=row<len(self.datasets): return
        self.current=self.datasets[row]
        self.source_unit.blockSignals(True); self.source_unit.setCurrentText(self.source_units.get(str(self.current.path),'m/s²')); self.source_unit.blockSignals(False)
        self.channels.clear(); self.channels.addItems(self.current.channel_names); self.channels.setCurrentRow(0); self.fs_override.setValue(0); self.analyze()
    def selected_indexes(self):
        rows=[self.channels.row(item) for item in self.channels.selectedItems()]
        return rows or ([self.channels.currentRow()] if self.channels.currentRow()>=0 else [])
    def analysis_slice(self,ds):
        t=ds.time_s; start,end=self.start_time.value(),self.end_time.value()
        if end and end<=start: raise ValueError("结束时间必须大于起始时间")
        mask=t>=start
        if end: mask &= t<=end
        if mask.sum()<2: raise ValueError("选定时间区间少于两个采样点")
        return t[mask],mask
    def processed_signal(self,ds,index,mask):
        fs=self.fs_override.value() or ds.sampling.sample_rate_hz; x=convert_acceleration(ds.channels[mask,index],self.source_units.get(str(ds.path),'m/s²'),'m/s²')
        if self.resample_fs.value(): x,fs=resample_uniform(x,fs,self.resample_fs.value())
        x=apply_filter(x,fs,self.filter_kind.currentText(),self.filter_low.value(),self.filter_high.value())
        return x,fs

    def analyze(self,*_):
        if not self.current or not self.selected_indexes(): return
        if self.studio is not None and self.studio.isVisible(): self.studio.refresh()
        if hasattr(self,'analysis_state'):
            self.analysis_state.setText('参数已更新 · 正在计算…')
        self.current_result=[]
        if hasattr(self,'analysis_worker') and self.analysis_worker.isRunning():
            self.analysis_pending=True; return
        if len(self.current.timestamps_ns)<100000:
            self._render_analysis(); return
        self.analysis_pending=False
        o=dict(start=self.start_time.value(),end=self.end_time.value(),source=self.source_unit.currentText(),fs=self.fs_override.value() or self.current.sampling.sample_rate_hz,resample=self.resample_fs.value(),filter=self.filter_kind.currentText(),low=self.filter_low.value(),high=self.filter_high.value(),mode=self.mode.currentText(),window=self.window.currentText(),segment=self.nperseg.value(),overlap=self.overlap.value())
        self.analysis_worker=AnalysisWorker(self.current,self.selected_indexes(),o,self)
        self.analysis_worker.ready.connect(self.analysis_ready)
        self.analysis_worker.failed.connect(lambda message:self.info.setPlainText('计算失败：'+message))
        self.analysis_worker.finished.connect(self.analysis_finished)
        self.statusBar().showMessage('正在后台分析…'); self.analysis_worker.start()

    def analysis_ready(self,cache):
        if self.analysis_pending: return
        self.analysis_cache=cache
        try: self._render_analysis()
        finally: self.analysis_cache=None

    def analysis_finished(self):
        self.statusBar().showMessage('分析完成')
        if self.analysis_pending: self.analyze()

    def _render_analysis(self):
        if not self.current or not self.selected_indexes(): return
        try:
            ds=self.current; indexes=self.selected_indexes(); unit=self.unit.currentText(); mode=self.mode.currentText(); t,mask=self.analysis_slice(ds); plots=self.analysis_plots(len(indexes)); self.current_result=[]
            colours=["#16a6a1","#4378bf","#bf6f3a","#9b5cb6","#b65a5a"]
            if self.palette.currentText()=='鲜明配色': colours=['#e63946','#247bff','#ff9800','#a34ee0','#19bb63']
            if self.palette.currentText()=='灰度': colours=['#777777','#999999','#555555','#aaaaaa']
            for n,idx in enumerate(indexes):
                cache=getattr(self,'analysis_cache',None)
                if cache: x_base,fs,_=cache[idx]
                else: x_base,fs=self.processed_signal(ds,idx,mask)
                name=ds.channel_names[idx]
                colour=self.channel_styles.get((str(ds.path),idx),colours[n%len(colours)])
                pen=pg.mkPen(colour,width=self.line_width.value(),style=[QtCore.Qt.SolidLine,QtCore.Qt.DashLine,QtCore.Qt.DotLine][self.line_style.currentIndex()])
                if (str(ds.path),idx) in self.channel_line_styles: pen.setStyle(self.channel_line_styles[(str(ds.path),idx)])
                plot=plots[n] if len(plots)>1 else plots[0]
                plot.setLogMode(x=mode!='时域' and self.x_scale.currentText()=='对数',y=mode!='时域' and self.y_scale.currentText()=='对数')
                if mode=="时域":
                    x=convert_acceleration(x_base,"m/s²",unit)
                    axis=np.linspace(t[0],t[-1],len(x)) if len(x)!=len(t) else t; plot.plot(axis,x,pen=pen,name=name); self.current_result.append((idx,"time",axis,x,fs,time_statistics(x)))
                elif mode=="FFT":
                    x=convert_acceleration(x_base,"m/s²",unit)
                    if cache:
                        axis,y=cache[idx][2]; y=convert_acceleration(y,'m/s²',unit)
                    else: axis,y=fft_spectrum(x,fs,self.window.currentText())
                    plot.plot(axis,y,pen=pen,name=name); self.current_result.append((idx,"series",axis,y,fs,None))
                else:
                    if cache: axis,y_base=cache[idx][2]
                    else: axis,y_base=welch_psd(x_base,fs,self.window.currentText(),self.nperseg.value(),self.overlap.value())
                    psd=convert_acceleration_psd(y_base,"m/s²",unit)
                    y=np.sqrt(np.maximum(psd, 0)) if self.spectral_display.currentIndex() == 0 else psd
                    plot.plot(axis,y,pen=pen,name=name); self.current_result.append((idx,"series",axis,y,fs,None))
                if mode=="时域": plot.setLabel("bottom","时间",units="s"); plot.setLabel("left",name,units=unit)
                elif mode=="FFT": plot.setLabel("bottom","频率",units="Hz"); plot.setLabel("left",name+" 幅值",units=unit)
                else: plot.setLabel("bottom","频率",units="Hz"); plot.setLabel("left",name+" "+self.spectral_name(),units=self.spectral_unit(unit))
                plot.showGrid(x=self.grid.currentIndex()==0,y=self.grid.currentIndex()==0,alpha=.25)
                for curve in plot.listDataItems(): curve.setSymbol([None,'o','s'][self.markers.currentIndex()]); curve.setSymbolSize(4)
                if mode!='时域' and self.frequency_auto.currentText()=='手动范围':
                    upper=self.freq_max.value() or fs/2
                    if self.freq_min.value()>=upper: raise ValueError('最小显示频率必须小于最大显示频率')
                    lower=self.freq_min.value()
                    if self.x_scale.currentText()=='对数':
                        positive=axis[axis>0]; lower=max(lower,float(positive[0])); lower,upper=np.log10(lower),np.log10(upper)
                    plot.setXRange(lower,upper,padding=0)
            first=self.current_result[0]; self.info.setPlainText(self.describe(ds,first,mode,unit))
            self.update_peak_table(ds, mode)
            self.draw_rms_band()
            self.interactions.attach(plots,self.current_result)
            self.peak_minimum.setSuffix(' '+self.value_unit()); self.peak_prominence.setSuffix(' '+self.value_unit())
            self.rms_table.setRowCount(0)
            self.rms_summary.setText("总有效值（RMS，单位 g）：设置积分频段并点击“计算区间总有效值”。")
            self.apply_pending_selection_focus()
            if hasattr(self,'analysis_state'):
                self.analysis_state.setText(f'已更新 | {ds.path.name} | 原始 {self.source_unit.currentText()} → {unit} | {self.mode.currentText()} | {first[4]:.6g} Hz | {t[0]:.4g}–{t[-1]:.4g} s | 滤波 {self.filter_kind.currentText()}')
        except Exception as exc:
            self.current_result=[]; self.plot.clear(); self.clear_multi_plots(); self.results.setRowCount(0); self.info.setPlainText(f"计算失败：{exc}")
            if hasattr(self,'analysis_state'): self.analysis_state.setText('分析失败：'+str(exc))

    def update_peak_table(self, ds, mode):
        self.results.setRowCount(0)
        self.results.setHorizontalHeaderLabels(['通道','峰值频率 (Hz)',f'峰值 ({self.value_unit()})'])
        self.peak_rows=[]
        if mode == "时域": return
        total=0
        for idx, _, frequency, values, _, _ in self.current_result:
            resolution = frequency[1] - frequency[0] if len(frequency) > 1 else 0
            distance = self.peak_distance.value() or resolution
            peaks=find_spectral_peaks(frequency, values, min_distance_hz=distance, prominence=self.peak_prominence.value(), limit=len(values),minimum_value=self.peak_minimum.value())
            total+=len(peaks)
            for hz, value in peaks[:self.peak_count.value()]:
                self.peak_rows.append((idx,hz,value))
                row=self.results.rowCount(); self.results.insertRow(row)
                for column, text in enumerate((ds.channel_names[idx], f"{hz:.6g}", f"{value:.6g}")):
                    item=QtWidgets.QTableWidgetItem(text); item.setToolTip("自动识别的局部谱峰。")
                    self.results.setItem(row,column,item)
        self.results.setToolTip(f'符合筛选条件共 {total} 个峰，当前显示 {self.results.rowCount()} 个。点击行可定位峰。')
        self.statusBar().showMessage(f'合格谱峰 {total} 个；显示 {self.results.rowCount()} 个')

    def calculate_band_rms(self):
        if not self.current_result or self.mode.currentText() != "PSD":
            QtWidgets.QMessageBox.information(self, "需要 PSD 结果", "请先选择 PSD 分析并计算曲线，再计算区间总有效值。")
            return
        try:
            lines=[]
            self.rms_table.setRowCount(0)
            for idx, _, frequency, values, _, _ in self.current_result:
                # Current curve is either ASD or raw PSD in the display unit.
                psd = values * values if self.spectral_display.currentIndex() == 0 else values
                area, rms_in_display_unit = band_rms_from_psd(frequency, psd, self.rms_low.value(), self.rms_high.value())
                rms_g = float(convert_acceleration([rms_in_display_unit], self.unit.currentText(), "g")[0])
                row=self.rms_table.rowCount(); self.rms_table.insertRow(row)
                band=f'{self.rms_low.value():.6g}–{self.rms_high.value() or frequency[-1]:.6g}'
                for column,text in enumerate((self.current.channel_names[idx],band,f'{rms_g*rms_g:.6g}',f'{rms_g:.6g}')):
                    self.rms_table.setItem(row,column,QtWidgets.QTableWidgetItem(text))
                lines.append(f"{self.current.channel_names[idx]} 总有效值（RMS）：{rms_g:.6g} g（均方值 {area:.6g} ({self.unit.currentText()})²）")
            low = self.rms_low.value() or self.current_result[0][2][0]
            high = self.rms_high.value() or self.current_result[0][2][-1]
            self.rms_summary.setText(f"区间总有效值 {low:.6g}–{high:.6g} Hz\n" + "\n".join(lines))
        except Exception as exc:
            QtWidgets.QMessageBox.warning(self, "总有效值计算失败", str(exc))

    def psd_unit_text(self):
        return {"g": "g²/Hz", "mm/s²": "mm²/s⁴/Hz", "m/s²": "m²/s⁴/Hz"}[self.unit.currentText()]

    def set_plot_mouse_mode(self,rectangle):
        for plot in dict.fromkeys(p for p,_ in self.interactions.entries):
            plot.getViewBox().setMouseMode(pg.ViewBox.RectMode if rectangle else pg.ViewBox.PanMode)

    def analyze_selection(self,mode):
        if self.mode.currentText()!='时域' or not self.selection_bounds:
            QtWidgets.QMessageBox.information(self,'选择时域区间','请在时域图点击“拖动选区”并调整区间。'); return
        low,high=self.selection_bounds
        blockers=[QtCore.QSignalBlocker(self.start_time),QtCore.QSignalBlocker(self.end_time),QtCore.QSignalBlocker(self.mode)]
        self.start_time.setValue(low); self.end_time.setValue(high); self.mode.setCurrentText(mode); del blockers
        self.selection_bounds=None; self.analyze()

    def set_axis_ranges(self):
        if not self.interactions.entries: return
        plot=self.interactions.entries[0][0]; ranges=plot.getViewBox().viewRange()
        dialog=QtWidgets.QDialog(self); dialog.setWindowTitle('精确坐标范围'); form=QtWidgets.QFormLayout(dialog); controls=[]
        for axis,label in [(0,'横轴'),(1,'纵轴')]:
            for boundary,name in [(0,'最小值'),(1,'最大值')]:
                spin=self.double_spin(-1e100,1e100,self.interactions.coordinate(plot,ranges[axis][boundary],axis,inverse=True),8)
                form.addRow(label+name+(' ('+('s' if self.mode.currentText()=='时域' else 'Hz')+')' if axis==0 else ' ('+self.value_unit()+')'),spin); controls.append(spin)
        buttons=QtWidgets.QDialogButtonBox(QtWidgets.QDialogButtonBox.Ok|QtWidgets.QDialogButtonBox.Cancel); buttons.accepted.connect(dialog.accept); buttons.rejected.connect(dialog.reject); form.addRow(buttons)
        if dialog.exec()!=QtWidgets.QDialog.Accepted: return
        values=[c.value() for c in controls]
        if values[0]>=values[1] or values[2]>=values[3]:
            QtWidgets.QMessageBox.warning(self,'无效范围','各坐标最小值必须小于最大值。'); return
        for axis,check in [(0,plot.getPlotItem().ctrl.logXCheck),(1,plot.getPlotItem().ctrl.logYCheck)]:
            if check.isChecked() and values[axis*2]<=0:
                QtWidgets.QMessageBox.warning(self,'无效范围','对数坐标范围必须为正数。'); return
        plot.setRange(xRange=[self.interactions.coordinate(plot,v,0) for v in values[:2]],yRange=[self.interactions.coordinate(plot,v,1) for v in values[2:]],padding=0)
        self.interactions.record_view()

    def draw_rms_band(self):
        if self.mode.currentText()!='PSD' or not self.current_result: return
        frequency=self.current_result[0][2]
        low=self.rms_low.value(); high=self.rms_high.value() or frequency[-1]
        if low>=high or high>frequency[-1]: return
        if self.x_scale.currentText()=='对数':
            low=max(low,float(frequency[frequency>0][0])); low,high=np.log10(low),np.log10(high)
        plots=self.multi_plots if self.chart_stack.currentIndex()==1 else [self.plot]
        for plot in plots:
            region=pg.LinearRegionItem((low,high),movable=False,brush=pg.mkBrush(50,150,230,35))
            region.setZValue(-5); plot.addItem(region); self.interactions.overlays.append(region)

    def locate_peak(self,row,column):
        if row>=len(getattr(self,'peak_rows',[])): return
        idx,hz,value=self.peak_rows[row]
        plot=self.plot
        if self.chart_stack.currentIndex()==1:
            plot=self.multi_plots[[r[0] for r in self.current_result].index(idx)]
            self.multi_scroll.ensureWidgetVisible(plot)
        for p,item in getattr(self,'peak_annotations',[]):
            if item.scene() is not None: p.removeItem(item)
        self.peak_annotations=[]
        x=np.log10(hz) if self.x_scale.currentText()=='对数' else hz
        y=np.log10(value) if self.y_scale.currentText()=='对数' and value>0 else value
        marker=pg.ScatterPlotItem([x],[y],size=13,pen=pg.mkPen('#ff4050',width=2),brush=None)
        label=pg.TextItem(f'{hz:.6g} Hz\n{value:.6g} {self.value_unit()}',color='#ff4050',anchor=(0,1)); label.setPos(x,y)
        plot.addItem(marker); plot.addItem(label); self.peak_annotations=[(plot,marker),(plot,label)]
        plot.getViewBox().setRange(xRange=(x-.5,x+.5) if self.x_scale.currentText()=='对数' else (max(0,hz*.9-1),hz*1.1+1),padding=.05)

    def configuration_controls(self):
        names='mode unit window multi_mode axes_link spectral_display start_time end_time freq_min freq_max frequency_auto nperseg overlap peak_distance peak_prominence peak_count peak_minimum rms_low rms_high fs_override resample_fs filter_kind filter_low filter_high line_width line_style markers palette grid x_scale y_scale theme'
        return {name:getattr(self,name) for name in names.split()}

    def save_current_selection(self):
        context=self.interactions.selection_context
        if not context or not self.current:
            QtWidgets.QMessageBox.information(self,'保存选区','请先在图表中点击“拖动选区”并调整范围。'); return
        kind=context['kind']; prefix='时间段' if kind=='time' else '频段'
        count=1
        names={r['name'] for r in self.saved_selections if r['kind']==kind and (kind=='frequency' or r['source']==context['source'])}
        while f'{prefix}{count}' in names: count+=1
        name,ok=QtWidgets.QInputDialog.getText(self,'保存'+prefix,'选区名称：',text=f'{prefix}{count}')
        if not ok: return
        record=dict(context,name=name,source=context['source'] if kind=='time' else '')
        try:
            if record['low']<0: raise ValueError('选区下限不能小于零')
            maximum=self.current.time_s[-1]+self.current.sampling.median_dt_s if kind=='time' else self.current_result[0][2][-1]
            if record['high']>maximum+1e-8: raise ValueError('选区超出当前数据范围，请调整后保存')
            record=validate_selections([record])[0]
            existing=next((i for i,r in enumerate(self.saved_selections) if (r['kind'],r['source'],r['name'])==(record['kind'],record['source'],record['name'])),None)
            updated=list(self.saved_selections)
            if existing is not None:
                answer=QtWidgets.QMessageBox.question(self,'覆盖已保存选区',f'已存在同名{prefix}“{record["name"]}”，是否用当前范围覆盖？',QtWidgets.QMessageBox.Yes|QtWidgets.QMessageBox.No,QtWidgets.QMessageBox.No)
                if answer!=QtWidgets.QMessageBox.Yes: return
                updated[existing]=record
            else: updated.append(record)
            self.saved_selections=validate_selections(updated)
            self.statusBar().showMessage(f'已保存{prefix}：{name}。可在导出设置直接调用；保存分析配置可永久保留。')
        except Exception as exc: QtWidgets.QMessageBox.warning(self,'保存失败',str(exc))

    def manage_selections(self):
        dialog=SelectionDialog(self.saved_selections,self)
        dialog.recordsDeleted.connect(self.delete_saved_selections)
        if dialog.exec()!=QtWidgets.QDialog.Accepted: return
        self.saved_selections=dialog.records
        if self.studio is not None and self.studio.isVisible(): self.studio.refresh()
        if dialog.focus_record: self.focus_saved_selection(dialog.focus_record)

    def delete_saved_selections(self,records):
        self.saved_selections=[r for r in self.saved_selections if r not in records]
        if self.studio is not None and self.studio.isVisible(): self.studio.refresh()
        context=self.interactions.selection_context
        if context and any(r['kind']==context['kind'] and (r['kind']=='frequency' or r['source']==context['source']) and np.isclose(r['low'],context['low'],rtol=0,atol=1e-9) and np.isclose(r['high'],context['high'],rtol=0,atol=1e-9) for r in records):
            if self.interactions.active_region is not None:
                plot,region=self.interactions.active_region
                plot.removeItem(region)
                self.interactions.overlays=[item for item in self.interactions.overlays if item is not region]
            self.interactions.active_region=None
            self.interactions.selection_context=None
            self.selection_bounds=None
            self.measurement.setText('选区已删除')
        self.statusBar().showMessage(f'已删除 {len(records)} 个已保存选区；请保存分析配置以保留变更。')

    def focus_saved_selection(self,record):
        if not self.current: return
        if record['kind']=='time':
            index=next((i for i,ds in enumerate(self.datasets) if str(ds.path.resolve())==record['source']),None)
            if index is None:
                QtWidgets.QMessageBox.information(self,'所属文件未打开','请先导入该时间段所属文件：'+record['source']); return
            self.files.setCurrentRow(index)
            controls=[self.mode,self.start_time,self.end_time]
            blockers=[QtCore.QSignalBlocker(c) for c in controls]
            self.mode.setCurrentText('时域'); self.start_time.setValue(0); self.end_time.setValue(0); del blockers
        else:
            if self.mode.currentText()=='时域':
                blocker=QtCore.QSignalBlocker(self.mode); self.mode.setCurrentText('PSD'); del blocker
        self.pending_selection_focus=record
        self.analyze()

    def apply_pending_selection_focus(self):
        record=getattr(self,'pending_selection_focus',None)
        if not record or not self.current_result: return
        self.pending_selection_focus=None
        low,high=record['low'],record['high']; maximum=self.current_result[0][2][-1]
        if record['kind']=='frequency' and high>maximum:
            self.statusBar().showMessage('频段超出当前频谱范围，未定位'); return
        self.interactions.select_band((low,high))
        for plot in dict.fromkeys(p for p,_ in self.interactions.entries):
            xlow=self.interactions.coordinate(plot,max(low,maximum*1e-9) if self.x_scale.currentText()=='对数' and record['kind']=='frequency' else low)
            xhigh=self.interactions.coordinate(plot,high); plot.setXRange(xlow,xhigh,padding=.1)

    def save_configuration(self):
        filename,_=QtWidgets.QFileDialog.getSaveFileName(self,'保存分析配置','vibration_config.json','JSON (*.json)')
        if not filename: return
        try:
            controls=self.configuration_controls()
            data={name:(control.currentText() if isinstance(control,QtWidgets.QComboBox) else control.value()) for name,control in controls.items()}
            Path(filename).write_text(json.dumps({'version':1,'parameters':data,'saved_selections':self.saved_selections,'interaction_workspace':self.interaction_workspace,'channel_colors':{str(idx):colour for (path,idx),colour in self.channel_styles.items() if self.current and path==str(self.current.path)}},ensure_ascii=False,indent=2),encoding='utf-8')
            self.statusBar().showMessage('分析配置已保存')
        except Exception as exc: QtWidgets.QMessageBox.warning(self,'保存失败',str(exc))

    def load_configuration(self):
        filename,_=QtWidgets.QFileDialog.getOpenFileName(self,'加载分析配置','','JSON (*.json)')
        if not filename: return
        try:
            data=json.loads(Path(filename).read_text(encoding='utf-8'))
            if data.get('version')!=1 or not isinstance(data.get('parameters'),dict): raise ValueError('不支持的配置格式')
            selections=validate_selections(data.get('saved_selections',[]))
            workspace=validate_workspace(data.get('interaction_workspace',{}))
            controls=self.configuration_controls(); values=data['parameters']
            for name,value in values.items():
                if name not in controls: continue
                control=controls[name]
                if isinstance(control,QtWidgets.QComboBox):
                    if control.findText(str(value))<0: raise ValueError('无效配置项：'+name)
                elif not isinstance(value,(int,float)) or not np.isfinite(value) or not control.minimum()<=value<=control.maximum(): raise ValueError('无效参数：'+name)
            blockers=[QtCore.QSignalBlocker(control) for control in controls.values()]
            for name,value in values.items():
                if name not in controls: continue
                control=controls[name]
                if isinstance(control,QtWidgets.QComboBox): control.setCurrentText(value)
                else: control.setValue(int(value) if isinstance(control,QtWidgets.QSpinBox) else value)
            del blockers
            self.saved_selections=selections; self.previous_unit=self.unit.currentText()
            self.interaction_workspace=workspace
            if self.studio is not None:
                self.studio.drafts=[]; self.studio.active=None; self.studio.undo_states.clear(); self.studio.redo_states.clear()
            if self.current:
                for idx,colour in data.get('channel_colors',{}).items(): self.channel_styles[(str(self.current.path),int(idx))]=colour
            self.apply_theme(self.theme.currentText()); self.analyze()
        except Exception as exc: QtWidgets.QMessageBox.warning(self,'加载失败',str(exc))

    def spectral_name(self):
        return "ASD" if self.spectral_display.currentIndex() == 0 else "PSD"

    def spectral_unit(self, unit):
        if self.spectral_display.currentIndex() == 0:
            return {"g": "g/√Hz", "mm/s²": "mm/s²/√Hz", "m/s²": "m/s²/√Hz"}[unit]
        return {"g": "g²/Hz", "mm/s²": "mm²/s⁴/Hz", "m/s²": "m²/s⁴/Hz"}[unit]

    def describe(self,ds,result,mode,unit):
        _,kind,axis,values,fs,stats=result; warnings="\n".join(ds.warnings) or "无"
        processing=f"时间区间: {self.start_time.value():.6g}–{self.end_time.value() or ds.time_s[-1]:.6g} s\n重采样: {self.resample_fs.value() or '未使用'} Hz\n滤波: {self.filter_kind.currentText()}"
        common=f"文件: {ds.path.name}\n比较通道数: {len(self.selected_indexes())}\n自动采样率: {ds.sampling.sample_rate_hz:.6g} Hz\n当前采用: {fs:.6g} Hz\n中位采样间隔: {ds.sampling.median_dt_s:.9g} s\n间隔波动: {ds.sampling.jitter_pct:.4g}%\n数据质量: {warnings}\n\n处理链\n{processing}\n\n"
        if not ds.sampling.approximately_uniform: common+='采样质量警告：FFT/Welch 假定均匀采样；当前结果仅供参考，请核对丢帧及时间间隔。现有重采样基于样本顺序，不能修复时间戳丢帧。\n'
        if self.fs_override.value() and abs(self.fs_override.value()/ds.sampling.sample_rate_hz-1)>.05: common+='采样率警告：手动采样率与估算值偏差超过 5%，请确认。\n'
        if kind=="time": return common+"\n".join(f"{k}: {v:.6g} {unit}" for k,v in stats.items())
        return common+f"峰值频率: {axis[np.argmax(values)]:.6g} Hz\n峰值: {np.max(values):.6g} {self.value_unit()}"

    def export_result(self):
        if not self.current_result: return
        filename,_=QtWidgets.QFileDialog.getSaveFileName(self,"导出 CSV","analysis.csv","CSV (*.csv)")
        if not filename: return
        try:
            self.write_result(Path(filename), self.current_result[0])
        except Exception as exc:
            QtWidgets.QMessageBox.warning(self,"导出失败",str(exc))

    def export_configured(self,checked=False,definitions=None,output_unit=None,rms_default=False):
        if not self.current: return
        dialog=ExportDialog(self.current.channel_names,self,saved_selections=self.saved_selections,source=str(self.current.path.resolve()))
        saved=definitions if definitions is not None else getattr(self,'export_segment_plans',{}).get(str(self.current.path))
        if saved:
            dialog.segments.setRowCount(0)
            for definition in saved:
                dialog.add_segment(); row=dialog.segments.rowCount()-1
                for column,key in enumerate(('name','start','end','low','high')): dialog.segments.item(row,column).setText(str(definition[key]))
            dialog.segmented.setChecked(True)
        if output_unit: dialog.unit.setCurrentText(output_unit)
        if rms_default:
            for i in range(dialog.quantities.count()):
                item=dialog.quantities.item(i); item.setCheckState(QtCore.Qt.Checked if item.text()=='频段 RMS' else QtCore.Qt.Unchecked)
        if dialog.exec()!=QtWidgets.QDialog.Accepted: return
        indexes=dialog.checked(dialog.channels); quantities=[dialog.quantities.item(i).text() for i in dialog.checked(dialog.quantities)]
        if not indexes or not quantities:
            QtWidgets.QMessageBox.warning(self,'导出设置','至少选择一个通道和一个变量'); return
        filename,_=QtWidgets.QFileDialog.getSaveFileName(self,'保存分析数据','analysis.csv','CSV (*.csv)')
        if not filename: return
        try:
            if dialog.segmented.isChecked():
                self.export_segmented_results(Path(filename),dialog,indexes,quantities)
                if not hasattr(self,'export_segment_plans'): self.export_segment_plans={}
                self.export_segment_plans[str(self.current.path)]=dialog.segment_definitions()
                self.statusBar().showMessage('命名分段导出完成：'+str(Path(filename).parent)); return
            ds=self.current
            signals,fs,times,meta=self.prepare_single_export(dialog,indexes)
            low,high=dialog.low.value(),dialog.high.value()
            groups=[[i] for i in range(len(indexes))] if dialog.separate.isChecked() else [list(range(len(indexes)))]
            base=Path(filename)
            for group in groups:
                names=[ds.channel_names[indexes[i]] for i in group]
                target=base.with_name(base.stem+'_'+names[0]+'.csv') if dialog.separate.isChecked() else base
                export_bundle(target,[signals[i] for i in group],fs,times,names,quantities,dialog.unit.currentText(),low,high,self.window.currentText(),self.nperseg.value(),self.overlap.value(),meta,dialog.metadata.isChecked(),output_options=dialog.output_options())
            self.statusBar().showMessage('导出完成：'+str(base.parent))
        except Exception as exc: QtWidgets.QMessageBox.warning(self,'导出失败',str(exc))

    def prepare_single_export(self,dialog,indexes):
        ds=self.current; t=ds.time_s; start,end=dialog.start.value(),dialog.end.value()
        if end and end<=start: raise ValueError('结束时间必须大于起始时间')
        if dialog.high.value() and dialog.high.value()<=dialog.low.value(): raise ValueError('最高频率必须大于最低频率')
        mask=t>=start
        if end: mask &= t<=end
        if mask.sum()<2: raise ValueError('所选时间范围数据不足')
        signals=[]
        for idx in indexes:
            x,fs=self.processed_signal(ds,idx,mask); signals.append(x)
        times=t[mask]
        if self.resample_fs.value(): times=times[0]+np.arange(len(signals[0]))/fs
        effective=min(self.nperseg.value(),len(signals[0]))
        meta={'segment_name':'单一区间','source_file':str(ds.path),'source_unit':self.source_unit.currentText(),'start_s':start,'end_s':end or float(t[-1]),'actual_first_sample_s':float(times[0]),'actual_last_sample_s':float(times[-1]),'effective_nperseg':effective,'effective_noverlap':int(effective*self.overlap.value()/100),'filter':self.filter_kind.currentText(),'filter_low_hz':self.filter_low.value(),'filter_high_hz':self.filter_high.value(),'resample_hz':self.resample_fs.value(),'warnings':ds.warnings}
        return signals,fs,times,meta

    def preview_export_table(self,dialog):
        indexes=dialog.checked(dialog.channels); quantities=[dialog.quantities.item(i).text() for i in dialog.checked(dialog.quantities)]
        if not indexes or not quantities: raise ValueError('至少选择一个通道和变量')
        names=[self.current.channel_names[i] for i in indexes]
        if dialog.separate.isChecked(): indexes=indexes[:1]; names=names[:1]
        if dialog.segmented.isChecked():
            prepared=self.prepare_segmented_results(dialog,indexes)
            table=export_named_segments(None,prepared,names,quantities,dialog.unit.currentText(),self.window.currentText(),self.nperseg.value(),self.overlap.value(),metadata={'source_file':str(self.current.path),'source_unit':self.source_unit.currentText(),'filter':self.filter_kind.currentText(),'filter_low_hz':self.filter_low.value(),'filter_high_hz':self.filter_high.value(),'resample_hz':self.resample_fs.value()},return_table=True)
        else:
            signals,fs,times,meta=self.prepare_single_export(dialog,indexes)
            table=export_bundle(None,signals,fs,times,names,quantities,dialog.unit.currentText(),dialog.low.value(),dialog.high.value(),self.window.currentText(),self.nperseg.value(),self.overlap.value(),meta,return_table=True)
        return prepare_table(*table,dialog.output_options())

    def prepare_segmented_results(self,dialog,indexes):
        ds=self.current; t=ds.time_s; prepared=[]
        file_end=t[-1]+ds.sampling.median_dt_s
        for definition in dialog.segment_definitions():
            name=definition['name']; start,end=definition['start'],definition['end']
            if start<t[0] or end>file_end+1e-8: raise ValueError(f'分段“{name}”：时间范围超出文件 {t[0]:.6g}–{file_end:.6g} s')
            mask=(t>=start)&(t<end)
            if mask.sum()<2: raise ValueError(f'分段“{name}”：有效采样点不足两个')
            signals=[]
            for idx in indexes:
                try: x,fs=self.processed_signal(ds,idx,mask)
                except Exception as exc: raise ValueError(f'分段“{name}”：{exc}') from exc
                signals.append(x)
            if definition['low']>=fs/2 or definition['high']>fs/2: raise ValueError(f'分段“{name}”：积分频段超出奈奎斯特频率 {fs/2:.6g} Hz')
            times=t[mask]
            if self.resample_fs.value(): times=times[0]+np.arange(len(signals[0]))/fs
            prepared.append(dict(definition,signals=signals,fs=fs,times=times))
        return prepared

    def export_segmented_results(self,path,dialog,indexes,quantities):
        ds=self.current; prepared=self.prepare_segmented_results(dialog,indexes)
        meta={'source_file':str(ds.path),'source_unit':self.source_unit.currentText(),'filter':self.filter_kind.currentText(),'filter_low_hz':self.filter_low.value(),'filter_high_hz':self.filter_high.value(),'resample_hz':self.resample_fs.value(),'warnings':ds.warnings}
        groups=[[i] for i in range(len(indexes))] if dialog.separate.isChecked() else [list(range(len(indexes)))]
        for group in groups:
            names=[ds.channel_names[indexes[i]] for i in group]
            target=path.with_name(path.stem+'_'+names[0]+'.csv') if dialog.separate.isChecked() else path
            segments=[dict(segment,signals=[segment['signals'][i] for i in group]) for segment in prepared]
            export_named_segments(target,segments,names,quantities,dialog.unit.currentText(),self.window.currentText(),self.nperseg.value(),self.overlap.value(),meta,dialog.metadata.isChecked(),output_options=dialog.output_options())

    def preview_segment_rms(self,dialog):
        indexes=dialog.checked(dialog.channels)
        if not indexes: raise ValueError('至少选择一个通道')
        prepared=self.prepare_segmented_results(dialog,indexes); rows=[]
        for segment in prepared:
            for idx,signal in zip(indexes,segment['signals']):
                x=convert_acceleration(signal,'m/s²',dialog.unit.currentText())
                f,psd=welch_psd(x,segment['fs'],self.window.currentText(),self.nperseg.value(),self.overlap.value())
                try: _,rms=band_rms_from_psd(f,psd,segment['low'],segment['high'])
                except ValueError as exc: raise ValueError(f"分段“{segment['name']}”：{exc}") from exc
                rows.append([segment['name'],self.current.channel_names[idx],f"{segment['start']:g}–{segment['end']:g} s",f"{segment['low']:g}–{segment['high'] or f[-1]:g} Hz",rms,dialog.unit.currentText()])
        return rows

    def write_result(self, path, result):
        idx,kind,axis,values,fs,_=result; mode=self.mode.currentText(); unit=self.unit.currentText()
        params={"window":self.window.currentText(),"start_s":self.start_time.value(),"end_s":self.end_time.value(),"resample_hz":self.resample_fs.value(),"filter":self.filter_kind.currentText(),"spectral_quantity":self.spectral_name(),"peak_min_distance_hz":self.peak_distance.value(),"peak_prominence":self.peak_prominence.value()}
        meta=metadata_for(self.current,self.current.channel_names[idx],fs,mode,params,unit)
        if mode=='PSD': meta['unit']=self.spectral_unit(unit); meta['method']=self.spectral_name()
        if kind=="time": export_time_domain(path,axis,values,meta)
        else: export_series(path,axis,values,meta)

    def export_all_results(self):
        if not self.current_result: return
        filename,_=QtWidgets.QFileDialog.getSaveFileName(self,"选择导出文件名前缀","analysis.csv","CSV (*.csv)")
        if not filename: return
        base=Path(filename)
        try:
            for result in self.current_result:
                channel=self.current.channel_names[result[0]]
                target=base.with_name(f"{base.stem}_{channel}{base.suffix or '.csv'}")
                self.write_result(target,result)
            QtWidgets.QMessageBox.information(self,"导出完成",f"已导出 {len(self.current_result)} 个通道结果到：\n{base.parent}")
        except Exception as exc: QtWidgets.QMessageBox.warning(self,"导出失败",str(exc))

    def export_image(self):
        plots=[self.plot] if self.chart_stack.currentIndex()==0 else self.multi_plots
        if not plots: return
        choice,ok=QtWidgets.QInputDialog.getItem(self,'图表导出设置','选择图表：',['全部显示图表']+[f'图表 {i+1}' for i in range(len(plots))],0,False)
        if not ok: return
        width,ok=QtWidgets.QInputDialog.getInt(self,'图像尺寸','输出宽度（像素）：',1600,400,8000,100)
        if not ok: return
        filename,_=QtWidgets.QFileDialog.getSaveFileName(self,"导出当前图表 PNG","vibration_plot.png","PNG 图像 (*.png)")
        if not filename: return
        hidden=[]
        try:
            if not self.export_overlays.isChecked():
                items=self.interactions.overlays+[item for _,item in getattr(self,'peak_annotations',[])]
                for item in items:
                    if item.isVisible(): hidden.append(item); item.hide()
            selected=plots if choice=='全部显示图表' else [plots[int(choice.split()[-1])-1]]
            for i,plot in enumerate(selected):
                target=Path(filename)
                if len(selected)>1: target=target.with_name(f'{target.stem}_{i+1}.png')
                exporter=ImageExporter(plot.getPlotItem()); exporter.parameters()['width']=width; exporter.export(str(target))
        except Exception as exc: QtWidgets.QMessageBox.warning(self,"图表导出失败",str(exc))
        finally:
            for item in hidden: item.show()
