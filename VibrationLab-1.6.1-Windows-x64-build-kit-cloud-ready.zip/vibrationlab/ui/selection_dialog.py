from PySide6 import QtWidgets,QtCore
from vibrationlab.core.selection_library import validate_selections


class SelectionDialog(QtWidgets.QDialog):
    recordsDeleted=QtCore.Signal(list)

    def __init__(self,records,parent=None):
        super().__init__(parent); self.setWindowTitle('已保存选区管理'); self.resize(850,420)
        layout=QtWidgets.QVBoxLayout(self); self.records=[dict(r) for r in records]; self.focus_record=None
        self.table=QtWidgets.QTableWidget(len(records),5); self.table.setHorizontalHeaderLabels(['名称','类型','下限 (s / Hz)','上限 (s / Hz)','所属文件'])
        self.table.horizontalHeader().setSectionResizeMode(QtWidgets.QHeaderView.Stretch); layout.addWidget(self.table)
        self.table.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectRows)
        self.table.setSelectionMode(QtWidgets.QAbstractItemView.ExtendedSelection)
        for row,record in enumerate(records):
            for col,value in enumerate([record['name'],'时间段' if record['kind']=='time' else '频段',record['low'],record['high'],record['source'] or '跨文件通用']):
                item=QtWidgets.QTableWidgetItem(str(value))
                if col in (1,4): item.setFlags(item.flags()&~QtCore.Qt.ItemIsEditable)
                self.table.setItem(row,col,item)
            self.table.item(row,0).setData(QtCore.Qt.UserRole,dict(record))
        buttons=QtWidgets.QHBoxLayout(); layout.addLayout(buttons)
        for name,callback in [('删除选中',self.remove),('定位到图表',self.locate),('保存修改',self.save),('取消',self.reject)]:
            button=QtWidgets.QPushButton(name); button.clicked.connect(callback); buttons.addWidget(button)
        layout.addWidget(QtWidgets.QLabel('删除立即生效，关闭或取消不会恢复；名称和范围编辑需保存修改。\n时间段关联原始文件；频段跨文件复用。永久保留变更请重新保存分析配置。'))

    def edited_records(self):
        records=[]
        for row in range(self.table.rowCount()):
            original=self.table.item(row,0).data(QtCore.Qt.UserRole)
            records.append(dict(original,name=self.table.item(row,0).text(),low=self.table.item(row,2).text(),high=self.table.item(row,3).text()))
        return validate_selections(records)

    def remove(self):
        rows=sorted({i.row() for i in self.table.selectedIndexes()},reverse=True)
        if not rows:
            QtWidgets.QMessageBox.information(self,'删除选区','请先选中需要删除的行。'); return
        deleted=[self.table.item(row,0).data(QtCore.Qt.UserRole) for row in rows]
        self.records=[r for r in self.records if r not in deleted]
        for row in rows: self.table.removeRow(row)
        self.recordsDeleted.emit(deleted)

    def save(self):
        try: self.records=self.edited_records(); self.accept()
        except Exception as exc: QtWidgets.QMessageBox.warning(self,'选区设置',str(exc))

    def locate(self):
        row=self.table.currentRow()
        if row<0: return
        try:
            self.records=self.edited_records(); self.focus_record=self.records[row]; self.accept()
        except Exception as exc: QtWidgets.QMessageBox.warning(self,'选区设置',str(exc))
