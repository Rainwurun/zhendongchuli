"""Data-aware plot interactions; graphics coordinates may be logarithmic."""
import numpy as np
import pyqtgraph as pg
import uuid
from PySide6 import QtCore, QtWidgets, QtGui


class PlotInteractions:
    def __init__(self, window):
        self.window=window; self.entries=[]; self.history=[]; self.cursors=[]; self.overlays=[]
        self.busy=False
        self.selection_context=None; self.active_region=None; self.notes=[]

    def reset(self):
        self.entries=[]; self.cursors=[]; self.overlays=[]; self.history=[]
        self.selection_context=None; self.active_region=None; self.notes=[]
        self.window.selection_bounds=None

    @staticmethod
    def coordinate(plot, value, axis=0, inverse=False):
        log=plot.getPlotItem().ctrl.logXCheck.isChecked() if axis==0 else plot.getPlotItem().ctrl.logYCheck.isChecked()
        if not log: return float(value)
        return float(10**value if inverse else np.log10(max(value,np.finfo(float).tiny)))

    def attach(self, plots, results):
        self.entries=[]
        for n,result in enumerate(results):
            plot=plots[n] if len(plots)>1 else plots[0]
            self.entries.append((plot,result))
        for plot in dict.fromkeys(plots):
            legend=plot.addLegend(); legend.clear()
            for curve in plot.listDataItems():
                if curve.name(): legend.addItem(curve,curve.name())
            for sample,label in legend.items:
                curve=sample.item
                label.setToolTip('单击名称显示/隐藏曲线；双击单独查看，再次双击恢复全部。')
                label.mouseClickEvent=lambda event,c=curve:self.legend_toggle(event,c)
                label.mouseDoubleClickEvent=lambda event,c=curve,p=plot:self.legend_solo(event,p,c)
            plot.getViewBox().setMouseMode(pg.ViewBox.PanMode)
            # PlotWidget is retained for overlay mode; connect only once.
            if not getattr(plot,'interaction_connected',False):
                plot.scene().sigMouseMoved.connect(lambda pos,p=plot:self.mouse_moved(p,pos))
                plot.getViewBox().sigRangeChangedManually.connect(self.record_view)
                plot.interaction_connected=True
            curves=plot.listDataItems()
            for curve in curves:
                curve.curve.setClickable(True,width=10)
                curve.sigClicked.connect(lambda selected,*_:self.highlight(selected))
            line=pg.InfiniteLine(angle=90,pen=pg.mkPen('#888888',style=QtCore.Qt.DashLine)); plot.addItem(line); line.hide()
            self.overlays.append(line); plot.reference_line=line
            menu=plot.getViewBox().getMenu(None)
            if getattr(plot,'channel_menu',None): menu.removeAction(plot.channel_menu.menuAction())
            plot.channel_menu=menu.addMenu('曲线设置')
            for p,result in self.entries:
                if p is not plot: continue
                idx=result[0]; submenu=plot.channel_menu.addMenu(self.window.current.channel_names[idx])
                submenu.addAction('修改名称',lambda checked=False,i=idx:self.rename_channel(i))
                submenu.addAction('修改颜色',lambda checked=False,i=idx:self.edit_colour(i))
                for label,style in [('实线',QtCore.Qt.SolidLine),('虚线',QtCore.Qt.DashLine),('点线',QtCore.Qt.DotLine)]:
                    submenu.addAction(label,lambda checked=False,i=idx,s=style:self.edit_line(i,s))
        self.record_view()
        if self.window.cursor_enabled.isChecked(): self.add_cursors()
        self.draw_notes()

    def record_view(self,*_):
        if self.busy: return
        state=[(p,p.getViewBox().viewRange()) for p in dict.fromkeys(p for p,_ in self.entries)]
        if not self.history or str([r for _,r in state])!=str([r for _,r in self.history[-1]]): self.history.append(state)
        self.history=self.history[-30:]

    @staticmethod
    def legend_toggle(event,curve):
        event.accept(); curve.setVisible(not curve.isVisible())

    @staticmethod
    def legend_solo(event,plot,curve):
        event.accept(); solo=getattr(plot,'solo_curve',None)
        plot.solo_curve=None if solo is curve else curve
        for item in plot.listDataItems(): item.setVisible(plot.solo_curve is None or item is curve)

    def previous_view(self):
        if len(self.history)<2: return
        self.history.pop(); self.busy=True
        try:
            for plot,ranges in self.history[-1]: plot.setRange(xRange=ranges[0],yRange=ranges[1],padding=0)
        finally: self.busy=False

    def mouse_moved(self,plot,pos):
        if not plot.sceneBoundingRect().contains(pos): return
        raw=plot.getViewBox().mapSceneToView(pos).x()
        x=self.coordinate(plot,raw,inverse=True); values=[]
        for target,result in self.entries:
            idx,_,axis,y,_,_=result
            target.reference_line.setValue(self.coordinate(target,x)); target.reference_line.show()
            i=int(np.argmin(abs(axis-x)))
            values.append(f'{self.window.current.channel_names[idx]}: {y[i]:.6g} {self.window.value_unit()}')
        self.window.cursor_readout.setText(f'同步读数 {x:.6g} {"s" if self.window.mode.currentText()=="时域" else "Hz"} | '+'；'.join(values))

    def add_cursors(self):
        self.remove_cursors()
        for plot in dict.fromkeys(p for p,_ in self.entries):
            lo,hi=plot.getViewBox().viewRange()[0]
            for name,fraction,colour in [('A',.33,'#ffb000'),('B',.67,'#e64980')]:
                line=pg.InfiniteLine(lo+(hi-lo)*fraction,angle=90,movable=True,pen=pg.mkPen(colour,width=2),label=name)
                plot.addItem(line); self.cursors.append((plot,name,line)); self.overlays.append(line)
                line.sigPositionChanged.connect(lambda item,p=plot:self.cursor_changed(p,item))
        if self.cursors: self.cursor_changed(self.cursors[0][0],self.cursors[0][2])

    def remove_cursors(self):
        for plot,_,line in self.cursors:
            plot.removeItem(line)
            if line in self.overlays: self.overlays.remove(line)
        self.cursors=[]

    def cursor_changed(self,plot,line):
        if self.busy: return
        self.busy=True
        try:
            name=next(name for p,name,l in self.cursors if l is line)
            x=self.coordinate(plot,line.value(),inverse=True)
            source=next(result for p,result in self.entries if p is plot)
            axis=source[2]
            if self.window.cursor_snap.currentText()=='谱峰' and self.window.mode.currentText()!='时域':
                from scipy.signal import find_peaks
                peaks,_=find_peaks(source[3]); candidates=axis[peaks] if len(peaks) else axis
            else: candidates=axis
            x=float(candidates[np.argmin(abs(candidates-x))])
            for p,n,l in self.cursors:
                if n==name: l.setValue(self.coordinate(p,x))
            positions={n:self.coordinate(p,l.value(),inverse=True) for p,n,l in self.cursors if p is plot}
            if len(positions)<2: return
            a,b=positions['A'],positions['B']; details=[]
            for _,r in self.entries:
                idx,_,f,y,_,_=r; ya=float(y[np.argmin(abs(f-a))]); yb=float(y[np.argmin(abs(f-b))])
                details.append(f'{self.window.current.channel_names[idx]} A={ya:.6g}, B={yb:.6g}, Δ={yb-ya:.6g} {self.window.value_unit()}')
                if self.window.mode.currentText()=='时域':
                    selected=y[(f>=min(a,b))&(f<=max(a,b))]
                    if len(selected): details[-1]+=f'；区间 RMS={np.sqrt(np.mean(selected**2)):.6g} {self.window.value_unit()}，峰峰值={np.ptp(selected):.6g} {self.window.value_unit()}'
                elif self.window.mode.currentText()=='PSD':
                    from vibrationlab.core.analysis import band_rms_from_psd,convert_acceleration
                    low,high=max(float(f[0]),min(a,b)),min(float(f[-1]),max(a,b))
                    if low<high:
                        _,rms=band_rms_from_psd(f,y*y if self.window.spectral_display.currentIndex()==0 else y,low,high)
                        details[-1]+=f'；频段 RMS={float(convert_acceleration([rms],self.window.unit.currentText(),"g")[0]):.6g} g'
            self.window.measurement.setText(f'A={a:.6g}, B={b:.6g}, Δ={b-a:.6g} {"s" if self.window.mode.currentText()=="时域" else "Hz"}\n'+'；'.join(details))
        finally: self.busy=False

    def select_band(self,bounds=None):
        if not self.entries: return
        if isinstance(bounds,bool): bounds=None
        plot,result=self.entries[0]; axis=result[2]
        if bounds is None: bounds=(float(axis[len(axis)//4]),float(axis[3*len(axis)//4]))
        if self.active_region is not None:
            old_plot,old_region=self.active_region; old_plot.removeItem(old_region)
            self.overlays=[item for item in self.overlays if item is not old_region]
        region=pg.LinearRegionItem(tuple(self.coordinate(plot,float(v)) for v in bounds),brush=pg.mkBrush(80,160,240,55))
        self.active_region=(plot,region)
        plot.addItem(region); self.overlays.append(region)
        def changed():
            low,high=[self.coordinate(plot,x,inverse=True) for x in region.getRegion()]
            self.window.selection_bounds=(low,high)
            self.selection_context=dict(kind='time' if self.window.mode.currentText()=='时域' else 'frequency',source=str(self.window.current.path.resolve()),low=low,high=high)
            self.window.measurement.setText(f'选区 {low:.6g}–{high:.6g} {"s" if self.window.mode.currentText()=="时域" else "Hz"}')
            if self.window.mode.currentText()=='PSD':
                blockers=[QtCore.QSignalBlocker(self.window.rms_low),QtCore.QSignalBlocker(self.window.rms_high)]
                self.window.rms_low.setValue(max(axis[0],low)); self.window.rms_high.setValue(min(axis[-1],high)); del blockers
                if self.window.rms_low.value()<self.window.rms_high.value(): self.window.calculate_band_rms()
        region.sigRegionChanged.connect(changed); changed()

    def highlight(self,curve):
        for plot in dict.fromkeys(p for p,_ in self.entries):
            for item in plot.listDataItems(): item.setOpacity(1 if item is curve else .25)

    def rename_channel(self,idx):
        text,ok=QtWidgets.QInputDialog.getText(self.window,'通道名称','名称：',text=self.window.current.channel_names[idx])
        if not ok or not text.strip(): return
        text=text.strip()
        if any(c in text for c in '/\\') or text in ('.','..'):
            QtWidgets.QMessageBox.warning(self.window,'无效名称','名称不能包含路径分隔符。'); return
        if text in [n for i,n in enumerate(self.window.current.channel_names) if i!=idx]:
            QtWidgets.QMessageBox.warning(self.window,'名称重复','请使用不同的通道名称。'); return
        self.window.current.channel_names[idx]=text; self.window.channels.item(idx).setText(text); self.window.analyze()

    def edit_colour(self,idx):
        colour=QtWidgets.QColorDialog.getColor(parent=self.window)
        if colour.isValid():
            self.window.channel_styles[(str(self.window.current.path),idx)]=colour.name(); self.window.analyze()

    def edit_line(self,idx,style):
        self.window.channel_line_styles[(str(self.window.current.path),idx)]=style; self.window.analyze()

    def annotate(self):
        if not self.entries: return
        text,ok=QtWidgets.QInputDialog.getText(self.window,'添加图上备注','备注内容：')
        if not ok or not text: return
        plot=self.entries[0][0]; ranges=plot.getViewBox().viewRange(); w=self.window
        note=dict(id=uuid.uuid4().hex,source=str(w.current.path.resolve()),kind='time' if w.mode.currentText()=='时域' else 'frequency',
            text=text,x=self.coordinate(plot,np.mean(ranges[0]),inverse=True),y=self.coordinate(plot,np.mean(ranges[1]),1,inverse=True),
            size=11,unit=w.unit.currentText(),spectrum=w.spectral_name() if w.mode.currentText()=='PSD' else 'FFT')
        w.interaction_workspace['notes'].append(note); self.draw_notes()

    def draw_notes(self):
        from .interaction_studio import StudioNote
        from vibrationlab.core.analysis import convert_acceleration,convert_acceleration_psd
        for plot,item in self.notes:
            plot.removeItem(item); self.overlays=[overlay for overlay in self.overlays if overlay is not item]
        self.notes=[]
        if not self.entries: return
        w=self.window; plot=self.entries[0][0]; kind='time' if w.mode.currentText()=='时域' else 'frequency'
        spectrum=w.spectral_name() if w.mode.currentText()=='PSD' else 'FFT'
        for note in w.interaction_workspace['notes']:
            if note['source']!=str(w.current.path.resolve()) or note['kind']!=kind or (kind=='frequency' and note['spectrum']!=spectrum): continue
            if kind=='frequency' and 'start' in note:
                end=w.end_time.value() or float(w.current.time_s[-1]+w.current.sampling.median_dt_s)
                if not np.allclose([note['start'],note['end']],[w.start_time.value(),end],rtol=0,atol=1e-8): continue
            converter=convert_acceleration_psd if kind=='frequency' and spectrum=='PSD' else convert_acceleration
            y=float(converter([note['y']],note['unit'],w.unit.currentText())[0])
            def moved(pos,n=note,c=converter):
                n['x']=self.coordinate(plot,pos.x(),inverse=True)
                n['y']=float(c([self.coordinate(plot,pos.y(),1,inverse=True)],w.unit.currentText(),n['unit'])[0])
            def edit(n=note):
                value,ok=QtWidgets.QInputDialog.getText(w,'修改图上备注','内容：',text=n['text'])
                if ok and value.strip(): n['text']=value.strip(); self.draw_notes()
            item=StudioNote(note['text'],moved,edit); font=QtGui.QFont(); font.setPointSize(note['size']); item.setFont(font)
            item.setPos(self.coordinate(plot,note['x']),self.coordinate(plot,y,1)); plot.addItem(item)
            self.notes.append((plot,item)); self.overlays.append(item)
