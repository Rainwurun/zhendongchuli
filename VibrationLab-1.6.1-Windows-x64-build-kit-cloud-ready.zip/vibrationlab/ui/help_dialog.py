"""Offline help shipped with the application, including algorithm details."""
from pathlib import Path
import shutil
from PySide6 import QtCore,QtGui,QtWidgets


class HelpDialog(QtWidgets.QDialog):
    def __init__(self,owner):
        super().__init__(owner)
        self.setWindowTitle('VibrationLab · 使用与算法说明'); self.resize(1050,800)
        layout=QtWidgets.QVBoxLayout(self); bar=QtWidgets.QHBoxLayout(); layout.addLayout(bar)
        self.search=QtWidgets.QLineEdit(); self.search.setPlaceholderText('搜索关键词，例如 PSD、RMS、重采样')
        bar.addWidget(self.search,1)
        find=QtWidgets.QPushButton('查找下一个'); bar.addWidget(find)
        save=QtWidgets.QPushButton('另存 HTML 帮助'); bar.addWidget(save)
        self.browser=QtWidgets.QTextBrowser(); self.browser.setOpenExternalLinks(True); layout.addWidget(self.browser,1)
        self.path=Path(__file__).resolve().parents[1]/'resources'/'help.html'
        if self.path.is_file(): self.browser.setSource(QtCore.QUrl.fromLocalFile(str(self.path)))
        else: self.browser.setPlainText('未找到随包帮助资源，请查看发布目录中的“帮助文档_使用与算法说明.md”。')
        self.search.returnPressed.connect(self.find_next); find.clicked.connect(self.find_next); save.clicked.connect(self.save_copy)
        close=QtWidgets.QPushButton('关闭'); close.clicked.connect(self.close); layout.addWidget(close)

    def find_next(self):
        word=self.search.text().strip()
        if not word: return
        if not self.browser.find(word):
            cursor=self.browser.textCursor(); cursor.movePosition(QtGui.QTextCursor.Start)
            self.browser.setTextCursor(cursor); self.browser.find(word)

    def save_copy(self):
        if not self.path.is_file(): return
        name,_=QtWidgets.QFileDialog.getSaveFileName(self,'另存帮助文档','VibrationLab_使用与算法说明.html','HTML (*.html)')
        if not name: return
        if not Path(name).suffix: name+='.html'
        try:
            if Path(name).resolve()!=self.path.resolve(): shutil.copyfile(self.path,name)
        except OSError as exc: QtWidgets.QMessageBox.warning(self,'保存帮助失败',str(exc))
