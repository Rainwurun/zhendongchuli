"""Use only QAction/QMenu in macOS native menu bars."""
from PySide6 import QtWidgets, QtGui, QtCore


class ParameterDialog(QtWidgets.QDialog):
    """Edit copies of numeric controls; cancel leaves analysis unchanged."""
    def __init__(self,title,fields,parent):
        super().__init__(parent); self.setWindowTitle(title); self.resize(440,180)
        form=QtWidgets.QFormLayout(self); self.fields=[]
        for label,original in fields:
            if isinstance(original,QtWidgets.QDoubleSpinBox):
                copy=QtWidgets.QDoubleSpinBox(); copy.setDecimals(original.decimals())
            else: copy=QtWidgets.QSpinBox()
            copy.setRange(original.minimum(),original.maximum()); copy.setSingleStep(original.singleStep())
            copy.setSuffix(original.suffix()); copy.setSpecialValueText(original.specialValueText())
            copy.setValue(original.value()); copy.setToolTip(original.toolTip()); copy.setKeyboardTracking(False)
            form.addRow(label,copy); self.fields.append((original,copy))
        buttons=QtWidgets.QDialogButtonBox(QtWidgets.QDialogButtonBox.Ok|QtWidgets.QDialogButtonBox.Cancel)
        buttons.accepted.connect(self.accept); buttons.rejected.connect(self.reject); form.addRow(buttons)

    def apply(self):
        blockers=[QtCore.QSignalBlocker(original) for original,_ in self.fields]
        for original,copy in self.fields: original.setValue(copy.value())
        del blockers


def install_native_menus(window):
    # Keep default-widget actions alive. Their controls remain the single source
    # of parameter state for configuration, analysis and export.
    window.legacy_parameter_actions=[]; window.native_action_groups=[]
    window.native_parameter_fields={}

    def edit(title,fields):
        dialog=ParameterDialog(title,fields,window)
        if dialog.exec()==QtWidgets.QDialog.Accepted:
            dialog.apply(); window.analyze()

    def convert(menu):
        numeric=[]
        for action in list(menu.actions()):
            if action.menu(): convert(action.menu()); continue
            if not isinstance(action,QtWidgets.QWidgetAction): continue
            widget=action.defaultWidget()
            if widget is None: continue
            labels=widget.findChildren(QtWidgets.QLabel)
            label=labels[0].text().rstrip('：: ') if labels else '参数'
            candidates=[child for child in widget.findChildren(QtWidgets.QWidget) if isinstance(child,(QtWidgets.QComboBox,QtWidgets.QSpinBox,QtWidgets.QDoubleSpinBox,QtWidgets.QCheckBox))]
            if not candidates: raise ValueError('未识别的菜单控件：'+label)
            control=candidates[0]
            window.legacy_parameter_actions.append(action)
            if isinstance(control,QtWidgets.QComboBox):
                submenu=QtWidgets.QMenu(label,window)
                window.menu_references.append(submenu)
                group=QtGui.QActionGroup(submenu); group.setExclusive(True)
                window.native_action_groups.append(group)
                for i in range(control.count()):
                    option=submenu.addAction(control.itemText(i)); option.setCheckable(True)
                    option.setChecked(i==control.currentIndex()); option.setToolTip(control.toolTip()); group.addAction(option)
                    option.triggered.connect(lambda checked=False,c=control,index=i:c.setCurrentIndex(index))
                control.currentIndexChanged.connect(lambda index,g=group:[a.setChecked(i==index) for i,a in enumerate(g.actions())])
                menu.insertMenu(action,submenu)
            elif isinstance(control,QtWidgets.QCheckBox):
                replacement=QtGui.QAction(label,window); replacement.setCheckable(True); replacement.setChecked(control.isChecked()); replacement.setToolTip(control.toolTip())
                replacement.toggled.connect(control.setChecked); control.toggled.connect(replacement.setChecked); menu.insertAction(action,replacement)
            else:
                numeric.append((label,control))
            menu.removeAction(action)
        if numeric:
            window.native_parameter_fields[menu.title()]=numeric
            menu.addAction('设置参数…',lambda checked=False,title=menu.title(),fields=numeric:edit(title,fields))

    for action in window.menuBar().actions():
        if action.menu(): convert(action.menu())
