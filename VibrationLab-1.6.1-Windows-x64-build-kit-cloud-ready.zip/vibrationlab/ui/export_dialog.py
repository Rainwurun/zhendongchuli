from PySide6 import QtWidgets, QtCore
import math
import json
from vibrationlab.core.export_table import FIELDS


class ExportDialog(QtWidgets.QDialog):
    def __init__(self,names,parent=None,saved_selections=None,source=''):
        super().__init__(parent); self.setWindowTitle('导出设置'); self.resize(850,730)
        self.saved_selections=saved_selections or []; self.source=source; self.owner=parent
        outer=QtWidgets.QVBoxLayout(self); scroll=QtWidgets.QScrollArea(); scroll.setWidgetResizable(True); outer.addWidget(scroll)
        body=QtWidgets.QWidget(); scroll.setWidget(body); form=QtWidgets.QFormLayout(body)
        self.channels=QtWidgets.QListWidget()
        for name in names:
            item=QtWidgets.QListWidgetItem(name); item.setFlags(item.flags()|QtCore.Qt.ItemIsUserCheckable); item.setCheckState(QtCore.Qt.Checked); self.channels.addItem(item)
        form.addRow('导出通道',self.channels)
        self.channels.setMaximumHeight(100)
        self.quantities=QtWidgets.QListWidget()
        for name in ['时域','统计值','FFT','PSD','ASD','频段 RMS','均方值']:
            item=QtWidgets.QListWidgetItem(name); item.setFlags(item.flags()|QtCore.Qt.ItemIsUserCheckable); item.setCheckState(QtCore.Qt.Checked if name=='PSD' else QtCore.Qt.Unchecked); self.quantities.addItem(item)
        form.addRow('导出变量',self.quantities)
        self.quantities.setMaximumHeight(125)
        self.unit=QtWidgets.QComboBox(); self.unit.addItems(['g','m/s²','mm/s²']); form.addRow('输出单位',self.unit)
        for name,label in [('start','起始时间 (s)'),('end','结束时间 (s，0=末尾)'),('low','最低频率 (Hz)'),('high','最高频率 (Hz，0=全频段)')]:
            spin=QtWidgets.QDoubleSpinBox(); spin.setRange(0,1e9); spin.setDecimals(4); setattr(self,name,spin); form.addRow(label,spin)
        self.segmented=QtWidgets.QCheckBox('使用命名多分段（每段独立时间与频段）'); form.addRow(self.segmented)
        self.segments=QtWidgets.QTableWidget(0,7); self.segments.setHorizontalHeaderLabels(['分段名称','起始 s','结束 s','最低 Hz','最高 Hz（0=全频）','调用时间段','调用频段']); self.segments.horizontalHeader().setSectionResizeMode(QtWidgets.QHeaderView.Stretch); self.segments.setMinimumHeight(190); form.addRow(self.segments)
        row=QtWidgets.QWidget(); actions=QtWidgets.QHBoxLayout(row)
        add=QtWidgets.QPushButton('添加分段'); remove=QtWidgets.QPushButton('删除选中分段'); actions.addWidget(add); actions.addWidget(remove); form.addRow(row)
        add.clicked.connect(self.add_segment); remove.clicked.connect(self.remove_segments)
        preview=QtWidgets.QPushButton('预览各段 RMS'); actions.addWidget(preview); preview.clicked.connect(self.preview_rms)
        pictures=QtWidgets.QPushButton('按分段批量导出图片…'); actions.addWidget(pictures); pictures.clicked.connect(self.export_images)
        self.segmented.toggled.connect(lambda enabled:[control.setEnabled(not enabled) for control in (self.start,self.end,self.low,self.high)])
        self.add_segment()
        self.separate=QtWidgets.QCheckBox('每通道独立 CSV'); form.addRow(self.separate)
        self.metadata=QtWidgets.QCheckBox('包含分析参数与处理记录'); self.metadata.setChecked(True); form.addRow(self.metadata)
        self.preset=QtWidgets.QComboBox(); self.preset.addItems(['精简结果','工程记录','自定义']); form.addRow('输出预设',self.preset)
        self.output_layout=QtWidgets.QComboBox(); self.output_layout.addItems(['长表：每行一个通道结果','宽表：各通道分别一列']); form.addRow('表格布局',self.output_layout)
        self.fields=QtWidgets.QListWidget(); self.fields.setMaximumHeight(180)
        for key,label in FIELDS.items():
            item=QtWidgets.QListWidgetItem(label); item.setData(QtCore.Qt.UserRole,key); item.setFlags(item.flags()|QtCore.Qt.ItemIsUserCheckable); item.setCheckState(QtCore.Qt.Unchecked); self.fields.addItem(item)
        form.addRow('输出字段（仅导出勾选列）',self.fields)
        preview_file=QtWidgets.QPushButton('预览实际输出列与前 10 行'); preview_file.clicked.connect(self.preview_output); form.addRow(preview_file)
        self.preset.currentTextChanged.connect(self.apply_preset)
        self.fields.itemChanged.connect(lambda _:self.preset.setCurrentText('自定义'))
        self.quantities.itemChanged.connect(lambda _:self.apply_preset(self.preset.currentText()) if self.preset.currentText()!='自定义' else None)
        self.apply_preset('精简结果'); self.restore_preferences()
        note=QtWidgets.QLabel('多分段模式使用表格中的名称、时间和频段，逐段独立分析。时间范围为 [起始,结束)，按文件起点计秒。勾选“频段 RMS”可导出各段有效值。'); note.setWordWrap(True); form.addRow(note)
        buttons=QtWidgets.QDialogButtonBox(QtWidgets.QDialogButtonBox.Ok|QtWidgets.QDialogButtonBox.Cancel); buttons.accepted.connect(self.validate_and_accept); buttons.rejected.connect(self.reject); outer.addWidget(buttons)

    def add_segment(self):
        row=self.segments.rowCount(); self.segments.insertRow(row)
        for column,value in enumerate((f'分段{row+1}',str(self.start.value()),str(self.end.value() or self.start.value()+1),str(self.low.value()),str(self.high.value()))):
            self.segments.setItem(row,column,QtWidgets.QTableWidgetItem(value))
        for column,kind in [(5,'time'),(6,'frequency')]:
            combo=QtWidgets.QComboBox(); combo.addItem('手动输入',None)
            for record in self.saved_selections:
                if record['kind']==kind and (kind=='frequency' or record['source']==self.source):
                    combo.addItem(f"{record['name']} ({record['low']:g}–{record['high']:g})",record)
            self.segments.setCellWidget(row,column,combo)
            combo.currentIndexChanged.connect(lambda index,c=combo,col=column:self.apply_saved_range(c,col))

    def apply_saved_range(self,combo,column):
        record=combo.currentData()
        if not record: return
        row=next((i for i in range(self.segments.rowCount()) if self.segments.cellWidget(i,column) is combo),None)
        if row is None: return
        columns=(1,2) if column==5 else (3,4)
        for target,key in zip(columns,('low','high')): self.segments.item(row,target).setText(str(record[key]))
        self.segmented.setChecked(True)
        name=self.segments.item(row,0)
        auto=name.data(QtCore.Qt.UserRole)
        if name.text().startswith('分段') or name.text()==auto:
            records=[self.segments.cellWidget(row,c).currentData() for c in (5,6)]
            text=' / '.join(r['name'] for r in records if r); name.setText(text); name.setData(QtCore.Qt.UserRole,text)

    def preview_rms(self):
        if self.owner is None: return
        try:
            if not self.segmented.isChecked(): raise ValueError('请启用多分段模式并设置分段表')
            rows=self.owner.preview_segment_rms(self)
            dialog=QtWidgets.QDialog(self); dialog.setWindowTitle('RMS 导出预览（与导出共用分段计算）'); dialog.resize(850,400)
            layout=QtWidgets.QVBoxLayout(dialog); table=QtWidgets.QTableWidget(len(rows),6); table.setHorizontalHeaderLabels(['分段名称','通道','时间范围','积分频段','总有效值 RMS','单位']); table.horizontalHeader().setSectionResizeMode(QtWidgets.QHeaderView.Stretch); layout.addWidget(table)
            for row,values in enumerate(rows):
                for column,value in enumerate(values): table.setItem(row,column,QtWidgets.QTableWidgetItem(f'{value:.8g}' if isinstance(value,float) else str(value)))
            close=QtWidgets.QPushButton('返回导出设置'); close.clicked.connect(dialog.accept); layout.addWidget(close); dialog.exec()
        except Exception as exc: QtWidgets.QMessageBox.warning(self,'无法预览 RMS',str(exc))

    def export_images(self):
        if self.owner is None: return
        try:
            indexes=self.checked(self.channels)
            if not indexes: raise ValueError('请勾选通道')
            if not self.segmented.isChecked(): raise ValueError('请启用命名多分段，并填写或调用时间段、频段')
            from .batch_images import BatchImages
            segments=self.owner.prepare_segmented_results(self,indexes)
            dialog=BatchImages(self.owner,segments,[self.owner.current.channel_names[i] for i in indexes],self.unit.currentText()); dialog.exec()
        except Exception as exc: QtWidgets.QMessageBox.warning(self,'批量图片导出',str(exc))

    def remove_segments(self):
        for row in sorted({index.row() for index in self.segments.selectedIndexes()},reverse=True): self.segments.removeRow(row)

    def segment_definitions(self):
        definitions=[]; used=set()
        for row in range(self.segments.rowCount()):
            texts=[self.segments.item(row,i).text().strip() if self.segments.item(row,i) else '' for i in range(5)]
            name=texts[0]
            if not name or name in used: raise ValueError(f'第 {row+1} 段名称为空或重复，请填写唯一名称')
            try: start,end,low,high=map(float,texts[1:])
            except ValueError: raise ValueError(f'分段“{name}”：时间和频率必须为数字')
            if not all(math.isfinite(v) for v in (start,end,low,high)) or start<0 or end<=start or low<0 or high<0 or (high and high<=low):
                raise ValueError(f'分段“{name}”：请检查时间、频率上下限')
            definitions.append(dict(name=name,start=start,end=end,low=low,high=high)); used.add(name)
        if not definitions: raise ValueError('请至少添加一个分段')
        return definitions

    def validate_and_accept(self):
        try:
            if self.segmented.isChecked(): self.segment_definitions()
            options=self.output_options()
            if not options['fields']: raise ValueError('请至少选择一个输出字段')
            if options['layout']=='wide' and 'value' not in options['fields']: raise ValueError('通道分列布局需要勾选结果数值')
            settings=QtCore.QSettings('VibrationLab','VibrationLab')
            settings.setValue('export/preferences',json.dumps(dict(options,preset=self.preset.currentText(),metadata=self.metadata.isChecked(),unit=self.unit.currentText(),quantities=[self.quantities.item(i).text() for i in self.checked(self.quantities)],separate=self.separate.isChecked())))
            self.accept()
        except ValueError as exc: QtWidgets.QMessageBox.warning(self,'分段设置',str(exc))

    def output_options(self):
        return dict(fields=[self.fields.item(i).data(QtCore.Qt.UserRole) for i in self.checked(self.fields)],layout='wide' if self.output_layout.currentIndex() else 'long')

    def apply_preset(self,name):
        if name=='自定义': return
        quantities=[self.quantities.item(i).text() for i in self.checked(self.quantities)]
        minimal=['segment_name','channel','value','unit']
        if not quantities or any(q not in ('频段 RMS','均方值') for q in quantities): minimal+=['quantity','time_s / frequency_hz / metric']
        if len(quantities)>1 and 'quantity' not in minimal: minimal+=['quantity']
        keys=list(FIELDS) if name=='工程记录' else minimal
        blocker=QtCore.QSignalBlocker(self.fields)
        for i in range(self.fields.count()): self.fields.item(i).setCheckState(QtCore.Qt.Checked if self.fields.item(i).data(QtCore.Qt.UserRole) in keys else QtCore.Qt.Unchecked)
        del blocker
        self.metadata.setChecked(name=='工程记录')

    def restore_preferences(self):
        try:
            value=QtCore.QSettings('VibrationLab','VibrationLab').value('export/preferences','')
            if not value: return
            prefs=json.loads(value); blockers=[QtCore.QSignalBlocker(widget) for widget in (self.fields,self.preset,self.quantities)]
            for i in range(self.fields.count()): self.fields.item(i).setCheckState(QtCore.Qt.Checked if self.fields.item(i).data(QtCore.Qt.UserRole) in prefs['fields'] else QtCore.Qt.Unchecked)
            for i in range(self.quantities.count()): self.quantities.item(i).setCheckState(QtCore.Qt.Checked if self.quantities.item(i).text() in prefs.get('quantities',[]) else QtCore.Qt.Unchecked)
            self.preset.setCurrentText(prefs.get('preset','自定义')); self.output_layout.setCurrentIndex(1 if prefs.get('layout')=='wide' else 0); self.metadata.setChecked(prefs.get('metadata',False)); self.unit.setCurrentText(prefs.get('unit','g')); self.separate.setChecked(prefs.get('separate',False)); del blockers
        except (ValueError,KeyError,TypeError): pass

    def preview_output(self):
        if self.owner is None: return
        try:
            headers,rows=self.owner.preview_export_table(self)
            dialog=QtWidgets.QDialog(self); dialog.setWindowTitle(f'输出预览：{len(headers)} 列 / {len(rows)} 行'); dialog.resize(950,400)
            layout=QtWidgets.QVBoxLayout(dialog)
            layout.addWidget(QtWidgets.QLabel(('每通道独立文件：此处预览第一个已选通道。' if self.separate.isChecked() else '预览所选通道的合并输出。')+(' 文件顶部将另附一行分析元数据。' if self.metadata.isChecked() else ' 不附加元数据说明行。')))
            table=QtWidgets.QTableWidget(min(10,len(rows)),len(headers)); table.setHorizontalHeaderLabels(headers); layout.addWidget(table)
            for row,values in enumerate(rows[:10]):
                for col,value in enumerate(values): table.setItem(row,col,QtWidgets.QTableWidgetItem(str(value)))
            table.resizeColumnsToContents(); close=QtWidgets.QPushButton('返回'); close.clicked.connect(dialog.accept); layout.addWidget(close); dialog.exec()
        except Exception as exc: QtWidgets.QMessageBox.warning(self,'输出预览失败',str(exc))

    @staticmethod
    def checked(widget):
        return [i for i in range(widget.count()) if widget.item(i).checkState()==QtCore.Qt.Checked]
