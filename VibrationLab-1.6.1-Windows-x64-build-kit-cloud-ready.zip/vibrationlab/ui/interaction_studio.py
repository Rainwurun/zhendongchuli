"""Linked time/spectrum workspace. Numeric work stays off the GUI thread."""
from copy import deepcopy
from pathlib import Path
import json
import math
import uuid

import numpy as np
import pyqtgraph as pg
from PySide6 import QtCore, QtGui, QtWidgets, QtSvg
from pyqtgraph.exporters import ImageExporter

from vibrationlab.core.analysis import (
    apply_filter, band_rms_from_psd, convert_acceleration,
    convert_acceleration_psd, fft_spectrum, find_spectral_peaks,
    resample_uniform, time_statistics, welch_psd,
)
from vibrationlab.core.selection_library import validate_selections

COLOURS = ['#2988d5', '#e39429', '#a15ccc', '#19a18e', '#dd596c', '#7e8d36']


def validate_workspace(value):
    """Validate configuration before mutating the live workspace."""
    if not isinstance(value, dict):
        raise ValueError('交互工作台配置无效')
    notes = []
    for note in value.get('notes', []):
        if not isinstance(note, dict) or note.get('kind') not in ('time', 'frequency'):
            raise ValueError('图表标注类型无效')
        text = str(note.get('text', '')).strip()
        x, y = float(note['x']), float(note['y'])
        size = int(note.get('size', 11))
        if not text or not all(math.isfinite(v) for v in (x, y)) or not 7 <= size <= 32:
            raise ValueError('图表标注内容或位置无效')
        notes.append(dict(id=str(note.get('id', uuid.uuid4().hex)), source=str(note.get('source', '')),
                          kind=note['kind'], text=text, x=x, y=y, size=size,
                          unit=str(note.get('unit', 'm/s²')), spectrum=str(note.get('spectrum', 'PSD'))))
        if notes[-1]['unit'] not in ('m/s²', 'mm/s²', 'g') or notes[-1]['spectrum'] not in ('PSD', 'ASD', 'FFT'):
            raise ValueError('图表标注单位或频谱类型无效')
        if 'start' in note or 'end' in note:
            start, end = float(note['start']), float(note['end'])
            if not math.isfinite(start) or not math.isfinite(end) or start < 0 or end <= start:
                raise ValueError('标注的时间段范围无效')
            notes[-1].update(start=start, end=end)
    queue = []
    for task in value.get('queue', []):
        start, end, low, high = (float(task[k]) for k in ('start', 'end', 'low', 'high'))
        name = str(task.get('name', '')).strip()
        if not name or not all(math.isfinite(v) for v in (start, end, low, high)) or start < 0 or end <= start or low < 0 or high < 0 or (high and high <= low):
            raise ValueError('交互导出任务名称或范围无效')
        queue.append(dict(name=name, source=str(task['source']), start=start, end=end, low=low, high=high))
    return dict(notes=notes, queue=queue)


class StudioWorker(QtCore.QThread):
    ready = QtCore.Signal(int, object)
    failed = QtCore.Signal(int, str)

    def __init__(self, generation, ds, indexes, options, bounds, parent):
        super().__init__(parent)
        self.args = generation, ds, indexes, options, bounds

    def run(self):
        generation, ds, indexes, o, bounds = self.args
        try:
            t = ds.time_s
            end = float(t[-1] + ds.sampling.median_dt_s)
            low, high = bounds or (float(t[0]), end)
            if low < t[0] or high > end + 1e-8 or low >= high:
                raise ValueError('时间选区超出文件范围')
            mask = (t >= low) & (t < high)
            if mask.sum() < 2:
                raise ValueError('所选时间段至少需要两个采样点')
            rows = []
            for idx in indexes:
                if self.isInterruptionRequested():
                    return
                raw = convert_acceleration(ds.channels[:, idx], o['source_unit'], 'm/s²')
                fs = o['fs']
                whole = raw
                if o['resample']:
                    whole, _ = resample_uniform(whole, fs, o['resample'])
                display_fs = o['resample'] or fs
                whole = apply_filter(whole, display_fs, o['filter'], o['filter_low'], o['filter_high'])
                display_t = t if not o['resample'] else t[0] + np.arange(len(whole)) / display_fs
                selected = raw[mask]
                if o['resample']:
                    selected, fs = resample_uniform(selected, fs, o['resample'])
                selected = apply_filter(selected, fs, o['filter'], o['filter_low'], o['filter_high'])
                selected_t = t[mask] if not o['resample'] else t[mask][0] + np.arange(len(selected)) / fs
                f, psd = welch_psd(selected, fs, o['window'], o['segment'], o['overlap'])
                ff, fft = fft_spectrum(selected, fs, o['window'])
                rows.append(dict(index=idx, name=ds.channel_names[idx], whole=whole, whole_t=display_t,
                                 signal=selected, times=selected_t, fs=fs, f=f, psd=psd, ff=ff, fft=fft))
            self.ready.emit(generation, dict(source=str(ds.path.resolve()), file=ds.path.name,
                                             start=low, end=high, rows=rows, options=o))
        except Exception as exc:
            self.failed.emit(generation, str(exc))


class StudioViewBox(pg.ViewBox):
    picked = QtCore.Signal(float, float)
    preview = QtCore.Signal(float, float)

    def __init__(self):
        super().__init__(enableMenu=True)
        self.tool = 'move'

    def mouseDragEvent(self, event, axis=None):
        if self.tool == 'select' and event.button() == QtCore.Qt.LeftButton:
            event.accept()
            a = self.mapSceneToView(event.buttonDownScenePos()).x()
            b = self.mapSceneToView(event.scenePos()).x()
            low, high = sorted((float(a), float(b)))
            (self.picked if event.isFinish() else self.preview).emit(low, high)
            return
        super().mouseDragEvent(event, axis=axis)


class StudioRegion(pg.LinearRegionItem):
    def __init__(self, values, activate, edit, context, **kwargs):
        super().__init__(values, **kwargs)
        self.activate_callback, self.edit_callback, self.context_callback = activate, edit, context

    def mouseClickEvent(self, event):
        if event.button() == QtCore.Qt.RightButton:
            event.accept(); self.activate_callback(); self.context_callback(event.screenPos())
        elif event.button() == QtCore.Qt.LeftButton:
            event.accept(); self.activate_callback()
        else:
            super().mouseClickEvent(event)

    def mouseDoubleClickEvent(self, event):
        event.accept(); self.activate_callback(); self.edit_callback()


class StudioNote(pg.TextItem):
    def __init__(self, text, moved, edit):
        super().__init__(text=text, color='#d07c1c', anchor=(0, 1), fill=pg.mkBrush(255, 255, 255, 190))
        self.moved_callback, self.edit_callback = moved, edit
        self.setFlag(QtWidgets.QGraphicsItem.ItemIsMovable, True)

    def mouseReleaseEvent(self, event):
        super().mouseReleaseEvent(event)
        self.moved_callback(self.pos())

    def mouseDoubleClickEvent(self, event):
        event.accept(); self.edit_callback()


class StudioTable(QtWidgets.QTreeWidget):
    """Flat rows with stable item ownership during background refreshes.

    QTableWidget's virtual accessible cell interfaces on the current Cocoa
    runtime can outlive the cells they describe. A flat tree keeps real rows.
    """
    cellDoubleClicked = QtCore.Signal(int, int)

    def __init__(self, columns):
        super().__init__()
        self.setColumnCount(columns); self.setRootIsDecorated(False); self.setItemsExpandable(False)
        self.setAlternatingRowColors(True)
        self.itemDoubleClicked.connect(lambda item, col:self.cellDoubleClicked.emit(self.indexOfTopLevelItem(item), col))

    def setHorizontalHeaderLabels(self, labels): self.setHeaderLabels(labels)

    def horizontalHeader(self): return self.header()

    def setRowCount(self, count):
        while self.topLevelItemCount() > count: self.takeTopLevelItem(self.topLevelItemCount()-1)
        while self.topLevelItemCount() < count: self.addTopLevelItem(QtWidgets.QTreeWidgetItem(['']*self.columnCount()))

    def currentRow(self): return self.indexOfTopLevelItem(self.currentItem()) if self.currentItem() else -1

    def selectRow(self, row):
        self.clearSelection()
        self.setCurrentItem(self.topLevelItem(row) if row >= 0 else None)
        if row >= 0: self.topLevelItem(row).setSelected(True)


class StudioPages(QtWidgets.QWidget):
    """Page switching through real buttons, without virtual tab children."""
    def __init__(self):
        super().__init__()
        layout=QtWidgets.QVBoxLayout(self); layout.setContentsMargins(0,0,0,0)
        self.buttons_layout=QtWidgets.QHBoxLayout(); layout.addLayout(self.buttons_layout)
        self.stack=QtWidgets.QStackedWidget(); layout.addWidget(self.stack,1)
        self.buttons=[]; self.group=QtWidgets.QButtonGroup(self); self.group.setExclusive(True)

    def addTab(self,page,title):
        index=self.stack.addWidget(page)
        button=QtWidgets.QPushButton(title); button.setCheckable(True)
        button.setToolTip('切换到'+title); self.buttons_layout.addWidget(button)
        self.group.addButton(button); self.buttons.append(button)
        button.clicked.connect(lambda checked=False,i=index:self.setCurrentIndex(i))
        if index==0: button.setChecked(True)
        return index

    def currentIndex(self): return self.stack.currentIndex()

    def setCurrentIndex(self,index):
        self.stack.setCurrentIndex(index)
        if 0<=index<len(self.buttons): self.buttons[index].setChecked(True)


class InteractionStudio(QtWidgets.QMainWindow):
    def __init__(self, owner):
        # A workspace is an independent native window. Retain it explicitly on
        # MainWindow rather than placing a second native window in its AX tree.
        super().__init__()
        self.owner = owner
        self.setWindowTitle('VibrationLab · 图表交互工作台')
        self.resize(1500, 950)
        self.menuBar().setNativeMenuBar(False)
        self.data = None; self.data_generation = -1; self.worker = None; self.generation = 0; self.pending = False
        self.source = ''; self.time_range = None; self.frequency_range = None
        self.active = None; self.drafts = []; self.snapshots = []; self.reference = None
        self.regions = []; self.note_items = []; self.curves = []; self.cursors = []
        self.undo_states = []; self.redo_states = []; self.views = []; self.view_busy = False
        self.drag_origins = {}; self.hidden_curves = set(); self.solo = None
        self.last_hover = None; self.preview_item = None; self.pending_pin = False
        self.cursor_busy = False; self.current_tool = 'move'
        self.timer = QtCore.QTimer(self); self.timer.setSingleShot(True); self.timer.setInterval(180)
        self.timer.timeout.connect(self.start_calculation)
        self._build()

    def _build(self):
        tools = self.addToolBar('图表工具'); tools.setMovable(False)
        self.tool_actions = {}; group = QtGui.QActionGroup(self); group.setExclusive(True)
        for key, name, tip in [('move', '移动', '拖动平移，滚轮缩放。'), ('zoom', '框选缩放', '拖出矩形放大。'),
                               ('select', '选取区间', '在时域或频域图拖出区间；可保留多个选区。'),
                               ('cursor', '双游标', '拖动 A/B 游标吸附数据点；复制读数可用于工程记录。'),
                               ('note', '标注', '点击图中数据点添加备注或峰值标注，双击文字修改。')]:
            action = tools.addAction(name); action.setCheckable(True); action.setToolTip(tip); group.addAction(action)
            action.triggered.connect(lambda checked=False, k=key: self.set_tool(k)); self.tool_actions[key] = action
        self.tool_actions['move'].setChecked(True)
        for name, callback, tip in [('撤销', self.undo, '撤销选区编辑、删除、备注或导出队列修改。'),
                                     ('重做', self.redo, '恢复已撤销的操作。'), ('撤销视图', self.previous_view, '回到上一次坐标范围。'),
                                     ('复位', self.reset_views, '恢复全部工作台图表的自动坐标范围。'),
                                     ('复制读数', self.copy_readout, '复制当前游标或选区测量，包含单位。')]:
            action = tools.addAction(name); action.triggered.connect(callback); action.setToolTip(tip)
            if name == '撤销': action.setShortcut(QtGui.QKeySequence.Undo)
            elif name == '重做': action.setShortcut(QtGui.QKeySequence.Redo)
        self.mode_status = QtWidgets.QLabel('当前：移动'); tools.addWidget(self.mode_status)
        root = QtWidgets.QWidget(); self.setCentralWidget(root); outer = QtWidgets.QVBoxLayout(root)
        settings = QtWidgets.QHBoxLayout(); outer.addLayout(settings)
        self.kind = QtWidgets.QComboBox(); self.kind.addItems(['PSD', 'ASD', 'FFT'])
        self.unit = QtWidgets.QComboBox(); self.unit.addItems(['g', 'm/s²', 'mm/s²']); self.unit.setCurrentText(self.owner.unit.currentText())
        self.scale = QtWidgets.QComboBox(); self.scale.addItems(['线性', '对数频率', '双对数'])
        self.layout_mode = QtWidgets.QComboBox(); self.layout_mode.addItems(['叠加', '按通道分图'])
        self.link = QtWidgets.QComboBox(); self.link.addItems(['统一横轴', '统一纵轴', '统一横纵轴', '独立尺度'])
        self.align = QtWidgets.QComboBox(); self.align.addItems(['原始时间', '各段从零开始'])
        self.snap = QtWidgets.QComboBox(); self.snap.addItems(['数据点', '谱峰'])
        for label, widget in [('频谱', self.kind), ('单位', self.unit), ('坐标', self.scale), ('布局', self.layout_mode), ('尺度', self.link), ('对齐', self.align), ('吸附', self.snap)]:
            settings.addWidget(QtWidgets.QLabel(label)); settings.addWidget(widget)
            widget.setToolTip('只改变工作台显示；处理参数沿用主窗口。' if widget is not self.snap else '谱峰吸附仅作用于频域；时域吸附数据点。')
        peak_settings = QtWidgets.QHBoxLayout(); outer.addLayout(peak_settings)
        self.peak_count = QtWidgets.QSpinBox(); self.peak_count.setRange(1, 100); self.peak_count.setValue(min(100, self.owner.peak_count.value()))
        self.peak_floor = QtWidgets.QDoubleSpinBox(); self.peak_floor.setDecimals(10); self.peak_floor.setRange(0, 1e90)
        self.peak_floor.setToolTip('仅标注不低于此值的谱峰，单位与工作台频谱纵轴一致。')
        peak_settings.addWidget(QtWidgets.QLabel('主峰数量 / 每通道')); peak_settings.addWidget(self.peak_count)
        peak_settings.addWidget(QtWidgets.QLabel('最低峰值')); peak_settings.addWidget(self.peak_floor)
        auto_peaks = QtWidgets.QPushButton('标注主峰'); auto_peaks.clicked.connect(self.annotate_peaks); peak_settings.addWidget(auto_peaks)
        peak_settings.addWidget(QtWidgets.QLabel('拖动仅预览，松开后计算；参考线加粗并使用虚线。')); peak_settings.addStretch()
        self.previous_display_unit = self.unit.currentText(); self.previous_display_kind = self.kind.currentText()
        split = QtWidgets.QSplitter(); outer.addWidget(split, 1)
        plots = QtWidgets.QSplitter(QtCore.Qt.Vertical); split.addWidget(plots)
        self.time_plot = self.new_plot('time'); plots.addWidget(self.time_plot)
        self.plot_tabs = StudioPages(); plots.addWidget(self.plot_tabs)
        self.frequency_scroll = QtWidgets.QScrollArea(); self.frequency_scroll.setWidgetResizable(True)
        self.frequency_host = QtWidgets.QWidget(); self.frequency_layout = QtWidgets.QVBoxLayout(self.frequency_host)
        self.frequency_scroll.setWidget(self.frequency_host); self.plot_tabs.addTab(self.frequency_scroll, '频域联动与对比')
        self.compare_plot = self.new_plot('compare'); self.plot_tabs.addTab(self.compare_plot, '所选时间段对比')
        initial_frequency_plot = self.new_plot('frequency'); self.frequency_layout.addWidget(initial_frequency_plot)
        self.frequency_plots = [initial_frequency_plot]; self.frequency_pool = [initial_frequency_plot]
        self.side = StudioPages(); self.side.setMinimumWidth(320); split.addWidget(self.side); split.setSizes([1120, 380])
        self.selection_table = self.table_tab('选区', ['名称 / 状态', '类型', '范围'], [
            ('新增时间段', lambda: self.new_range('time')), ('新增频段', lambda: self.new_range('frequency')),
            ('精确编辑', self.edit_active), ('保存选区', self.save_active), ('复制选区', self.duplicate_active),
            ('删除选区', self.delete_active)])
        self.selection_table.itemSelectionChanged.connect(self.table_selected)
        self.selection_table.cellDoubleClicked.connect(lambda *_: self.edit_active())
        self.snapshot_table = self.table_tab('对比', ['名称', '范围 / 参数', '参考'], [
            ('锁定当前结果', self.pin), ('设为参考', self.set_reference), ('重命名', self.rename_snapshot),
            ('删除对比', self.delete_snapshot)])
        self.note_table = self.table_tab('标注', ['内容', '图表', '字号'], [
            ('添加备注', self.add_note_dialog), ('编辑', self.edit_selected_note), ('删除', self.delete_note),
            ('自动避让', self.arrange_notes)])
        self.queue_table = self.table_tab('导出', ['任务名称', '时间 (s)', '频段 (Hz)'], [
            ('当前选区加入任务', self.enqueue), ('预览任务曲线', self.preview_task), ('删除任务', self.delete_task),
            ('打开 CSV / 批量图片导出', self.export_queue)])
        self.summary = StudioTable(7); self.summary.setHorizontalHeaderLabels(['结果 / 通道', '主峰 (Hz)', '峰值', '数值单位', '频段 RMS (g)', '相对参考 RMS', '时域 RMS / 峰峰值'])
        self.summary.setEditTriggers(QtWidgets.QAbstractItemView.NoEditTriggers)
        self.summary.setMaximumHeight(150); self.summary.horizontalHeader().setSectionResizeMode(QtWidgets.QHeaderView.ResizeToContents)
        outer.addWidget(self.summary)
        self.readout = QtWidgets.QLabel('导入数据后，在时域框选时间段，频域自动更新。'); self.readout.setWordWrap(True)
        self.readout.setTextInteractionFlags(QtCore.Qt.TextSelectableByMouse); outer.addWidget(self.readout)
        self.include_notes = QtWidgets.QCheckBox('导出图表包含选区、游标和标注'); self.include_notes.setChecked(True)
        footer = QtWidgets.QHBoxLayout(); outer.addLayout(footer); footer.addWidget(self.include_notes)
        for name, callback in [('刷新处理参数', self.refresh), ('保存分析配置', self.owner.save_configuration), ('导出工作台图表', self.export_chart)]:
            button = QtWidgets.QPushButton(name); button.clicked.connect(callback); footer.addWidget(button)
        for combo in (self.kind, self.unit): combo.currentIndexChanged.connect(self.display_changed)
        for combo in (self.scale, self.layout_mode, self.link, self.align): combo.currentIndexChanged.connect(self.render)
        self.statusBar().showMessage('提示：保存分析配置可保留选区、标注与导出任务。对比快照仅保留在本次会话。')

    def table_tab(self, title, headers, buttons):
        page = QtWidgets.QWidget(); layout = QtWidgets.QVBoxLayout(page)
        table = StudioTable(len(headers)); table.setHorizontalHeaderLabels(headers)
        table.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectRows); table.setSelectionMode(QtWidgets.QAbstractItemView.SingleSelection)
        table.setEditTriggers(QtWidgets.QAbstractItemView.NoEditTriggers); table.horizontalHeader().setStretchLastSection(True)
        layout.addWidget(table)
        for name, callback in buttons:
            button = QtWidgets.QPushButton(name); button.clicked.connect(callback); layout.addWidget(button)
            button.setToolTip(name + '；撤销可恢复本次工作台中的数据编辑。')
        self.side.addTab(page, title); return table

    def display_changed(self):
        unit, kind = self.unit.currentText(), self.kind.currentText()
        old_unit, old_kind = self.previous_display_unit, self.previous_display_kind
        value = self.peak_floor.value()
        if kind != old_kind:
            # FFT amplitude and density thresholds are different quantities.
            value = 0.
        elif kind == 'PSD': value = float(convert_acceleration_psd([value], old_unit, unit)[0])
        else: value = float(convert_acceleration([value], old_unit, unit)[0])
        self.peak_floor.setValue(value)
        self.previous_display_unit, self.previous_display_kind = unit, kind
        self.render()

    def new_plot(self, kind):
        view = StudioViewBox(); plot = pg.PlotWidget(viewBox=view); plot.studio_kind = kind
        plot.showGrid(x=True, y=True, alpha=.2); plot.setMinimumHeight(180)
        self.owner.configure_axis_units(plot)
        plot.getViewBox().sigRangeChangedManually.connect(self.record_view)
        view.picked.connect(lambda a, b, p=plot: self.picked(p, a, b))
        view.preview.connect(lambda a, b, p=plot: self.preview_range(p, a, b))
        plot.scene().sigMouseMoved.connect(lambda pos, p=plot: self.hover(p, pos))
        plot.scene().sigMouseClicked.connect(lambda event, p=plot: self.plot_clicked(p, event))
        return plot

    def plots(self):
        return [self.time_plot, self.compare_plot] + self.frequency_plots

    def source_path(self):
        return str(self.owner.current.path.resolve()) if self.owner.current else ''

    def refresh(self):
        if not self.owner.current:
            self.readout.setText('请先在主窗口导入文件并选择通道。'); return
        source = self.source_path()
        if source != self.source:
            self.source = source; self.time_range = None; self.frequency_range = None; self.active = None
            self.undo_states.clear(); self.redo_states.clear(); self.views.clear(); self.hidden_curves.clear()
        elif self.active and not any(self.key(r) == self.active for r in self.records()):
            if self.active[0] == 'time': self.time_range = None
            else: self.frequency_range = None
            self.active = None
        self.generation += 1; self.pending = True; self.timer.start()
        self.refresh_tables()

    def options(self):
        w = self.owner
        return dict(source_unit=w.source_units.get(str(w.current.path), 'm/s²'),
                    fs=w.fs_override.value() or w.current.sampling.sample_rate_hz,
                    resample=w.resample_fs.value(), filter=w.filter_kind.currentText(),
                    filter_low=w.filter_low.value(), filter_high=w.filter_high.value(),
                    window=w.window.currentText(), segment=w.nperseg.value(), overlap=w.overlap.value())

    def start_calculation(self):
        if not self.owner.current: return
        if self.worker is not None and self.worker.isRunning():
            self.worker.requestInterruption(); self.pending = True; return
        self.pending = False
        self.worker = StudioWorker(self.generation, self.owner.current, self.owner.selected_indexes(), self.options(), self.time_range, self)
        self.worker.ready.connect(self.received); self.worker.failed.connect(self.failed)
        self.worker.finished.connect(lambda worker=self.worker:self.finished(worker)); self.worker.start()
        self.statusBar().showMessage('后台计算中…旧曲线保留至新结果就绪；时间段按 [起始,结束) 计算。')

    def received(self, generation, result):
        if generation != self.generation: return
        self.data = result; self.data_generation = generation
        self.render()
        if self.pending_pin:
            self.pending_pin = False; self.pin()
        self.statusBar().showMessage(f"已更新 {result['file']} · {result['start']:.6g}–{result['end']:.6g} s；双击选区可精确编辑。")

    def failed(self, generation, message):
        if generation == self.generation:
            self.pending_pin = False; self.readout.setText('本次计算失败，当前曲线仍为上次成功结果：' + message)

    def finished(self, worker):
        if self.worker is worker: self.worker = None
        worker.deleteLater()
        if self.pending: self.timer.start()

    def ready(self):
        return self.data is not None and self.data_generation == self.generation and self.data['source'] == self.source and not self.pending and not self.timer.isActive() and not (self.worker and self.worker.isRunning())

    def records(self):
        return [r for r in self.owner.saved_selections if r['kind'] == 'frequency' or r['source'] == self.source] + [r for r in self.drafts if r['source'] in ('', self.source)]

    @staticmethod
    def key(record):
        return record['kind'], record['source'], record['name']

    def selected_record(self):
        return next((r for r in self.records() if self.key(r) == self.active), None)

    def checkpoint(self):
        self.undo_states.append(deepcopy(dict(saved=self.owner.saved_selections, drafts=self.drafts, workspace=self.owner.interaction_workspace,
                                              active=self.active, time=self.time_range, frequency=self.frequency_range)))
        self.undo_states = self.undo_states[-50:]; self.redo_states.clear()

    def restore_state(self, state):
        self.owner.saved_selections = state['saved']; self.drafts = state['drafts']; self.owner.interaction_workspace = state['workspace']
        self.active = state['active']; self.time_range = state['time']; self.frequency_range = state['frequency']
        self.refresh()

    def undo(self):
        if not self.undo_states: return
        state = self.undo_states.pop()
        self.redo_states.append(deepcopy(dict(saved=self.owner.saved_selections, drafts=self.drafts, workspace=self.owner.interaction_workspace,
                                              active=self.active, time=self.time_range, frequency=self.frequency_range)))
        self.restore_state(state)

    def redo(self):
        if not self.redo_states: return
        state = self.redo_states.pop()
        self.undo_states.append(deepcopy(dict(saved=self.owner.saved_selections, drafts=self.drafts, workspace=self.owner.interaction_workspace,
                                              active=self.active, time=self.time_range, frequency=self.frequency_range)))
        self.restore_state(state)

    def fill_table(self, table, rows):
        blocker = QtCore.QSignalBlocker(table); table.setRowCount(len(rows))
        for row, values in enumerate(rows):
            for col, value in enumerate(values):
                table.topLevelItem(row).setText(col,str(value))
        del blocker

    def refresh_tables(self):
        records = self.records()
        self.fill_table(self.selection_table, [(r['name'] + (' · 草稿' if r in self.drafts else ' · 已保存'),
                        '时间段 (s)' if r['kind'] == 'time' else '频段 (Hz)', f"{r['low']:.6g}–{r['high']:.6g}") for r in records])
        if self.active:
            row = next((i for i, r in enumerate(records) if self.key(r) == self.active), -1)
            blocker = QtCore.QSignalBlocker(self.selection_table); self.selection_table.selectRow(row); del blocker
        self.fill_table(self.snapshot_table, [(s['name'], f"{s['file']} · {s['start']:.5g}–{s['end']:.5g} s · {s['options']['filter']}", '参考' if s['id'] == self.reference else '') for s in self.snapshots])
        self.fill_table(self.note_table, [(n['text'], n['kind'], n['size']) for n in self.visible_notes()])
        self.fill_table(self.queue_table, [(q['name'], f"{q['start']:g}–{q['end']:g}", f"{q['low']:g}–{q['high'] or '全频'}") for q in self.tasks()])

    def table_selected(self):
        row = self.selection_table.currentRow(); records = self.records()
        if 0 <= row < len(records): self.activate(records[row], locate=True)

    def activate(self, record, locate=False):
        self.active = self.key(record)
        if record['kind'] == 'time':
            if self.time_range != (record['low'], record['high']):
                self.time_range = record['low'], record['high']; self.refresh()
        else:
            self.frequency_range = record['low'], record['high']; self.update_summary()
        self.refresh_tables(); self.draw_regions()
        if locate:
            targets = [self.time_plot] if record['kind'] == 'time' else self.frequency_plots
            for plot in targets:
                plot.setXRange(self.coord(plot, record['low']), self.coord(plot, record['high']), padding=.1)

    def new_range(self, kind, bounds=None):
        if not self.owner.current: return
        if bounds is None:
            if kind == 'time':
                t = self.owner.current.time_s; lo, hi = float(t[0]), float(t[-1] + self.owner.current.sampling.median_dt_s)
            else:
                lo, hi = 0., float((self.options()['resample'] or self.options()['fs']) / 2)
            bounds = lo + (hi-lo)*.25, lo + (hi-lo)*.75
        lo, hi = bounds
        maximum = float(self.owner.current.time_s[-1] + self.owner.current.sampling.median_dt_s) if kind == 'time' else (self.options()['resample'] or self.options()['fs']) / 2
        lo, hi = max(0., lo), min(maximum, hi)
        if hi <= lo: return
        prefix = '时间段' if kind == 'time' else '频段'; i = 1
        while any(r['name'] == f'{prefix}{i}' and r['kind'] == kind for r in self.records()): i += 1
        self.checkpoint()
        record = dict(name=f'{prefix}{i}', kind=kind, source=self.source if kind == 'time' else '', low=lo, high=hi,
                      colour=COLOURS[len(self.records()) % len(COLOURS)])
        self.drafts.append(record); self.activate(record)

    def picked(self, plot, low, high):
        self.clear_preview()
        if plot.studio_kind == 'compare': return
        self.new_range('time' if plot.studio_kind == 'time' else 'frequency', (self.coord(plot, low, inverse=True), self.coord(plot, high, inverse=True)))

    def preview_range(self, plot, low, high):
        self.clear_preview()
        self.preview_item = plot, pg.LinearRegionItem((low, high), movable=False, brush=pg.mkBrush(60, 145, 220, 45))
        plot.addItem(self.preview_item[1])
        self.readout.setText(f"选区预览 {self.coord(plot, low, inverse=True):.6g}–{self.coord(plot, high, inverse=True):.6g} {'s' if plot.studio_kind == 'time' else 'Hz'}；松开鼠标后计算。")

    def clear_preview(self):
        if self.preview_item:
            self.preview_item[0].removeItem(self.preview_item[1]); self.preview_item = None

    @staticmethod
    def coord(plot, value, axis=0, inverse=False):
        ctrl = plot.getPlotItem().ctrl
        logarithmic = ctrl.logXCheck.isChecked() if axis == 0 else ctrl.logYCheck.isChecked()
        if not logarithmic: return float(value)
        return float(10.**value if inverse else np.log10(max(float(value), np.finfo(float).tiny)))

    def draw_regions(self):
        for plot, region, label in self.regions:
            plot.removeItem(region)
        self.regions = []
        for n, record in enumerate(self.records()):
            targets = [self.time_plot] if record['kind'] == 'time' else self.frequency_plots
            for plot in targets:
                maximum = self.owner.current.time_s[-1] + self.owner.current.sampling.median_dt_s if record['kind'] == 'time' and self.owner.current else (self.data['rows'][0]['f'][-1] if self.data and self.data['rows'] else 0)
                if record['high'] > maximum + 1e-8: continue
                colour = record.get('colour', COLOURS[n % len(COLOURS)])
                active = self.key(record) == self.active
                region = StudioRegion((self.coord(plot, record['low']), self.coord(plot, record['high'])),
                    lambda r=record: self.activate(r), self.edit_active, self.region_menu,
                    movable=self.current_tool == 'move',
                    brush=pg.mkBrush(QtGui.QColor(colour).red(), QtGui.QColor(colour).green(), QtGui.QColor(colour).blue(), 55 if active else 20),
                    pen=pg.mkPen(colour, width=2 if active else 1))
                region.setZValue(5 if active else 1); plot.addItem(region)
                pg.InfLineLabel(region.lines[0], record['name'].replace('{','{{').replace('}','}}'), position=.95 - (n % 5)*.12, color=colour)
                self.regions.append((plot, region, None))
                region.sigRegionChanged.connect(lambda item, p=plot: self.region_preview(p, item))
                region.sigRegionChangeFinished.connect(lambda item, p=plot, r=record: self.finish_region(p, item, r))

    def region_preview(self, plot, region):
        low, high = (self.coord(plot, v, inverse=True) for v in region.getRegion())
        self.readout.setText(f"调整预览 {low:.6g}–{high:.6g} {'s' if plot.studio_kind == 'time' else 'Hz'}；松开后应用。")

    def finish_region(self, plot, region, record):
        low, high = (self.coord(plot, v, inverse=True) for v in region.getRegion())
        replacement = dict(record, low=low, high=high)
        self.drag_origins.pop(id(region), None)
        if np.allclose([low, high], [record['low'], record['high']], rtol=0, atol=1e-10): return
        self.replace_record(record, replacement)

    def region_menu(self, position):
        menu = QtWidgets.QMenu(self)
        for name, callback in [('精确编辑 / 重命名', self.edit_active), ('保存 / 更新选区', self.save_active),
                               ('复制选区', self.duplicate_active), ('加入导出任务', self.enqueue), ('删除选区', self.delete_active)]:
            menu.addAction(name, callback)
        menu.exec(QtCore.QPoint(int(position.x()), int(position.y())))

    def replace_record(self, original, replacement, confirm=True):
        try:
            replacement = validate_selections([replacement])[0]
            if replacement['kind'] == 'time' and self.owner.current:
                maximum = float(self.owner.current.time_s[-1] + self.owner.current.sampling.median_dt_s)
            else: maximum = (self.options()['resample'] or self.options()['fs']) / 2
            if replacement['high'] > maximum + 1e-8: raise ValueError('选区超出当前数据范围')
            all_records = [r for r in self.records() if r is not original]
            if any(self.key(r) == self.key(replacement) for r in all_records): raise ValueError('名称已存在，请使用其他名称')
            saved = original in self.owner.saved_selections
            if saved and confirm and QtWidgets.QMessageBox.question(self, '更新已保存选区', '此修改将更新已保存记录，是否应用？', QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No, QtWidgets.QMessageBox.No) != QtWidgets.QMessageBox.Yes:
                self.draw_regions(); return
            self.checkpoint()
            target = self.owner.saved_selections if saved else self.drafts
            target[target.index(original)] = replacement
            self.activate(replacement); self.render()
        except Exception as exc:
            QtWidgets.QMessageBox.warning(self, '选区编辑', str(exc)); self.draw_regions()

    def edit_active(self):
        record = self.selected_record()
        if not record: return
        dialog = QtWidgets.QDialog(self); dialog.setWindowTitle('精确编辑选区'); layout = QtWidgets.QFormLayout(dialog)
        name = QtWidgets.QLineEdit(record['name']); layout.addRow('名称', name)
        low, high = QtWidgets.QDoubleSpinBox(), QtWidgets.QDoubleSpinBox()
        for control, key in [(low, 'low'), (high, 'high')]:
            control.setDecimals(9); control.setRange(0, 1e12); control.setValue(record[key]); control.setSuffix(' s' if record['kind'] == 'time' else ' Hz')
            layout.addRow('下限' if key == 'low' else '上限', control)
        colour = QtWidgets.QPushButton('选择颜色'); selected_colour = [record.get('colour', COLOURS[0])]
        def choose():
            chosen = QtWidgets.QColorDialog.getColor(QtGui.QColor(selected_colour[0]), dialog)
            if chosen.isValid(): selected_colour[0] = chosen.name(); colour.setText(chosen.name())
        colour.clicked.connect(choose); layout.addRow('选区颜色', colour)
        buttons = QtWidgets.QDialogButtonBox(QtWidgets.QDialogButtonBox.Ok | QtWidgets.QDialogButtonBox.Cancel)
        buttons.accepted.connect(dialog.accept); buttons.rejected.connect(dialog.reject); layout.addRow(buttons)
        if dialog.exec() == QtWidgets.QDialog.Accepted:
            self.replace_record(record, dict(record, name=name.text().strip(), low=low.value(), high=high.value(), colour=selected_colour[0]))

    def save_active(self):
        record = self.selected_record()
        if not record: return
        if record in self.owner.saved_selections:
            self.statusBar().showMessage('当前选区已在库中；拖动或精确编辑可更新。永久保留请保存分析配置。'); return
        name, ok = QtWidgets.QInputDialog.getText(self, '保存选区', '选区名称：', text=record['name'])
        if not ok: return
        try:
            replacement = validate_selections([dict(record, name=name)])[0]
            existing = next((r for r in self.owner.saved_selections if self.key(r) == self.key(replacement)), None)
            if existing and QtWidgets.QMessageBox.question(self, '覆盖选区', '已有同名选区，是否覆盖？', QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No, QtWidgets.QMessageBox.No) != QtWidgets.QMessageBox.Yes: return
            self.checkpoint()
            if existing: self.owner.saved_selections.remove(existing)
            self.owner.saved_selections.append(replacement); self.drafts.remove(record); self.active = self.key(replacement)
            self.refresh_tables(); self.draw_regions()
            self.statusBar().showMessage('已保存到选区库；永久保留请保存分析配置。')
        except Exception as exc: QtWidgets.QMessageBox.warning(self, '保存选区', str(exc))

    def duplicate_active(self):
        record = self.selected_record()
        if not record: return
        self.checkpoint(); name = record['name'] + ' 副本'; i = 2
        while any(r['name'] == name and r['kind'] == record['kind'] for r in self.records()): name = record['name'] + f' 副本{i}'; i += 1
        replacement = dict(record, name=name); self.drafts.append(replacement); self.activate(replacement)

    def delete_active(self):
        record = self.selected_record()
        if not record: return
        self.checkpoint()
        if record in self.owner.saved_selections: self.owner.delete_saved_selections([record])
        else: self.drafts.remove(record)
        if record['kind'] == 'time': self.time_range = None
        else: self.frequency_range = None
        self.active = None; self.refresh(); self.draw_regions()

    def spectrum(self, row):
        unit = self.unit.currentText(); kind = self.kind.currentText()
        if kind == 'FFT': return row['ff'], convert_acceleration(row['fft'], 'm/s²', unit), unit
        psd = convert_acceleration_psd(row['psd'], 'm/s²', unit)
        return row['f'], np.sqrt(np.maximum(psd, 0)) if kind == 'ASD' else psd, unit+'/√Hz' if kind == 'ASD' else f'({unit})²/Hz'

    def results(self):
        current = [dict(self.data, id='current', name='当前选区')] if self.data and self.data['source'] == self.source else []
        return current + self.snapshots

    def render(self, *_):
        if not self.data or self.data['source'] != self.source: return
        self.view_busy = True
        try:
            self.clear_preview(); self.regions = []; self.cursors = []; self.note_items = []; self.curves = []
            self.time_plot.clear(); self.compare_plot.clear()
            results = self.results()
            channels = list(dict.fromkeys((s['source'], row['index']) for s in results for row in s['rows']))
            groups = channels if self.layout_mode.currentIndex() else [None]
            while len(self.frequency_pool) < len(groups):
                plot = self.new_plot('frequency'); self.frequency_layout.addWidget(plot); self.frequency_pool.append(plot)
            self.frequency_plots = self.frequency_pool[:len(groups)]
            for index, plot in enumerate(self.frequency_pool):
                plot.clear(); plot.setXLink(None); plot.setYLink(None); plot.setVisible(index < len(groups))
            for channel, plot in zip(groups, self.frequency_plots):
                plot.channel_key = channel
                plot.setLogMode(x=self.scale.currentIndex() > 0, y=self.scale.currentIndex() == 2)
                plot.setLabel('bottom', '频率', units='Hz'); plot.setLabel('left', self.kind.currentText(), units=self.spectrum(self.data['rows'][0])[2] if self.data['rows'] else '')
            unit = self.unit.currentText()
            self.time_plot.setLabel('bottom', '文件时间', units='s'); self.time_plot.setLabel('left', '加速度', units=unit)
            self.compare_plot.setLabel('bottom', self.align.currentText(), units='s'); self.compare_plot.setLabel('left', '加速度', units=unit)
            for n, row in enumerate(self.data['rows']):
                self.add_curve(self.time_plot, row['whole_t'], convert_acceleration(row['whole'], 'm/s²', unit), row['name'], COLOURS[n % len(COLOURS)], ('context', self.source, row['index']), row, self.data)
            for n, result in enumerate(results):
                for j, row in enumerate(result['rows']):
                    colour = COLOURS[(n * max(1, len(self.data['rows'])) + j) % len(COLOURS)]
                    title = f"{result['name']} / {row['name']}"
                    x, y, _ = self.spectrum(row)
                    target = next(p for p in self.frequency_plots if p.channel_key is None or p.channel_key == (result['source'], row['index']))
                    self.add_curve(target, x, y, title, colour, (result['id'], result['source'], row['index']), row, result)
                    times = row['times'] - row['times'][0] if self.align.currentIndex() else row['times']
                    self.add_curve(self.compare_plot, times, convert_acceleration(row['signal'], 'm/s²', unit), title, colour, ('compare', result['id'], row['index']), row, result)
            if len(self.frequency_plots) > 1:
                for plot in self.frequency_plots[1:]:
                    if self.link.currentIndex() in (0, 2): plot.setXLink(self.frequency_plots[0])
                    if self.link.currentIndex() in (1, 2): plot.setYLink(self.frequency_plots[0])
            self.draw_regions(); self.draw_notes(); self.refresh_tables(); self.update_summary()
            self.peak_floor.setSuffix(' ' + self.spectrum(self.data['rows'][0])[2] if self.data['rows'] else '')
            dark = self.owner.theme.currentText() in ('深色', '深蓝', '高对比度')
            for plot in self.plots():
                plot.setBackground('#20242a' if dark else '#ffffff')
                for axis in ('bottom', 'left'): plot.getAxis(axis).setTextPen('#eeeeee' if dark else '#20242a')
                plot.enableAutoRange()
            self.set_tool(self.current_tool)
            self.views = [deepcopy([p.getViewBox().viewRange() for p in self.plots()])]
        except Exception as exc:
            self.data_generation = -1
            self.readout.setText('图表显示失败，请刷新处理参数后重试：' + str(exc))
        finally: self.view_busy = False

    def add_curve(self, plot, x, y, name, colour, key, row, result):
        reference = result.get('id') == self.reference
        curve = plot.plot(x, y, name=name, pen=pg.mkPen(colour, width=2.7 if reference else 1.3,
                          style=QtCore.Qt.DashLine if reference else QtCore.Qt.SolidLine))
        curve.setDownsampling(auto=True, method='peak'); curve.setClipToView(True)
        curve.curve.setClickable(True, width=10)
        curve.sigClicked.connect(lambda selected, *_: self.highlight(selected))
        self.curves.append(dict(plot=plot, item=curve, key=key, row=row, result=result, x=np.asarray(x), y=np.asarray(y), name=name))
        legend = plot.getPlotItem().legend or plot.addLegend(offset=(10, 10))
        # addLegend after plot() needs one explicit item for the first curve.
        if not any(sample.item is curve for sample, _ in legend.items): legend.addItem(curve, name)
        for sample, label in legend.items:
            if sample.item is curve:
                label.setToolTip('单击名称：显示/隐藏；双击：单独查看；再次双击：恢复全部。')
                label.mouseClickEvent = lambda event, k=key: self.legend_click(event, k)
                label.mouseDoubleClickEvent = lambda event, k=key: self.legend_solo(event, k)
        curve.setVisible(key not in self.hidden_curves and (self.solo is None or self.solo == key))

    def annotate_peaks(self):
        if not self.ready():
            self.statusBar().showMessage('请等待频谱更新后标注主峰。'); return
        notes = []
        for row in self.data['rows']:
            f, y, unit = self.spectrum(row)
            for frequency, value in find_spectral_peaks(f, y, min_distance_hz=self.owner.peak_distance.value(),
                    limit=self.peak_count.value(), minimum_value=self.peak_floor.value()):
                text = f"{row['name']} · {frequency:.6g} Hz\n{value:.6g} {unit}"
                if any(n['text'] == text and n['spectrum'] == self.kind.currentText() for n in self.displayed_notes()): continue
                notes.append(dict(id=uuid.uuid4().hex, source=self.source, kind='frequency', text=text,
                    x=frequency, y=value, size=10, unit=self.unit.currentText(), spectrum=self.kind.currentText(),
                    start=self.data['start'], end=self.data['end']))
        if notes:
            self.checkpoint(); self.owner.interaction_workspace['notes'].extend(notes); self.draw_notes(); self.refresh_tables()
        self.statusBar().showMessage(f'新增 {len(notes)} 个主峰标注；可用“自动避让”整理，或拖动、双击编辑。')

    def legend_click(self, event, key):
        event.accept()
        if key in self.hidden_curves: self.hidden_curves.remove(key)
        else: self.hidden_curves.add(key)
        self.apply_visibility()

    def legend_solo(self, event, key):
        event.accept(); self.solo = None if self.solo == key else key; self.apply_visibility()

    def apply_visibility(self):
        for entry in self.curves:
            entry['item'].setVisible(entry['key'] not in self.hidden_curves and (self.solo is None or entry['key'] == self.solo))

    def highlight(self, curve):
        for entry in self.curves: entry['item'].setOpacity(1 if entry['item'] is curve else .35)
        entry = next(e for e in self.curves if e['item'] is curve)
        self.readout.setText(f"曲线：{entry['result']['file']} / {entry['row']['name']} · {entry['result']['start']:.6g}–{entry['result']['end']:.6g} s · {self.unit.currentText()}；点击图例可隐藏或单独查看。")

    def hover(self, plot, pos):
        if not plot.sceneBoundingRect().contains(pos): return
        point = plot.getViewBox().mapSceneToView(pos); x = self.coord(plot, point.x(), inverse=True)
        entries = [e for e in self.curves if e['plot'] is plot and e['item'].isVisible()]
        if not entries: return
        readouts = []
        for entry in entries:
            i = self.nearest(entry['x'], x)
            readouts.append(f"{entry['name']}: {entry['y'][i]:.7g} {self.axis_unit(plot)}")
        self.last_hover = plot, x, self.coord(plot, point.y(), 1, inverse=True)
        if self.current_tool != 'cursor': self.readout.setText(f"{x:.7g} {'Hz' if plot.studio_kind == 'frequency' else 's'} | " + '；'.join(readouts))

    @staticmethod
    def nearest(axis, x):
        index = int(np.searchsorted(axis, x)); index = max(0, min(index, len(axis)-1))
        if index > 0 and abs(axis[index-1]-x) < abs(axis[index]-x): index -= 1
        return index

    def axis_unit(self, plot):
        return self.spectrum(self.data['rows'][0])[2] if plot.studio_kind == 'frequency' and self.data and self.data['rows'] else self.unit.currentText()

    def plot_clicked(self, plot, event):
        if self.current_tool != 'note' or event.button() != QtCore.Qt.LeftButton or not plot.sceneBoundingRect().contains(event.scenePos()): return
        if plot.studio_kind == 'compare':
            self.statusBar().showMessage('请在上方时域或频域图添加持久标注。'); return
        point = plot.getViewBox().mapSceneToView(event.scenePos())
        x = self.coord(plot, point.x(), inverse=True)
        entries = [e for e in self.curves if e['plot'] is plot and e['item'].isVisible()]
        if not entries: return
        entry = min(entries, key=lambda e: abs(self.coord(plot, e['y'][self.nearest(e['x'], x)], 1)-point.y()))
        if plot.studio_kind == 'frequency':
            from scipy.signal import find_peaks
            peaks, _ = find_peaks(entry['y'])
            idx = int(peaks[np.argmin(abs(entry['x'][peaks]-x))]) if len(peaks) else self.nearest(entry['x'], x)
        else: idx = self.nearest(entry['x'], x)
        x, y = float(entry['x'][idx]), float(entry['y'][idx])
        text = f"{entry['name']}\n{x:.6g} {'Hz' if plot.studio_kind == 'frequency' else 's'}, {y:.6g} {self.axis_unit(plot)}"
        self.add_note(plot, x, y, text)

    def set_tool(self, key):
        self.current_tool = key; self.tool_actions[key].setChecked(True)
        self.mode_status.setText('当前：' + self.tool_actions[key].text())
        for plot in self.plots():
            view = plot.getViewBox(); view.tool = key
            view.setMouseMode(pg.ViewBox.RectMode if key == 'zoom' else pg.ViewBox.PanMode)
        for _, region, _ in self.regions: region.setMovable(key == 'move')
        for plot, _, line in self.cursors: plot.removeItem(line)
        self.cursors = []
        if key == 'cursor':
            for plot in self.plots():
                lo, hi = plot.getViewBox().viewRange()[0]
                for label, fraction, colour in [('A', .33, '#d89a00'), ('B', .67, '#d24c9c')]:
                    line = pg.InfiniteLine(lo+(hi-lo)*fraction, angle=90, movable=True, label=label, pen=pg.mkPen(colour, width=2))
                    plot.addItem(line); self.cursors.append((plot, label, line))
                    line.sigPositionChanged.connect(lambda item, p=plot: self.cursor_changed(p, item))

    def cursor_changed(self, plot, line):
        if self.cursor_busy: return
        entries = [e for e in self.curves if e['plot'] is plot and e['item'].isVisible()]
        if not entries: return
        self.cursor_busy = True
        try:
            x = self.coord(plot, line.value(), inverse=True); first = entries[0]; candidates = first['x']
            if self.snap.currentIndex() and plot.studio_kind == 'frequency':
                from scipy.signal import find_peaks
                indexes, _ = find_peaks(first['y'])
                if len(indexes): candidates = candidates[indexes]
            x = float(candidates[self.nearest(candidates, x)])
            name = next(n for p, n, l in self.cursors if l is line)
            for target, label, cursor in self.cursors:
                if label == name and target.studio_kind == plot.studio_kind: cursor.setValue(self.coord(target, x))
            positions = {n:self.coord(p, l.value(), inverse=True) for p, n, l in self.cursors if p is plot}
            a, b = positions['A'], positions['B']; low, high = sorted((a, b)); unit = self.axis_unit(plot)
            details = [f"A={a:.7g}, B={b:.7g}, Δ={b-a:.7g} {'Hz' if plot.studio_kind == 'frequency' else 's'}"]
            for entry in entries:
                axis, values = entry['x'], entry['y']; ya, yb = values[self.nearest(axis,a)], values[self.nearest(axis,b)]
                text = f"{entry['name']}: A={ya:.7g}, B={yb:.7g}, Δ={yb-ya:.7g} {unit}"
                if plot.studio_kind != 'frequency':
                    selected = values[(axis>=low)&(axis<=high)]
                    if len(selected): text += f" | 区间 RMS={np.sqrt(np.mean(selected**2)):.7g} {unit}，峰峰值={np.ptp(selected):.7g} {unit}"
                elif self.kind.currentText() in ('PSD', 'ASD'):
                    row = entry['row']; band_low, band_high = max(low,float(row['f'][0])), min(high,float(row['f'][-1]))
                    if band_low < band_high:
                        _, rms = band_rms_from_psd(row['f'], row['psd'], band_low, band_high)
                        text += f" | 频段 RMS={float(convert_acceleration([rms],'m/s²','g')[0]):.7g} g"
                details.append(text)
            self.readout.setText('\n'.join(details))
        finally: self.cursor_busy = False

    def update_summary(self):
        if not self.data: return
        rows = []; band = self.frequency_range
        reference_values = {}
        reference = next((s for s in self.snapshots if s['id'] == self.reference), None)
        def rms_for(row):
            low, high = band or (0., 0.)
            if high > row['f'][-1] or low >= row['f'][-1]: return None
            _, rms = band_rms_from_psd(row['f'], row['psd'], low, high)
            return float(convert_acceleration([rms], 'm/s²', 'g')[0])
        if reference:
            reference_values = {(reference['source'], r['index']):rms_for(r) for r in reference['rows']}
        for result in self.results():
            for row in result['rows']:
                f, y, unit = self.spectrum(row)
                peaks = find_spectral_peaks(f, y, limit=1)
                hz, peak = peaks[0] if peaks else (float(f[np.argmax(y)]), float(np.max(y)))
                rms = rms_for(row); base = reference_values.get((result['source'], row['index']))
                difference = f'{(rms/base-1)*100:+.3g}%' if rms is not None and base else '—'
                stats = time_statistics(convert_acceleration(row['signal'], 'm/s²', self.unit.currentText()))
                rows.append((f"{result['name']} / {row['name']}", f'{hz:.7g}', f'{peak:.7g}', unit,
                             f'{rms:.7g}' if rms is not None else '频段超范围', difference,
                             f"{stats['rms']:.7g} / {stats['peak_to_peak']:.7g} {self.unit.currentText()}"))
        self.fill_table(self.summary, rows)

    def pin(self):
        if not self.ready():
            self.statusBar().showMessage('当前结果仍在更新，请计算完成后锁定。'); return
        name, ok = QtWidgets.QInputDialog.getText(self, '锁定当前结果', '对比结果名称：', text=f'对比{len(self.snapshots)+1}')
        if not ok or not name.strip(): return
        if len(self.snapshots) >= 12:
            QtWidgets.QMessageBox.information(self, '对比数量', '最多保留 12 组结果，请先删除不需要的快照。'); return
        snapshot = dict(self.data, id=uuid.uuid4().hex, name=name.strip())
        # Worker arrays are immutable after delivery; retaining them avoids copying long records.
        self.snapshots.append(snapshot); self.render()

    def set_reference(self):
        row = self.snapshot_table.currentRow()
        if 0 <= row < len(self.snapshots): self.reference = self.snapshots[row]['id']; self.render()

    def rename_snapshot(self):
        row = self.snapshot_table.currentRow()
        if not 0 <= row < len(self.snapshots): return
        snapshot = self.snapshots[row]; text, ok = QtWidgets.QInputDialog.getText(self, '重命名对比', '名称：', text=snapshot['name'])
        if ok and text.strip(): snapshot['name'] = text.strip(); self.render()

    def delete_snapshot(self):
        row = self.snapshot_table.currentRow()
        if 0 <= row < len(self.snapshots):
            removed = self.snapshots.pop(row)
            if removed['id'] == self.reference: self.reference = None
            self.render()

    def visible_notes(self):
        return [n for n in self.owner.interaction_workspace['notes'] if n['source'] == self.source]

    def displayed_notes(self):
        """Annotations belonging to the current spectrum and time interval.

        The management table intentionally lists all annotations for this file;
        chart operations must only change annotations currently on the chart.
        """
        return [n for n in self.visible_notes()
                if n['kind'] == 'time' or
                (n['spectrum'] == self.kind.currentText() and
                 ('start' not in n or self.data is None or
                  np.allclose([n['start'], n['end']],
                              [self.data['start'], self.data['end']], rtol=0, atol=1e-8)))]

    def add_note_dialog(self):
        if not self.data: return
        plot = self.time_plot; ranges = plot.getViewBox().viewRange()
        self.add_note(plot, float(np.mean(ranges[0])), float(np.mean(ranges[1])), '工程备注')

    def add_note(self, plot, x, y, text):
        note = dict(id=uuid.uuid4().hex, source=self.source, kind='time' if plot.studio_kind == 'time' else 'frequency',
                    text=text, x=x, y=y, size=11, unit=self.unit.currentText(), spectrum=self.kind.currentText())
        if note['kind'] == 'frequency' and self.data: note.update(start=self.data['start'], end=self.data['end'])
        self.edit_note(note, new=True)

    def edit_selected_note(self):
        row = self.note_table.currentRow(); notes = self.visible_notes()
        if 0 <= row < len(notes): self.edit_note(notes[row])

    def edit_note(self, note, new=False):
        dialog = QtWidgets.QDialog(self); dialog.setWindowTitle('标注内容与字体'); form = QtWidgets.QFormLayout(dialog)
        text = QtWidgets.QPlainTextEdit(note['text']); form.addRow('内容（记录时的单位保留在文字中）', text)
        size = QtWidgets.QSpinBox(); size.setRange(7, 32); size.setValue(note['size']); form.addRow('字号', size)
        buttons = QtWidgets.QDialogButtonBox(QtWidgets.QDialogButtonBox.Ok | QtWidgets.QDialogButtonBox.Cancel)
        buttons.accepted.connect(dialog.accept); buttons.rejected.connect(dialog.reject); form.addRow(buttons)
        if dialog.exec() != QtWidgets.QDialog.Accepted or not text.toPlainText().strip(): return
        self.checkpoint()
        if new: self.owner.interaction_workspace['notes'].append(note)
        note['text'] = text.toPlainText().strip(); note['size'] = size.value(); self.draw_notes(); self.refresh_tables()

    def draw_notes(self):
        for plot, item in self.note_items: plot.removeItem(item)
        self.note_items = []
        for note in self.displayed_notes():
            targets = [self.time_plot] if note['kind'] == 'time' else self.frequency_plots[:1]
            for plot in targets:
                y = note['y']
                if note['kind'] == 'frequency' and note['spectrum'] == 'PSD': y = float(convert_acceleration_psd([y], note['unit'], self.unit.currentText())[0])
                else: y = float(convert_acceleration([y], note['unit'], self.unit.currentText())[0])
                item = StudioNote(note['text'], lambda pos, n=note, p=plot: self.move_note(n, p, pos), lambda n=note: self.edit_note(n))
                font = QtGui.QFont(); font.setPointSize(note['size']); item.setFont(font)
                item.setPos(self.coord(plot, note['x']), self.coord(plot, y, 1)); plot.addItem(item); self.note_items.append((plot, item))

    def move_note(self, note, plot, pos, checkpoint=True):
        if checkpoint: self.checkpoint()
        note['x'] = self.coord(plot, pos.x(), inverse=True); y = self.coord(plot, pos.y(), 1, inverse=True)
        if note['kind'] == 'frequency' and note['spectrum'] == 'PSD': y = float(convert_acceleration_psd([y], self.unit.currentText(), note['unit'])[0])
        else: y = float(convert_acceleration([y], self.unit.currentText(), note['unit'])[0])
        note['y'] = y

    def delete_note(self):
        row = self.note_table.currentRow(); notes = self.visible_notes()
        if 0 <= row < len(notes):
            self.checkpoint(); self.owner.interaction_workspace['notes'].remove(notes[row]); self.draw_notes(); self.refresh_tables()

    def arrange_notes(self):
        if not self.note_items: return
        self.checkpoint()
        for kind, plot in [('time', self.time_plot), ('frequency', self.frequency_plots[0] if self.frequency_plots else None)]:
            if plot is None: continue
            notes = [n for n in self.displayed_notes() if n['kind'] == kind]
            (x0, x1), (y0, y1) = plot.getViewBox().viewRange()
            for i, note in enumerate(notes):
                x = x0+(x1-x0)*(.03 + (i % 3)*.32); y = y1-(y1-y0)*(.08 + (i // 3)*.16)
                self.move_note(note, plot, QtCore.QPointF(x, y), checkpoint=False)
        self.draw_notes()

    def tasks(self):
        return [q for q in self.owner.interaction_workspace['queue'] if q['source'] == self.source]

    def enqueue(self):
        if not self.ready():
            self.statusBar().showMessage('请等待当前选区计算完成，再加入导出任务。'); return
        time_record = next((r for r in self.records() if r['kind'] == 'time' and self.time_range == (r['low'], r['high'])), None)
        frequency_record = next((r for r in self.records() if r['kind'] == 'frequency' and self.frequency_range == (r['low'], r['high'])), None)
        default = ' / '.join(r['name'] for r in (time_record, frequency_record) if r) or f'任务{len(self.tasks())+1}'
        name, ok = QtWidgets.QInputDialog.getText(self, '加入导出任务', '任务名称：', text=default)
        if not ok or not name.strip(): return
        if any(q['name'] == name.strip() for q in self.tasks()):
            QtWidgets.QMessageBox.warning(self, '任务名称重复', '请使用不同的任务名称。'); return
        low, high = self.frequency_range or (0., 0.)
        if self.data['rows'] and (low >= self.data['rows'][0]['f'][-1] or high > self.data['rows'][0]['f'][-1]):
            QtWidgets.QMessageBox.warning(self, '积分范围', '当前频段超出数据范围。'); return
        self.checkpoint(); self.owner.interaction_workspace['queue'].append(dict(name=name.strip(), source=self.source,
                   start=self.data['start'], end=self.data['end'], low=low, high=high))
        self.refresh_tables(); self.side.setCurrentIndex(3)
        self.statusBar().showMessage('任务已保存数值范围。导出时使用主窗口当前通道与处理参数，可在导出设置复核。')

    def preview_task(self):
        row = self.queue_table.currentRow(); tasks = self.tasks()
        if not 0 <= row < len(tasks): return
        task = tasks[row]; self.time_range = task['start'], task['end']; self.frequency_range = (task['low'], task['high'])
        self.refresh(); self.plot_tabs.setCurrentIndex(0)

    def delete_task(self):
        row = self.queue_table.currentRow(); tasks = self.tasks()
        if 0 <= row < len(tasks):
            self.checkpoint(); self.owner.interaction_workspace['queue'].remove(tasks[row]); self.refresh_tables()

    def export_queue(self):
        if not self.tasks():
            self.statusBar().showMessage('请先将选区加入导出任务。'); return
        self.owner.export_configured(definitions=[{k:q[k] for k in ('name', 'start', 'end', 'low', 'high')} for q in self.tasks()], output_unit=self.unit.currentText(), rms_default=True)

    def copy_readout(self):
        QtWidgets.QApplication.clipboard().setText(self.readout.text()); self.statusBar().showMessage('读数已复制，包含单位。')

    def record_view(self, *_):
        if self.view_busy: return
        ranges = [p.getViewBox().viewRange() for p in self.plots()]
        if not self.views or ranges != self.views[-1]: self.views.append(deepcopy(ranges))
        self.views = self.views[-40:]

    def previous_view(self):
        if len(self.views) < 2: return
        self.views.pop(); self.view_busy = True
        try:
            for plot, ranges in zip(self.plots(), self.views[-1]): plot.setRange(xRange=ranges[0], yRange=ranges[1], padding=0)
        finally: self.view_busy = False

    def reset_views(self):
        self.record_view()
        for plot in self.plots(): plot.autoRange()
        self.record_view()

    def export_chart(self):
        if not self.data: return
        path, selected_filter = QtWidgets.QFileDialog.getSaveFileName(self, '导出当前工作台图表', 'interaction.png', 'PNG (*.png);;SVG (*.svg);;PDF (*.pdf)')
        if not path: return
        try:
            suffix = Path(path).suffix.lower()
            if suffix not in ('.png', '.svg', '.pdf'):
                suffix = '.svg' if selected_filter.startswith('SVG') else '.pdf' if selected_filter.startswith('PDF') else '.png'; path += suffix
            hidden = []
            if not self.include_notes.isChecked():
                hidden = [r for _, r, _ in self.regions] + [i for _, i in self.note_items] + [line for _, _, line in self.cursors]
                for item in hidden: item.hide()
            try:
                # Render the two visible plots with their labels and annotations, without UI controls.
                targets = [self.time_plot] + (self.frequency_plots if self.plot_tabs.currentIndex() == 0 else [self.compare_plot])
                if suffix == '.svg':
                    # One SVG per visible plot avoids embedding raster images into vector output.
                    for i, plot in enumerate(targets):
                        target = str(Path(path).with_name(Path(path).stem+f'_{i+1}.svg'))
                        rectangle=plot.getPlotItem().sceneBoundingRect()
                        width,height=max(1,int(math.ceil(rectangle.width()))),max(1,int(math.ceil(rectangle.height())))
                        device=QtSvg.QSvgGenerator(); device.setFileName(target)
                        device.setSize(QtCore.QSize(width,height)); device.setViewBox(QtCore.QRect(0,0,width,height))
                        painter=QtGui.QPainter(device)
                        if not painter.isActive(): raise ValueError('SVG 输出文件无法写入')
                        try: plot.scene().render(painter,QtCore.QRectF(0,0,width,height),rectangle)
                        finally: painter.end()
                else:
                    images = [ImageExporter(p.getPlotItem()).export(toBytes=True) for p in targets]
                    width = max(image.width() for image in images); height = sum(image.height() for image in images)
                    canvas = QtGui.QImage(width, height, QtGui.QImage.Format_ARGB32); canvas.fill(QtCore.Qt.white)
                    painter = QtGui.QPainter(canvas); y = 0
                    for image in images: painter.drawImage(0, y, image); y += image.height()
                    painter.end()
                    if suffix == '.pdf':
                        writer = QtGui.QPdfWriter(path); writer.setResolution(144)
                        writer.setPageSize(QtGui.QPageSize(QtCore.QSizeF(width*25.4/144, height*25.4/144), QtGui.QPageSize.Millimeter))
                        writer.setPageMargins(QtCore.QMarginsF(0,0,0,0))
                        painter = QtGui.QPainter(writer); painter.drawImage(QtCore.QRect(0, 0, writer.width(), writer.height()), canvas); painter.end()
                    elif not canvas.save(path): raise ValueError('图片写入失败')
            finally:
                for item in hidden: item.show()
            self.statusBar().showMessage('图表导出完成' + ('：SVG 按可见图表编号分别保存。' if suffix == '.svg' else '：'+path))
        except Exception as exc: QtWidgets.QMessageBox.warning(self, '图表导出失败', str(exc))

    def closeEvent(self, event):
        if self.worker and self.worker.isRunning():
            self.statusBar().showMessage('请等待后台计算结束后关闭工作台。'); event.ignore(); return
        self.timer.stop(); super().closeEvent(event)
