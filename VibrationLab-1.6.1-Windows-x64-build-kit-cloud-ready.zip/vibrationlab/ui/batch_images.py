"""Batch PNG generation with worker computation and GUI-thread rendering."""
import csv
import re
from pathlib import Path
import numpy as np
import pyqtgraph as pg
from pyqtgraph.exporters import ImageExporter
from PySide6 import QtCore,QtWidgets
from vibrationlab.core.analysis import convert_acceleration,welch_psd,fft_spectrum,band_rms_from_psd
from .image_style import DEFAULT,ImageStyleDialog,make_figure,write_figure


class ImageWorker(QtCore.QThread):
    ready=QtCore.Signal(object)
    failed=QtCore.Signal(str)
    def __init__(self,segments,names,types,unit,params,parent):
        super().__init__(parent); self.args=(segments,names,types,unit,params)
    def run(self):
        try:
            segments,names,types,unit,params=self.args; jobs=[]
            for segment in segments:
                for name,signal in zip(names,segment['signals']):
                    if self.isInterruptionRequested(): return
                    x=convert_acceleration(signal,'m/s²',unit); fs=segment['fs']
                    f,p=welch_psd(x,fs,params[0],params[1],params[2])
                    _,rms=band_rms_from_psd(f,p,segment['low'],segment['high'])
                    for kind in types:
                        if kind=='时域': axis,y,label=segment['times'],x,unit
                        elif kind=='FFT': axis,y=fft_spectrum(x,fs,params[0]); label=unit
                        else: axis,y,label=f,(np.sqrt(p) if kind=='ASD' else p),(unit+'/√Hz' if kind=='ASD' else f'({unit})²/Hz')
                        mask=np.ones(len(axis),dtype=bool) if kind=='时域' else (axis>=segment['low']) & (axis<=(segment['high'] or axis[-1]))
                        if not mask.any(): raise ValueError('频段中没有可绘制的数据点')
                        jobs.append(dict(segment=segment['name'],channel=name,kind=kind,x=axis[mask],y=y[mask],label=label,rms=rms,unit=unit,start=segment['start'],end=segment['end'],low=segment['low'],high=segment['high'] or f[-1]))
            self.ready.emit(jobs)
        except Exception as exc: self.failed.emit(str(exc))


class BatchImages(QtWidgets.QDialog):
    def __init__(self,owner,segments,names,unit='g'):
        super().__init__(owner); self.owner=owner; self.segments=segments; self.names=names; self.unit=unit; self.setWindowTitle('分段批量图片导出'); self.resize(500,350)
        layout=QtWidgets.QFormLayout(self); self.types=[]
        for kind in ['时域','FFT','PSD','ASD']:
            box=QtWidgets.QCheckBox(kind); box.setChecked(kind=='PSD'); self.types.append(box); layout.addRow(box)
        self.width=QtWidgets.QSpinBox(); self.width.setRange(800,5000); self.width.setValue(1600); layout.addRow('图片宽度（像素，PNG）',self.width)
        self.theme=QtWidgets.QComboBox(); self.theme.addItems(['白底','深色']); layout.addRow('图片主题',self.theme)
        self.unified=QtWidgets.QCheckBox('同一图类型统一横纵坐标'); layout.addRow(self.unified)
        self.labels=QtWidgets.QCheckBox('显示主峰、RMS 和积分频段'); self.labels.setChecked(True); layout.addRow(self.labels)
        self.style=dict(DEFAULT); self.style['width']=self.width.value()
        self.formats=QtWidgets.QComboBox(); self.formats.addItems(['PNG','PDF','SVG','PNG + PDF + SVG']); layout.addRow('导出格式',self.formats)
        style_button=QtWidgets.QPushButton('字体、排版与模板…'); style_button.clicked.connect(self.edit_style); layout.addRow(style_button)
        self.preview_button=QtWidgets.QPushButton('预览实际首张 / 拼版'); self.preview_button.clicked.connect(self.preview); layout.addRow(self.preview_button)
        self.count=QtWidgets.QLabel(); layout.addRow(self.count)
        for box in self.types: box.toggled.connect(self.update_count)
        self.update_count(); self.start=QtWidgets.QPushButton('选择目录并开始'); self.start.clicked.connect(self.begin); layout.addRow(self.start)
        self.progress=QtWidgets.QProgressBar(); layout.addRow(self.progress)
        self.cancel=QtWidgets.QPushButton('取消 / 关闭'); self.cancel.clicked.connect(self.stop); layout.addRow(self.cancel)
        self.jobs=[]; self.position=0; self.stopped=False; self.writer=None; self.stream=None

    def edit_style(self):
        if self.stream or (hasattr(self,'worker') and self.worker.isRunning()): return
        dialog=ImageStyleDialog(dict(self.style,width=self.width.value()),self)
        if dialog.exec()==QtWidgets.QDialog.Accepted:
            self.style=dialog.values(); self.width.setMaximum(8000); self.width.setValue(self.style['width']); self.update_count()

    def preview(self):
        if hasattr(self,'worker') and self.worker.isRunning(): return
        self.preview_mode=True; self.stopped=False; self.preview_button.setEnabled(False)
        types=[box.text() for box in self.types if box.isChecked()]
        if not types: self.preview_button.setEnabled(True); return
        self.worker=ImageWorker(self.segments,self.names,types,self.unit,(self.owner.window.currentText(),self.owner.nperseg.value(),self.owner.overlap.value()),self)
        self.worker.ready.connect(self.received); self.worker.failed.connect(self.failed); self.worker.finished.connect(self.worker_finished); self.worker.start()

    def figure(self,page):
        style=dict(self.style,width=self.width.value())
        if style['layout']!='独立图片': style['height']=max(style['height'],int(np.ceil(len(page)/style['columns']))*360)
        if not self.labels.isChecked(): style.update(show_info=False,show_peak=False,shade=False)
        ranges={kind:[j for j in self.jobs if j['kind']==kind] for kind in {j['kind'] for j in self.jobs}} if self.unified.isChecked() else None
        return make_figure(page,style,self.theme.currentIndex()==1,ranges),style

    def update_count(self):
        channels=len(self.names) if self.style['layout']=='独立图片' else 1
        self.count.setText(f'预计 {len(self.segments)*channels*sum(box.isChecked() for box in self.types)} 张／页；'+self.style['layout'])
    def begin(self):
        types=[box.text() for box in self.types if box.isChecked()]
        if not types: return
        folder=QtWidgets.QFileDialog.getExistingDirectory(self,'选择输出目录')
        if not folder: return
        from datetime import datetime
        self.folder=Path(folder)/('VibrationLab_images_'+datetime.now().strftime('%Y%m%d_%H%M%S_%f')); self.folder.mkdir()
        self.stopped=False; self.start.setEnabled(False)
        self.preview_mode=False; self.preview_button.setEnabled(False)
        self.formats.setEnabled(False)
        for control in self.types+[self.width,self.theme,self.unified,self.labels]: control.setEnabled(False)
        self.worker=ImageWorker(self.segments,self.names,types,self.unit,(self.owner.window.currentText(),self.owner.nperseg.value(),self.owner.overlap.value()),self)
        self.worker.ready.connect(self.received); self.worker.failed.connect(self.failed); self.worker.finished.connect(self.worker_finished)
        self.progress.setRange(0,0); self.count.setText('正在后台计算曲线…'); self.worker.start()
    def received(self,jobs):
        if self.stopped: return
        self.jobs=jobs; self.pages=[]
        if self.style['layout']=='独立图片': self.pages=[[job] for job in jobs]
        else:
            groups={}
            for job in jobs: groups.setdefault((job['segment'],job['kind']),[]).append(job)
            self.pages=list(groups.values())
        self.position=0; self.progress.setRange(0,len(self.pages))
        if getattr(self,'preview_mode',False):
            view,style=self.figure(self.pages[0]); view.hide(); view.setAttribute(QtCore.Qt.WA_DontShowOnScreen,False)
            dialog=QtWidgets.QDialog(self); dialog.setWindowTitle('实际输出预览：图内信息框可拖动'); dialog.resize(1050,750); layout=QtWidgets.QVBoxLayout(dialog)
            scroll=QtWidgets.QScrollArea(); scroll.setWidget(view); layout.addWidget(scroll); close=QtWidgets.QPushButton('采用当前信息框位置并返回'); close.clicked.connect(dialog.accept); layout.addWidget(close); dialog.exec()
            if view.info_items:
                item,(xmin,xmax,ymin,ymax)=view.info_items[0]
                self.style['info_x']=(item.pos().x()-xmin)/max(xmax-xmin,1e-12); self.style['info_y']=(item.pos().y()-ymin)/max(ymax-ymin,1e-12)
            view.close(); view.deleteLater(); self.preview_button.setEnabled(True); self.count.setText('预览完成，导出使用同一渲染模板'); return
        self.stream=(self.folder/'图片索引.csv').open('w',encoding='utf-8-sig',newline=''); self.writer=csv.writer(self.stream)
        self.writer.writerow(['segment_name','channel','kind','start_s','end_s','low_hz','high_hz','rms','rms_unit','image'])
        QtCore.QTimer.singleShot(0,self.next_image)
    def next_image(self):
        if self.stopped or self.position>=len(self.pages): self.finish(); return
        plot=None
        try:
            page=self.pages[self.position]; job=page[0]; plot,style=self.figure(page)
            label=job['channel'] if len(page)==1 else '多通道拼版'
            stem=re.sub(r'[^\w\-.一-鿿]+','_',f"{job['segment']}_{label}_{job['kind']}")[:150]
            formats=['png','pdf','svg'] if self.formats.currentIndex()==3 else [self.formats.currentText().lower()]
            for extension in formats:
                filename=f'{self.position+1:04d}_{stem}.{extension}'; write_figure(plot,self.folder/filename,style)
                for entry in page: self.writer.writerow([entry[key] for key in ['segment','channel','kind','start','end','low','high','rms','unit']]+[filename])
            self.stream.flush(); self.position+=1; self.progress.setValue(self.position); self.count.setText(f'已导出 {self.position}/{len(self.pages)} 张／页')
        except Exception as exc: self.failed(str(exc)); return
        finally:
            if plot is not None: plot.close(); plot.deleteLater()
        QtCore.QTimer.singleShot(0,self.next_image)
    def finish(self):
        if self.stream: self.stream.close(); self.stream=None
        self.count.setText(('已取消，保留完成的图片：' if self.stopped else '完成：')+str(self.folder)); self.start.hide()
    def failed(self,message):
        self.stopped=True
        if self.stream: self.stream.close(); self.stream=None
        self.count.setText('导出失败：'+message)
    def worker_finished(self):
        if self.stopped and hasattr(self,'folder'): self.finish()
        if getattr(self,'preview_mode',False): self.preview_button.setEnabled(True)
    def stop(self):
        if hasattr(self,'worker') and self.worker.isRunning(): self.stopped=True; self.worker.requestInterruption(); return
        if self.stream and self.position<len(self.pages) and not self.stopped: self.stopped=True; return
        self.reject()
    def closeEvent(self,event):
        if hasattr(self,'worker') and self.worker.isRunning(): self.stop(); event.ignore(); return
        self.stopped=True
        if self.stream: self.stream.close(); self.stream=None
        super().closeEvent(event)
