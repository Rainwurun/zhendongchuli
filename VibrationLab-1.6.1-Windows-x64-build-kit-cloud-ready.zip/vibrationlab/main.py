import sys
import multiprocessing
import os
from PySide6 import QtWidgets, QtCore
from .ui.main_window import MainWindow
from .version import VERSION

def main():
    multiprocessing.freeze_support()
    # Opt into Windows per-monitor DPI handling before constructing QApplication.
    if sys.platform=='win32': os.environ.setdefault('QT_SCALE_FACTOR_ROUNDING_POLICY','PassThrough')
    QtWidgets.QApplication.setAttribute(QtCore.Qt.AA_DontUseNativeMenuBar,True)
    app=QtWidgets.QApplication(sys.argv); app.setApplicationName('VibrationLab'); app.setApplicationVersion(VERSION); app.setOrganizationName('rain'); app.setStyle("Fusion"); win=MainWindow()
    if '--self-check' in sys.argv:
        from .release_check import run_checks
        return run_checks(win,sys.argv[sys.argv.index('--self-check')+1])
    win.show(); return app.exec()

if __name__ == "__main__": raise SystemExit(main())
