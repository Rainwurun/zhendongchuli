import numpy as np
from scipy import signal

def convert_acceleration(values, source_unit="m/s²", target_unit="m/s²"):
    # Each factor is the magnitude of one unit expressed in m/s².
    # Therefore m/s² -> g divides by standard gravity (9.80665).
    factor = {"m/s²": 1.0, "g": 9.80665, "mm/s²": 0.001}
    if source_unit not in factor or target_unit not in factor: raise ValueError("单位仅支持 m/s²、g 和 mm/s²")
    return np.asarray(values) * factor[source_unit] / factor[target_unit]

def convert_acceleration_psd(values, source_unit="m/s²", target_unit="m/s²"):
    """Convert an acceleration PSD; the linear unit scale is squared for PSD."""
    factor = {"m/s²": 1.0, "g": 9.80665, "mm/s²": 0.001}
    if source_unit not in factor or target_unit not in factor:
        raise ValueError("单位仅支持 m/s²、g 和 mm/s²")
    scale = factor[source_unit] / factor[target_unit]
    return np.asarray(values) * scale * scale

def time_statistics(x):
    x = np.asarray(x, dtype=float)
    if not x.size: raise ValueError("分析区间没有数据")
    return {"mean": float(np.mean(x)), "max": float(np.max(x)), "min": float(np.min(x)), "peak_to_peak": float(np.ptp(x)), "rms": float(np.sqrt(np.mean(x*x))), "std": float(np.std(x))}

def fft_spectrum(x, fs, window="hann", detrend=True):
    x = np.asarray(x, dtype=float)
    if fs <= 0 or len(x) < 2: raise ValueError("FFT 需要正采样频率和至少两个点")
    y = x - np.mean(x) if detrend else x.copy()
    w = signal.get_window(window, len(y), fftbins=True)
    amp = np.abs(np.fft.rfft(y*w)) / np.sum(w)
    if len(y) % 2 == 0: amp[1:-1] *= 2
    else: amp[1:] *= 2
    return np.fft.rfftfreq(len(y), 1/fs), amp

def welch_psd(x, fs, window="hann", nperseg=1024, overlap_pct=50):
    x = np.asarray(x, dtype=float)
    if fs <= 0 or not len(x): raise ValueError("PSD 需要正采样频率和有效数据")
    n = min(int(nperseg), len(x))
    if n < 2: raise ValueError("PSD 至少需要两个数据点")
    if overlap_pct < 0 or overlap_pct >= 100: raise ValueError("重叠率必须在 0 到 100 之间")
    return signal.welch(x, fs=fs, window=window, nperseg=n, noverlap=int(n*overlap_pct/100), detrend="constant", scaling="density")

def resample_uniform(x, fs_in, fs_out):
    """Resample an evenly sampled signal without modifying the original data."""
    x = np.asarray(x, dtype=float)
    if fs_in <= 0 or fs_out <= 0:
        raise ValueError("重采样频率必须为正数")
    if len(x) < 2:
        raise ValueError("重采样至少需要两个数据点")
    target_count = max(2, int(round(len(x) * fs_out / fs_in)))
    return signal.resample(x, target_count), fs_out

def apply_filter(x, fs, kind="none", low_hz=0.0, high_hz=0.0, order=4):
    """Apply a zero-phase Butterworth filter, returning a new array."""
    x = np.asarray(x, dtype=float)
    if kind == "none":
        return x
    nyquist = fs / 2
    if fs <= 0 or len(x) < max(16, order * 3):
        raise ValueError("滤波需要正采样频率和足够的数据点")
    if kind in ("lowpass", "highpass"):
        cutoff = high_hz if kind == "lowpass" else low_hz
        if not 0 < cutoff < nyquist:
            raise ValueError("截止频率必须介于 0 和奈奎斯特频率之间")
        sos = signal.butter(order, cutoff, btype="low" if kind == "lowpass" else "high", fs=fs, output="sos")
    elif kind == "bandpass":
        if not 0 < low_hz < high_hz < nyquist:
            raise ValueError("带通频率须满足 0 < 下限 < 上限 < 奈奎斯特频率")
        sos = signal.butter(order, [low_hz, high_hz], btype="band", fs=fs, output="sos")
    else:
        raise ValueError("未知滤波类型")
    return signal.sosfiltfilt(sos, x)

def find_spectral_peaks(frequency, values, min_distance_hz=0.0, prominence=0.0, limit=10, minimum_value=0.0):
    """Return strongest spectral peaks sorted from largest to smallest."""
    frequency = np.asarray(frequency, dtype=float)
    values = np.asarray(values, dtype=float)
    if len(frequency) != len(values) or len(values) < 3:
        return []
    resolution = frequency[1] - frequency[0]
    distance = max(1, int(round(min_distance_hz / resolution))) if resolution > 0 else 1
    indexes, _ = signal.find_peaks(values, distance=distance, prominence=prominence, height=minimum_value)
    indexes = indexes[np.argsort(values[indexes])[::-1]][:limit]
    return [(float(frequency[i]), float(values[i])) for i in indexes]

def band_rms_from_psd(frequency, psd, low_hz=0.0, high_hz=0.0):
    """Integrate a one-sided PSD over a frequency band and return (area, RMS).

    PSD must use an acceleration-squared per Hz unit.  Zero bounds mean the
    available first/last frequency, and interpolated end points avoid losing
    partial frequency bins at a user-selected band boundary.
    """
    frequency = np.asarray(frequency, dtype=float)
    psd = np.asarray(psd, dtype=float)
    if len(frequency) != len(psd) or len(frequency) < 2:
        raise ValueError("PSD 积分至少需要两个频率点")
    if np.any(np.diff(frequency) <= 0):
        raise ValueError("频率坐标必须严格递增")
    low = frequency[0] if low_hz == 0 else float(low_hz)
    high = frequency[-1] if high_hz == 0 else float(high_hz)
    if low < frequency[0] or high > frequency[-1] or low >= high:
        raise ValueError(f"积分区间必须位于 {frequency[0]:.6g}–{frequency[-1]:.6g} Hz 内，且下限小于上限")
    interior = (frequency > low) & (frequency < high)
    f_band = np.concatenate(([low], frequency[interior], [high]))
    p_band = np.concatenate(([np.interp(low, frequency, psd)], psd[interior], [np.interp(high, frequency, psd)]))
    area = float(np.trapezoid(p_band, f_band))
    if area < 0:
        raise ValueError("PSD 积分面积不能为负")
    return area, float(np.sqrt(area))
