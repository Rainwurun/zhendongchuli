"""Reusable ranges: time selections belong to one source, bands are global."""
import math
import re


def validate_selections(records):
    if not isinstance(records,list): raise ValueError('选区库格式无效')
    result=[]; keys=set()
    for record in records:
        kind=record.get('kind'); name=str(record.get('name','')).strip()
        source=str(record.get('source','')) if kind=='time' else ''
        low=float(record['low']); high=float(record['high'])
        if kind not in ('time','frequency') or not name or not all(math.isfinite(v) for v in (low,high)) or low<0 or high<=low:
            raise ValueError(f'选区“{name}”的名称或范围无效')
        if kind=='time' and not source: raise ValueError('时间段必须关联数据文件')
        key=(kind,source,name)
        if key in keys: raise ValueError(f'选区“{name}”名称重复')
        normalized=dict(kind=kind,name=name,source=source,low=low,high=high)
        if 'colour' in record:
            colour=str(record['colour'])
            if not re.fullmatch(r'#[0-9a-fA-F]{6}',colour): raise ValueError('选区颜色格式无效')
            normalized['colour']=colour
        keys.add(key); result.append(normalized)
    return result
