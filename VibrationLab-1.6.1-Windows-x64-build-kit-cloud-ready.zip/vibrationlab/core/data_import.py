from pathlib import Path
import re
import numpy as np
from .data_models import VibrationDataset
from .timestamp_analysis import estimate_sampling

_TIME_RE = re.compile(r"^(\d{2}):(\d{2}):(\d{2})(?:\.(\d{1,9}))?$")
def _timestamp_ns(date: str, clock: str) -> int:
    from datetime import date as Date
    y, m, d = map(int, date.split("-")); Date(y, m, d)
    match = _TIME_RE.match(clock.strip())
    if not match: raise ValueError("无效时间戳")
    hh, mm, ss = map(int, match.group(1,2,3))
    if hh > 23 or mm > 59 or ss > 59: raise ValueError("无效时间戳")
    fraction = (match.group(4) or "").ljust(9, "0")
    from datetime import datetime, timezone
    epoch = datetime(y, m, d, hh, mm, ss, tzinfo=timezone.utc)
    seconds = int(epoch.timestamp())
    return seconds * 1_000_000_000 + int(fraction or 0)

def load_txt(path: str | Path) -> VibrationDataset:
    path = Path(path)
    if not path.is_file(): raise FileNotFoundError(path)
    timestamps, aux, rows = [], [], []
    errors = []
    expected = None
    with path.open("r", encoding="utf-8-sig") as f:
        for line_no, line in enumerate(f, 1):
            if not line.strip(): continue
            cols = [c.strip() for c in line.rstrip("\r\n").split(",")]
            if expected is None: expected = len(cols)
            if len(cols) != expected:
                errors.append(f"第 {line_no} 行列数为 {len(cols)}，预期 {expected}"); continue
            if len(cols) < 4:
                errors.append(f"第 {line_no} 行至少需要日期、时间、附加列和一个加速度通道"); continue
            try:
                ts = _timestamp_ns(cols[0], cols[1])
                numeric = [float(x) for x in cols[2:]]
                if not np.all(np.isfinite(numeric)): raise ValueError("包含非有限数值")
            except Exception as exc:
                errors.append(f"第 {line_no} 行：{exc}"); continue
            timestamps.append(ts); aux.append(numeric[0]); rows.append(numeric[1:])
    if not timestamps: raise ValueError("文件为空或没有可用数据行。" + ("\n" + "\n".join(errors[:20]) if errors else ""))
    ts = np.asarray(timestamps, dtype=np.int64)
    diffs = np.diff(ts)
    if np.any(diffs <= 0):
        idx = int(np.flatnonzero(diffs <= 0)[0]) + 2
        raise ValueError(f"第 {idx} 行时间戳重复或倒退；为避免静默改变数据，已停止导入")
    sampling = estimate_sampling(ts)
    warnings = list(sampling.warnings)
    if errors: warnings.append(f"有 {len(errors)} 行异常，已跳过；示例：" + "; ".join(errors[:5]))
    chans = np.asarray(rows, dtype=np.float64)
    return VibrationDataset(path, ts, np.asarray(aux), chans, [f"CH{i+1}" for i in range(chans.shape[1])], sampling, warnings)
