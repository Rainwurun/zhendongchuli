import numpy as np
from .data_models import SamplingReport

def estimate_sampling(timestamps_ns: np.ndarray) -> SamplingReport:
    if len(timestamps_ns) < 2:
        raise ValueError("至少需要两个有效时间戳才能估算采样频率")
    dt = np.diff(timestamps_ns).astype(np.float64) / 1e9
    warnings = []
    if np.any(dt <= 0):
        raise ValueError("时间戳存在重复或倒退，无法安全估算采样频率")
    med = float(np.median(dt))
    mean = float(np.mean(dt))
    jitter = float(np.std(dt) / med * 100) if med else float("inf")
    ratios = dt / med
    gaps = np.flatnonzero(ratios > 1.8)
    if len(gaps): warnings.append(f"发现 {len(gaps)} 个疑似丢帧/异常间隔")
    if jitter > 2: warnings.append(f"采样间隔波动较大（{jitter:.2f}%）")
    uniform = jitter <= 2 and not len(gaps)
    return SamplingReport(len(timestamps_ns), mean, med, jitter, 1.0 / med, uniform, warnings)
