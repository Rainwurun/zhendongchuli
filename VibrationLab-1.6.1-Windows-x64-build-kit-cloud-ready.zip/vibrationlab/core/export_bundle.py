"""Reproducible export of selected channels and analysis quantities."""
import csv
import json
from datetime import datetime, timezone
from pathlib import Path
import numpy as np
from .analysis import (convert_acceleration, fft_spectrum, welch_psd,
                       band_rms_from_psd, time_statistics)
from .export_table import write_table


def export_bundle(path, signals, fs, time_s, names, quantities, unit,
                  low=0, high=0, window='hann', nperseg=1024, overlap=50,
                  metadata=None, include_metadata=True, return_rows=False,output_options=None,return_table=False):
    """Signals are processed acceleration arrays in m/s², on a common grid."""
    rows=[]
    for name, raw in zip(names, signals):
        x=convert_acceleration(raw, 'm/s²', unit)
        for quantity in quantities:
            if quantity == '统计值':
                rows.extend((name, quantity, metric, value, unit)
                            for metric, value in time_statistics(x).items())
                continue
            if quantity == '时域':
                rows.extend((name, quantity, t, y, unit) for t,y in zip(time_s,x))
                continue
            if quantity == 'FFT':
                f,y=fft_spectrum(x,fs,window)
                value_unit=unit
            else:
                f,y=welch_psd(x,fs,window,nperseg,overlap)
                if quantity in ('频段 RMS','均方值'):
                    area,rms=band_rms_from_psd(f,y,low,high)
                    rows.append((name,quantity,f'{low}–{high or f[-1]} Hz',rms if quantity=='频段 RMS' else area,unit if quantity=='频段 RMS' else f'({unit})²'))
                    continue
                value_unit=f'({unit})²/Hz'
                if quantity == 'ASD':
                    y=np.sqrt(y); value_unit=f'{unit}/√Hz'
            mask=f>=low
            if high: mask &= f<=high
            if not mask.any(): raise ValueError('导出频段没有频率点')
            rows.extend((name,quantity,hz,value,value_unit) for hz,value in zip(f[mask],y[mask]))
    if return_rows: return rows
    meta=dict(metadata or {},sample_rate_hz=fs,window=window,nperseg=nperseg,overlap_pct=overlap,frequency_band=[low,high],frequency_low_hz=low,frequency_high_hz=high or fs/2,exported_utc=datetime.now(timezone.utc).isoformat())
    if return_table: return ['channel','quantity','time_s / frequency_hz / metric','value','unit'],rows,meta
    write_table(path,['channel','quantity','time_s / frequency_hz / metric','value','unit'],rows,meta,include_metadata,output_options)


def export_named_segments(path, segments, names, quantities, unit,
                          window='hann',nperseg=1024,overlap=50,
                          metadata=None,include_metadata=True,output_options=None,return_table=False):
    """Each segment supplies separately processed samples in m/s²."""
    rows=[]
    for segment in segments:
        fs=segment['fs']; times=segment['times']; signals=segment['signals']
        effective=min(nperseg,len(signals[0]))
        prefix=[segment['name'],segment['start'],segment['end'],float(times[0]),float(times[-1]),segment['low'],segment['high'] or fs/2,fs,effective,int(effective*overlap/100)]
        try:
            values=export_bundle(None,signals,fs,times,names,quantities,unit,
                segment['low'],segment['high'],window,nperseg,overlap,return_rows=True)
        except Exception as exc: raise ValueError(f"分段“{segment['name']}”：{exc}") from exc
        rows.extend(prefix+list(value) for value in values)
    # Calculate every segment before touching the destination file.
    headers=['segment_name','start_s','end_s','actual_first_sample_s','actual_last_sample_s','frequency_low_hz','frequency_high_hz','sample_rate_hz','effective_nperseg','effective_noverlap','channel','quantity','time_s / frequency_hz / metric','value','unit']
    meta=dict(metadata or {},window=window,requested_nperseg=nperseg,overlap_pct=overlap,time_interval='[start,end)',exported_utc=datetime.now(timezone.utc).isoformat())
    if return_table: return headers,rows,meta
    write_table(path,headers,rows,meta,include_metadata,output_options)
