"""Field projection and channel pivot shared by preview and CSV output."""
import csv
import json
from pathlib import Path

FIELDS={
    'segment_name':'分段名称','channel':'通道','quantity':'变量名称',
    'time_s / frequency_hz / metric':'时间／频率／指标','value':'结果数值','unit':'单位',
    'start_s':'起始时间 s','end_s':'结束时间 s','frequency_low_hz':'最低频率 Hz','frequency_high_hz':'最高频率 Hz',
    'actual_first_sample_s':'实际首采样时间 s','actual_last_sample_s':'实际末采样时间 s',
    'sample_rate_hz':'采样率 Hz','effective_nperseg':'实际 Welch 分段长度','effective_noverlap':'实际重叠点数',
    'source_file':'源文件','source_unit':'原始单位','window':'窗函数','filter':'滤波类型',
    'filter_low_hz':'滤波下限 Hz','filter_high_hz':'滤波上限 Hz','resample_hz':'重采样率 Hz','exported_utc':'导出时间 UTC'}
MINIMAL=['segment_name','channel','quantity','value','unit']


def prepare_table(headers,rows,metadata,options=None):
    if options is None: return list(headers),list(rows)
    fields=options.get('fields',list(headers))
    if not fields: raise ValueError('请至少选择一个输出字段')
    records=[dict(metadata or {},**dict(zip(headers,row))) for row in rows]
    if options.get('layout')!='wide':
        return fields,[[record.get(field,'') for field in fields] for record in records]
    if 'value' not in fields: raise ValueError('通道分列布局需要勾选“结果数值”')
    channels=list(dict.fromkeys(record['channel'] for record in records))
    projected=[field for field in fields if field not in ('channel','value')]
    groups={}
    for record in records:
        # Group using original identities, even if the user hides them.
        key=tuple((field,str(record.get(field,''))) for field in headers if field not in ('channel','value'))
        if key not in groups: groups[key]=(record,{})
        values=groups[key][1]
        if record['channel'] in values: raise ValueError('重复通道记录无法转换为分列布局')
        values[record['channel']]=record['value']
    return projected+[f'{channel} value' for channel in channels],[[record.get(field,'') for field in projected]+[values.get(channel,'') for channel in channels] for record,values in groups.values()]


def write_table(path,headers,rows,metadata,include_metadata=True,options=None):
    headers,rows=prepare_table(headers,rows,metadata,options)
    with Path(path).open('w',newline='',encoding='utf-8-sig') as stream:
        writer=csv.writer(stream)
        if include_metadata: writer.writerow(['# metadata',json.dumps(metadata or {},ensure_ascii=False)])
        writer.writerow(headers); writer.writerows(rows)
