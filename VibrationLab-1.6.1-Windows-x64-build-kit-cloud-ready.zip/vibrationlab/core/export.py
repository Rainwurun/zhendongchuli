from datetime import datetime, timezone
from pathlib import Path
import csv

def export_series(path, frequency, values, metadata):
    path = Path(path)
    with path.open("w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f)
        for key, value in metadata.items(): w.writerow([f"# {key}", value])
        w.writerow(["frequency_hz", f"value ({metadata.get('unit', '')})"])
        w.writerows(zip(frequency, values))

def export_time_domain(path, time_s, values, metadata):
    with Path(path).open("w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f)
        for key, value in metadata.items(): w.writerow([f"# {key}", value])
        w.writerow(["time_s", f"acceleration ({metadata.get('unit', '')})"])
        w.writerows(zip(time_s, values))

def export_statistics(path, statistics, unit, metadata):
    with Path(path).open("w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f)
        for key, value in metadata.items(): w.writerow([f"# {key}", value])
        w.writerow(["metric", "value", "unit"])
        for key, value in statistics.items(): w.writerow([key, value, unit])

def metadata_for(dataset, channel, fs, method, params, unit="m/s²"):
    return {"source_file": dataset.path.name, "channel": channel, "unit": unit, "sample_rate_hz": fs, "method": method, "parameters": params, "exported_utc": datetime.now(timezone.utc).isoformat()}
