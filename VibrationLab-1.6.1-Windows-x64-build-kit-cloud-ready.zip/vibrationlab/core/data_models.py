from dataclasses import dataclass, field
from pathlib import Path
import numpy as np

@dataclass
class SamplingReport:
    sample_count: int
    mean_dt_s: float
    median_dt_s: float
    jitter_pct: float
    sample_rate_hz: float
    approximately_uniform: bool
    warnings: list[str] = field(default_factory=list)

@dataclass
class VibrationDataset:
    path: Path
    timestamps_ns: np.ndarray
    auxiliary: np.ndarray
    channels: np.ndarray
    channel_names: list[str]
    sampling: SamplingReport
    warnings: list[str] = field(default_factory=list)

    @property
    def time_s(self):
        return (self.timestamps_ns - self.timestamps_ns[0]).astype(np.float64) / 1e9
