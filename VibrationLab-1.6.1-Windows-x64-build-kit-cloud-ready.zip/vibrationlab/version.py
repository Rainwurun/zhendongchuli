VERSION = '1.6.1'
DEVELOPER = 'rain'
PRODUCT = 'VibrationLab'
COPYRIGHT = 'Copyright © 2026 rain'
