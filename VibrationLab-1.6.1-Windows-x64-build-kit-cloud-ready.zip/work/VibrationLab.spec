# Build with .venv/bin/pyinstaller --distpath outputs/VibrationLab-1.0.0 --workpath work/pyinstaller work/VibrationLab.spec
from pathlib import Path
root=Path(SPECPATH).parent
a = Analysis(['app_entry.py'], pathex=['.'], binaries=[], datas=[(str(root/'vibrationlab'/'resources'),'vibrationlab/resources')],
    hiddenimports=['vibrationlab.release_check'],
    excludes=['pandas','matplotlib','PySide6.QtWebEngineCore','PySide6.QtWebEngineWidgets','PySide6.QtWebEngineQuick','PySide6.QtQml','PySide6.QtQuick','PySide6.QtPdf','PySide6.QtPdfWidgets'],
    noarchive=False)
pyz = PYZ(a.pure)
exe = EXE(pyz,a.scripts,[],exclude_binaries=True,name='VibrationLab',debug=False,
    bootloader_ignore_signals=False,strip=False,upx=False,console=False,target_arch='arm64',codesign_identity=None,entitlements_file=None)
coll = COLLECT(exe,a.binaries,a.datas,strip=False,upx=False,name='VibrationLab')
app = BUNDLE(coll,name='VibrationLab.app',bundle_identifier='com.rain.vibrationlab',
    info_plist={'CFBundleShortVersionString':'1.6.1','CFBundleVersion':'1.6.1',
        'NSHumanReadableCopyright':'Copyright © 2026 rain',
        'CFBundleDisplayName':'VibrationLab','LSMinimumSystemVersion':'14.0',
        'NSHighResolutionCapable':True})
