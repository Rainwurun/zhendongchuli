"""Run on Windows x64. Requires Python 3.11 and Internet for first build."""
import json
import os
import platform
from pathlib import Path
import shutil
import struct
import subprocess
import sys
import traceback

ROOT=Path(__file__).resolve().parent.parent


def main():
    if sys.platform!='win32' or struct.calcsize('P')!=8 or platform.machine().lower() not in ('amd64','x86_64'):
        raise RuntimeError('Please run this build on Windows x64 with x64 Python 3.11.')
    if sys.version_info[:2]!=(3,11): raise RuntimeError('Please install Python 3.11 x64 first.')
    os.chdir(ROOT)
    from runpy import run_path
    version=run_path(str(ROOT/'vibrationlab'/'version.py'))['VERSION']
    work=ROOT/'work'; work.mkdir(exist_ok=True)
    env=dict(os.environ,PYTHONUTF8='1',PYINSTALLER_CONFIG_DIR=str(work/'pyinstaller-cache-windows'))
    log=work/'build-windows.log'
    def run(command,timeout=None):
        print('Running: '+' '.join(map(str,command)),flush=True)
        with log.open('a',encoding='utf-8') as stream:
            result=subprocess.run(list(map(str,command)),stdout=stream,stderr=subprocess.STDOUT,env=env,timeout=timeout)
        if result.returncode: raise RuntimeError(f'Command failed ({result.returncode}); see {log}')
    python=ROOT/'.venv-win'/'Scripts'/'python.exe'
    if not python.exists(): run([sys.executable,'-m','venv',ROOT/'.venv-win'])
    run([python,'-m','pip','install','-c',ROOT/'packaging'/'release-constraints.txt','-e','.[test]','pyinstaller==6.22.3'])
    run([python,'-m','pytest','-q'])
    dist=ROOT/'outputs'/f'VibrationLab-{version}-windows-x64'
    if dist.exists() or dist.with_suffix('.zip').exists(): raise RuntimeError(f'Output already exists. Rename {dist} and its ZIP before rebuilding to preserve them.')
    run([python,'-m','PyInstaller','--noconfirm','--distpath',dist,'--workpath',work/'build-windows',ROOT/'packaging'/'windows.spec'])
    report=dist/'acceptance.json'
    run([dist/'VibrationLab'/'VibrationLab.exe','--self-check',report],timeout=180)
    if not json.loads(report.read_text(encoding='utf-8'))['passed']: raise RuntimeError('Packaged acceptance checks failed.')
    shutil.copy2(ROOT/'WINDOWS_README.md',dist/'README.md')
    for name in ('help.html','help.md'):
        shutil.copy2(ROOT/'vibrationlab'/'resources'/name,dist/name)
    (dist/'START_HERE.txt').write_text('VibrationLab '+version+' - rain\n\nExtract the entire ZIP, then open VibrationLab/VibrationLab.exe.\nNo Python installation or Internet connection is required to run this portable package.\nKeep the _internal folder beside VibrationLab.exe.\nTarget: Windows 10/11 x64 (Intel/AMD).\nSee README.md for verification scope.\n',encoding='utf-8-sig')
    with (dist/'build-requirements.txt').open('w',encoding='utf-8') as stream:
        subprocess.run([str(python),'-m','pip','freeze'],stdout=stream,env=env,check=True)
    archive=shutil.make_archive(str(dist),'zip',root_dir=dist.parent,base_dir=dist.name)
    print(f'BUILD COMPLETED: {archive}\nStart: {dist / "VibrationLab" / "VibrationLab.exe"}\nPlease verify the menus and TXT analysis on your Windows desktop.',flush=True)


if __name__=='__main__':
    try: main()
    except Exception:
        traceback.print_exc(); sys.exit(1)
