from pathlib import Path
import platform
import struct
import sys

if sys.platform!='win32' or struct.calcsize('P')!=8 or platform.machine().lower() not in ('amd64','x86_64'):
    raise SystemExit('Build requires Windows x64 with 64-bit x64 Python.')
root=Path(SPECPATH).parent
a=Analysis([str(root/'packaging'/'windows_entry.py')],pathex=[str(root)],
    binaries=[],datas=[(str(root/'vibrationlab'/'resources'),'vibrationlab/resources')],hiddenimports=['vibrationlab.release_check'],
    excludes=['pandas','matplotlib','PySide6.QtWebEngineCore','PySide6.QtWebEngineWidgets','PySide6.QtWebEngineQuick','PySide6.QtQml','PySide6.QtQuick','PySide6.QtPdf','PySide6.QtPdfWidgets'],noarchive=False)
pyz=PYZ(a.pure)
exe=EXE(pyz,a.scripts,[],exclude_binaries=True,name='VibrationLab',
    debug=False,bootloader_ignore_signals=False,strip=False,upx=False,
    console=False,version=str(root/'packaging'/'windows-version.txt'))
coll=COLLECT(exe,a.binaries,a.datas,strip=False,upx=False,name='VibrationLab')
