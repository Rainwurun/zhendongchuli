import os
os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
import csv
import numpy as np
from unittest.mock import patch
from PySide6 import QtWidgets,QtTest
from vibrationlab.ui.main_window import MainWindow
from vibrationlab.ui.batch_images import BatchImages


def test_batch_png_and_index(tmp_path):
    app=QtWidgets.QApplication.instance() or QtWidgets.QApplication([])
    owner=MainWindow(); fs=1024; t=np.arange(fs)/fs; x=9.80665*np.sin(2*np.pi*64*t)
    segments=[dict(name='起飞',start=1,end=2,low=50,high=80,fs=fs,times=t+1,signals=[x,2*x])]
    dialog=BatchImages(owner,segments,['CH1','CH2'],'g')
    with patch.object(QtWidgets.QFileDialog,'getExistingDirectory',return_value=str(tmp_path)): dialog.begin()
    for _ in range(100):
        QtTest.QTest.qWait(50)
        if dialog.position==2: break
    assert dialog.position==2,dialog.count.text()
    QtTest.QTest.qWait(50)
    files=list(dialog.folder.glob('*.png')); assert len(files)==2
    assert all(f.read_bytes().startswith(b'\x89PNG') for f in files)
    with (dialog.folder/'图片索引.csv').open(encoding='utf-8-sig') as stream: rows=list(csv.DictReader(stream))
    assert np.isclose(float(rows[0]['rms']),1/np.sqrt(2),rtol=.001)
    assert rows[0]['rms_unit']=='g'
    assert rows[0]['segment_name']=='起飞'
    dialog.close(); owner.close()
