import os
os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
import numpy as np
from PySide6 import QtWidgets,QtGui
from vibrationlab.ui.image_style import DEFAULT,make_figure,write_figure,ImageStyleDialog


def test_montage_raster_and_vector(tmp_path):
    app=QtWidgets.QApplication.instance() or QtWidgets.QApplication([])
    x=np.linspace(10,100,100); y=np.exp(-((x-60)/5)**2)
    jobs=[dict(segment='起飞',channel=name,kind='PSD',x=x,y=y,label='g²/Hz',rms=.707,unit='g',start=1,end=2,low=10,high=100) for name in ['CH1','CH2']]
    style=dict(DEFAULT,layout='多通道拼版',columns=2,width=1600,height=900,info_position='图内可拖动信息框')
    figure=make_figure(jobs,style)
    assert len(figure.info_items)==2
    for extension in ['png','pdf','svg']: write_figure(figure,tmp_path/f'figure.{extension}',style)
    image=QtGui.QImage(str(tmp_path/'figure.png')); assert image.width()==1600 and image.height()==900
    assert (tmp_path/'figure.pdf').read_bytes().startswith(b'%PDF')
    svg=(tmp_path/'figure.svg').read_text()
    assert '<svg' in svg and ('<path' in svg or '<polyline' in svg)
    figure.close()


def test_style_dialog_independent_fonts():
    app=QtWidgets.QApplication.instance() or QtWidgets.QApplication([])
    dialog=ImageStyleDialog(dict(DEFAULT),None)
    dialog.controls['title_size'].setValue(28); dialog.controls['tick_size'].setValue(11)
    result=dialog.values()
    assert result['title_size']==28 and result['tick_size']==11
    assert DEFAULT['title_size']==20
    dialog.close()
