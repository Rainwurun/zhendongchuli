from unittest.mock import patch
from vibrationlab.platform_info import multiselect_key,platform_description


def test_windows_user_wording():
    with patch('vibrationlab.platform_info.platform.system',return_value='Windows'),patch('vibrationlab.platform_info.platform.release',return_value='11'),patch('vibrationlab.platform_info.platform.machine',return_value='AMD64'):
        assert multiselect_key()=='Ctrl'
        assert platform_description()=='Windows 11 · AMD64'


def test_macos_user_wording():
    with patch('vibrationlab.platform_info.platform.system',return_value='Darwin'):
        assert multiselect_key()=='Command'
