import os
os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
import pytest
from PySide6 import QtWidgets
from vibrationlab.ui.export_dialog import ExportDialog


def test_named_segment_validation():
    app=QtWidgets.QApplication.instance() or QtWidgets.QApplication([])
    dialog=ExportDialog(['CH1']); dialog.add_segment()
    dialog.segments.item(0,0).setText('起飞')
    dialog.segments.item(1,0).setText('巡航')
    assert [d['name'] for d in dialog.segment_definitions()]==['起飞','巡航']
    dialog.segments.item(1,0).setText('起飞')
    with pytest.raises(ValueError,match='重复'): dialog.segment_definitions()
    dialog.segments.item(1,0).setText('巡航'); dialog.segments.item(1,2).setText('nan')
    with pytest.raises(ValueError): dialog.segment_definitions()
    dialog.close()
