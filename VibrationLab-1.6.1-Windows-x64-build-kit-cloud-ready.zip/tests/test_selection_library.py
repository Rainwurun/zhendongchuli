import os
os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
import csv
import numpy as np
import pytest
from unittest.mock import patch
from PySide6 import QtWidgets
from vibrationlab.core.selection_library import validate_selections
from vibrationlab.core.data_models import SamplingReport,VibrationDataset
from vibrationlab.ui.main_window import MainWindow
from vibrationlab.ui.export_dialog import ExportDialog


def test_selection_scoping():
    record=dict(kind='time',name='阶段一',source='/a.txt',low=1,high=2)
    assert len(validate_selections([record,dict(record,source='/b.txt')]))==2
    with pytest.raises(ValueError): validate_selections([record,record])
    with pytest.raises(ValueError): validate_selections([dict(record,high=float('nan'))])


def test_saved_selection_export_preview_and_configuration(tmp_path):
    app=QtWidgets.QApplication.instance() or QtWidgets.QApplication([])
    w=MainWindow(); fs=1024; t=np.arange(4096)/fs
    ds=VibrationDataset(tmp_path/'data.txt',np.round(t*1e9).astype(np.int64),np.zeros(len(t)),(9.80665*np.sin(2*np.pi*64*t))[:,None],['CH1'],SamplingReport(len(t),1/fs,1/fs,0,fs,True))
    w.datasets=[ds]; w.files.addItem('data'); w.files.setCurrentRow(0)
    w.interactions.select_band(False)
    with patch.object(QtWidgets.QInputDialog,'getText',return_value=('起飞',True)): w.save_current_selection()
    assert w.saved_selections[0]['kind']=='time'
    w.mode.setCurrentText('PSD'); w.interactions.select_band((50,80))
    with patch.object(QtWidgets.QInputDialog,'getText',return_value=('低频',True)): w.save_current_selection()
    d=ExportDialog(['CH1'],w,saved_selections=w.saved_selections,source=str(ds.path.resolve()))
    d.metadata.setChecked(True)
    d.segments.cellWidget(0,5).setCurrentIndex(1); d.segments.cellWidget(0,6).setCurrentIndex(1)
    assert d.segment_definitions()[0]['name']=='起飞 / 低频'
    rows=w.preview_segment_rms(d)
    assert rows[0][4]==pytest.approx(1/np.sqrt(2),rel=.001)
    csvpath=tmp_path/'out.csv'; w.export_segmented_results(csvpath,d,[0],['频段 RMS'])
    with csvpath.open(encoding='utf-8-sig') as stream:
        next(stream); results=list(csv.DictReader(stream))
    assert float(results[0]['value'])==pytest.approx(rows[0][4])
    config=tmp_path/'config.json'
    with patch.object(QtWidgets.QFileDialog,'getSaveFileName',return_value=(str(config),'')): w.save_configuration()
    w.saved_selections=[]
    with patch.object(QtWidgets.QFileDialog,'getOpenFileName',return_value=(str(config),'')): w.load_configuration()
    assert len(w.saved_selections)==2
    w.focus_saved_selection(w.saved_selections[0]); assert w.mode.currentText()=='时域'
    assert w.interactions.selection_context['kind']=='time'
    w.close()
