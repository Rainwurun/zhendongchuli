import os
os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
import json
import time
from unittest.mock import patch

import numpy as np
import pytest
from PySide6 import QtCore, QtGui, QtWidgets, QtTest

from vibrationlab.core.data_models import SamplingReport,VibrationDataset
from vibrationlab.core.analysis import band_rms_from_psd
from vibrationlab.ui.main_window import MainWindow
from vibrationlab.ui.interaction_studio import InteractionStudio,validate_workspace


def settle(studio):
    deadline=time.monotonic()+8
    while time.monotonic()<deadline:
        QtWidgets.QApplication.processEvents()
        if studio.ready(): return
        QtTest.QTest.qWait(10)
    raise AssertionError(studio.readout.text())


@pytest.fixture
def studio(tmp_path,monkeypatch):
    def warning(*args,**kwargs): raise AssertionError(str(args[2]))
    monkeypatch.setattr(QtWidgets.QMessageBox,'warning',warning)
    app=QtWidgets.QApplication.instance() or QtWidgets.QApplication([])
    w=MainWindow(); fs=1024; t=np.arange(fs*4)/fs
    x=9.80665*np.sin(2*np.pi*64*t); x[t>=2]*=2
    ds=VibrationDataset(tmp_path/'demo.txt',np.round(t*1e9).astype(np.int64),np.zeros(len(t)),
         np.column_stack((x,x*.5)),['CH1','CH2'],SamplingReport(len(t),1/fs,1/fs,0,fs,True))
    w.datasets=[ds]; w.files.addItem('demo'); w.files.setCurrentRow(0); w.unit.setCurrentText('g')
    w.studio=InteractionStudio(w); s=w.studio; s.refresh(); settle(s)
    yield s
    s.timer.stop()
    if s.worker:
        s.worker.requestInterruption(); s.worker.wait(8000); app.processEvents()
    s.close(); w.close(); app.processEvents()


def text_input(value):
    return patch.object(QtWidgets.QInputDialog,'getText',return_value=(value,True))


def test_linked_worker_units_snapshots_and_views(studio):
    s=studio
    assert len(s.data['rows'])==1
    s.new_range('time',(0,1)); settle(s)
    _,rms=band_rms_from_psd(s.data['rows'][0]['f'],s.data['rows'][0]['psd'],50,80)
    assert rms/9.80665==pytest.approx(1/np.sqrt(2),rel=1e-5)
    with text_input('初始阶段'): s.pin()
    s.snapshot_table.selectRow(0); s.set_reference()
    s.new_range('time',(2,3)); settle(s)
    assert len(s.snapshots)==1 and s.snapshots[0]['start']==0
    s.new_range('frequency',(50,80))
    assert float(s.summary.topLevelItem(0).text(4))==pytest.approx(np.sqrt(2),rel=1e-5)
    assert s.summary.topLevelItem(0).text(5)=='+100%'
    _,psd_g,label=s.spectrum(s.data['rows'][0]); assert label=='(g)²/Hz'
    s.unit.setCurrentText('m/s²')
    _,psd_m,_=s.spectrum(s.data['rows'][0]); np.testing.assert_allclose(psd_m,psd_g*9.80665**2)
    s.kind.setCurrentText('ASD')
    _,asd,label=s.spectrum(s.data['rows'][0]); np.testing.assert_allclose(asd**2,psd_m); assert '/√Hz' in label
    s.kind.setCurrentText('FFT'); s.scale.setCurrentIndex(2)
    s.layout_mode.setCurrentIndex(1)
    for mode in range(4): s.link.setCurrentIndex(mode)
    s.align.setCurrentIndex(1); s.set_tool('cursor')
    plot,_,line=s.cursors[0]; s.cursor_changed(plot,line)
    assert 'RMS=' in s.readout.text()
    assert s.data_generation==s.generation


def test_selection_save_cancel_delete_undo_and_config(studio,tmp_path):
    s=studio; s.new_range('time',(0,1)); settle(s)
    with text_input('时间段{一}'): s.save_active()
    original=dict(s.owner.saved_selections[0])
    with patch.object(QtWidgets.QMessageBox,'question',return_value=QtWidgets.QMessageBox.No):
        s.replace_record(s.selected_record(),dict(original,low=.2,high=.8))
    assert s.owner.saved_selections==[original]
    s.delete_active(); settle(s); assert not s.owner.saved_selections
    s.undo(); settle(s); assert s.owner.saved_selections==[original]
    s.redo(); settle(s); assert not s.owner.saved_selections
    s.undo(); settle(s)
    s.new_range('frequency',(50,80))
    with text_input('导出阶段一'): s.enqueue()
    assert s.tasks()[0]['start']==0 and s.tasks()[0]['high']==80
    file=tmp_path/'config.json'
    with patch.object(QtWidgets.QFileDialog,'getSaveFileName',return_value=(str(file),'')): s.owner.save_configuration()
    raw=json.loads(file.read_text()); assert raw['interaction_workspace']['queue'][0]['name']=='导出阶段一'
    assert validate_workspace(raw['interaction_workspace'])['queue']==s.tasks()
    with patch.object(s.owner,'export_configured') as export:
        s.export_queue(); assert export.call_args.kwargs['definitions'][0]['low']==50


@pytest.mark.parametrize('extension',['png','pdf','svg'])
def test_studio_picture_exports(studio,tmp_path,extension):
    s=studio; s.new_range('time',(0,1)); settle(s)
    path=tmp_path/('linked.'+extension)
    with patch.object(QtWidgets.QFileDialog,'getSaveFileName',return_value=(str(path),extension.upper())):
        s.export_chart()
    if extension=='png': assert not QtGui.QImage(str(path)).isNull()
    elif extension=='pdf': assert path.read_bytes().startswith(b'%PDF')
    else: assert '<svg' in path.with_name('linked_1.svg').read_text()


def test_notes_scope_and_threshold_conversion(studio):
    s=studio; s.new_range('time',(0,1)); settle(s)
    s.peak_count.setValue(1); s.annotate_peaks()
    assert s.owner.interaction_workspace['notes'] and s.note_items
    note=dict(s.owner.interaction_workspace['notes'][0]); assert note['start']==0 and note['end']==1
    s.new_range('time',(2,3)); settle(s); assert not s.note_items
    s.peak_floor.setValue(.2); s.unit.setCurrentText('m/s²')
    assert s.peak_floor.value()==pytest.approx(.2*9.80665**2)
    s.kind.setCurrentText('ASD'); assert s.peak_floor.value()==0
    with pytest.raises(ValueError): validate_workspace(dict(notes=[dict(note,x=float('nan'))]))


def test_late_result_rejected_and_failed_range_not_ready(studio):
    s=studio; previous=s.data
    s.generation+=1; s.received(s.generation-1,dict(previous,start=99))
    assert s.data['start']!=99 and not s.ready()
    s.time_range=(1,1.00000001); s.refresh()
    deadline=time.monotonic()+8
    while s.pending or s.timer.isActive() or s.worker:
        QtWidgets.QApplication.processEvents(); QtTest.QTest.qWait(10)
        assert time.monotonic()<deadline
    assert not s.ready() and '计算失败' in s.readout.text()


def test_offline_help_can_search_without_network(studio):
    w=studio.owner; w.show_help()
    dialog=w.help_dialog
    assert dialog.path.is_file()
    text=dialog.browser.toPlainText()
    for word in ('Welch','9.80665','峰峰值','重采样','scaling'):
        assert word in text
    dialog.search.setText('RMS'); dialog.find_next()
    assert dialog.browser.textCursor().selectedText()=='RMS'
    dialog.close()


def test_peak_annotations_are_independent_between_time_ranges(studio, monkeypatch):
    s = studio
    # Identical peaks can occur in different operating stages; both need notes.
    monkeypatch.setattr('vibrationlab.ui.interaction_studio.find_spectral_peaks',
                        lambda *args, **kwargs: [(64., .25)])
    s.new_range('time', (0, 1)); settle(s)
    s.annotate_peaks(); s.annotate_peaks()
    assert len(s.visible_notes()) == 1  # Repeated click in this stage is deduplicated.
    first = dict(s.visible_notes()[0])
    s.new_range('time', (2, 3)); settle(s)
    s.annotate_peaks()
    assert len(s.visible_notes()) == 2
    assert [n['start'] for n in s.displayed_notes()] == [2]
    s.arrange_notes()
    assert s.visible_notes()[0] == first  # Hidden stage's coordinates are untouched.
    s.new_range('time', (0, 1)); settle(s)
    assert s.displayed_notes() == [first]
    assert len(s.note_items) == 1


def test_arrange_notes_preserves_other_spectrum_positions(studio):
    s = studio
    s.annotate_peaks()
    psd_notes = [dict(n) for n in s.visible_notes()]
    assert psd_notes
    s.kind.setCurrentText('ASD'); s.annotate_peaks()
    assert all(n['spectrum'] == 'ASD' for n in s.displayed_notes())
    s.arrange_notes()
    assert [n for n in s.visible_notes() if n['spectrum'] == 'PSD'] == psd_notes


def test_workbench_buttons_and_repeated_redraw(studio):
    s = studio; s.show(); QtWidgets.QApplication.processEvents()
    def click(label):
        button = next(b for b in s.findChildren(QtWidgets.QPushButton) if b.text() == label)
        QtTest.QTest.mouseClick(button, QtCore.Qt.LeftButton)
        QtWidgets.QApplication.processEvents()
    click('新增时间段'); settle(s)
    click('新增频段')
    assert {r['kind'] for r in s.records()} == {'time', 'frequency'}
    for page in range(len(s.side.buttons)):
        QtTest.QTest.mouseClick(s.side.buttons[page], QtCore.Qt.LeftButton)
        assert s.side.currentIndex() == page
    for _ in range(3):
        for kind in ('ASD', 'FFT', 'PSD'):
            s.kind.setCurrentText(kind)
            for layout in (1, 0): s.layout_mode.setCurrentIndex(layout)
            QtWidgets.QApplication.processEvents()
            assert s.ready()
    assert len(s.frequency_pool) <= 2


def test_latest_time_range_wins_during_rapid_refresh(studio):
    s = studio
    for bounds in ((0, 1), (1, 2), (2, 3), (0, .5)):
        s.time_range = bounds; s.refresh()
        QtWidgets.QApplication.processEvents()
    settle(s)
    assert (s.data['start'], s.data['end']) == (0, .5)
    assert s.generation == s.data_generation
