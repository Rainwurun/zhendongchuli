"""Regression checks for the macOS menu compatibility defect."""
import os
os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
from PySide6 import QtWidgets
from vibrationlab.ui.main_window import MainWindow
from vibrationlab.ui.native_menus import ParameterDialog
from PySide6 import QtCore, QtTest


def test_native_menu_controls_and_dialog_commit():
    app=QtWidgets.QApplication.instance() or QtWidgets.QApplication([])
    window=MainWindow()
    menus=[]
    def visit(menu):
        menus.append(menu)
        for action in menu.actions():
            assert not isinstance(action,QtWidgets.QWidgetAction)
            if action.menu(): visit(action.menu())
    for action in window.menuBar().actions(): visit(action.menu())
    assert len(window.legacy_parameter_actions)==36
    analysis=next(menu for menu in menus if menu.title()=='分析类型')
    analysis.actions()[2].trigger()
    assert window.mode.currentText()=='PSD'
    window.mode.setCurrentText('FFT')
    assert analysis.actions()[1].isChecked()
    fields=window.native_parameter_fields['主峰筛选']
    dialog=ParameterDialog('主峰筛选',fields,window)
    for original,copy in dialog.fields:
        if original is window.peak_count: copy.setValue(6)
    dialog.reject()
    assert window.peak_count.value()==10
    dialog.apply()
    assert window.peak_count.value()==6
    window.close()


def test_mouse_menu_opening_and_parameter_dialog():
    app=QtWidgets.QApplication.instance() or QtWidgets.QApplication([])
    window=MainWindow(); window.show(); app.processEvents()
    assert not window.menuBar().isNativeMenuBar()
    assert len(window.menuBar().actions()) == 6
    for action in window.menuBar().actions():
        QtTest.QTest.mouseClick(window.menuBar(),QtCore.Qt.LeftButton,pos=window.menuBar().actionGeometry(action).center())
        app.processEvents()
        assert action.menu().isVisible(), action.text()
        action.menu().hide()
    target=next(menu for menu in window.menu_references if menu.title()=='主峰筛选')
    setting=next(a for a in target.actions() if a.text()=='设置参数…')
    opened=[]
    def dismiss():
        dialog=app.activeModalWidget()
        opened.append(isinstance(dialog,ParameterDialog))
        if dialog: dialog.reject()
    QtCore.QTimer.singleShot(50,dismiss)
    setting.trigger()
    assert opened==[True]
    window.close()
