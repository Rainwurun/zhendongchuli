import numpy as np
import pytest
from vibrationlab.core.data_import import load_txt
from vibrationlab.core.timestamp_analysis import estimate_sampling
from vibrationlab.core.analysis import apply_filter, band_rms_from_psd, convert_acceleration, convert_acceleration_psd, fft_spectrum, find_spectral_peaks, resample_uniform, time_statistics, welch_psd

def test_sampling_rates():
    for fs in (1000,2048,5000):
        ts=np.arange(1000,dtype=np.int64)*round(1e9/fs)
        assert estimate_sampling(ts).sample_rate_hz == pytest.approx(fs,rel=1e-5)

def test_timestamp_nanoseconds_and_import(tmp_path):
    p=tmp_path/"x.txt"; p.write_text("2026-09-15,22:21:13.433940500,5848.24,1,2\n2026-09-15,22:21:13.434940500,5848.25,3,4\n")
    ds=load_txt(p); assert ds.channels.shape==(2,2); assert ds.timestamps_ns[1]-ds.timestamps_ns[0]==1_000_000
    assert ds.auxiliary[0]==5848.24

def test_invalid_rows_reported(tmp_path):
    p=tmp_path/"x.txt"; p.write_text("2026-01-01,00:00:00.0,3,1\n2026-01-01,00:00:00.1,nope,1\n")
    with pytest.raises(ValueError): load_txt(p)

def test_analysis():
    x=np.array([1.,-1.,1.,-1.]); assert time_statistics(x)["rms"]==1
    assert convert_acceleration([9.80665],"m/s²","g")[0]==pytest.approx(1)
    assert convert_acceleration([1.0],"m/s²","g")[0]==pytest.approx(1 / 9.80665)
    assert convert_acceleration([1.0],"m/s²","mm/s²")[0] == pytest.approx(1000)
    assert convert_acceleration([1000.0],"mm/s²","m/s²")[0] == pytest.approx(1)
    fs=1000; t=np.arange(fs)/fs; f,a=fft_spectrum(2*np.sin(2*np.pi*50*t),fs)
    assert f[np.argmax(a)]==pytest.approx(50); assert a.max()==pytest.approx(2,rel=.01)
    f,p=welch_psd(np.sin(2*np.pi*50*t),fs,nperseg=512)
    assert f[np.argmax(p)]==pytest.approx(50,abs=2)

def test_resampling_and_filtering():
    fs = 1000
    t = np.arange(fs) / fs
    x = np.sin(2*np.pi*20*t) + .8*np.sin(2*np.pi*200*t)
    y, out_fs = resample_uniform(x, fs, 500)
    assert out_fs == 500
    assert len(y) == 500
    filtered = apply_filter(x, fs, "lowpass", high_hz=50)
    f, amplitude = fft_spectrum(filtered, fs)
    assert amplitude[np.argmin(abs(f-20))] > amplitude[np.argmin(abs(f-200))] * 10

def test_filter_parameter_validation():
    with pytest.raises(ValueError):
        apply_filter(np.ones(100), 100, "bandpass", low_hz=40, high_hz=20)

def test_spectral_peak_identification():
    frequency = np.arange(0, 101, dtype=float)
    values = np.zeros_like(frequency)
    values[20], values[60] = 2, 5
    peaks = find_spectral_peaks(frequency, values, limit=2)
    assert peaks[0] == (60.0, 5.0)
    assert peaks[1] == (20.0, 2.0)
    assert find_spectral_peaks(frequency,values,limit=10,minimum_value=3)==[(60.0,5.0)]

def test_psd_scales_by_squared_acceleration_unit_factor():
    fs = 1000
    x_mps2 = 9.80665 * np.sin(2*np.pi*50*np.arange(fs)/fs)
    _, psd_mps2 = welch_psd(x_mps2, fs, nperseg=512)
    _, psd_g = welch_psd(convert_acceleration(x_mps2, "m/s²", "g"), fs, nperseg=512)
    assert psd_g.max() == pytest.approx(psd_mps2.max() / 9.80665**2, rel=1e-12)

def test_explicit_psd_unit_conversion():
    psd_mps2 = np.array([1.0, 4.0])
    assert np.allclose(convert_acceleration_psd(psd_mps2, "m/s²", "g"), psd_mps2 / 9.80665**2)
    assert np.allclose(convert_acceleration_psd(psd_mps2, "m/s²", "mm/s²"), psd_mps2 * 1_000_000)

def test_band_rms_from_psd():
    frequency = np.arange(0, 101, dtype=float)
    psd = np.full_like(frequency, 4.0)  # 4 g²/Hz over 10 Hz gives 40 g².
    area, rms = band_rms_from_psd(frequency, psd, 10, 20)
    assert area == pytest.approx(40)
    assert rms == pytest.approx(np.sqrt(40))

def test_configurable_export_units_and_rms(tmp_path):
    import csv
    from vibrationlab.core.export_bundle import export_bundle
    fs=1024; t=np.arange(4096)/fs
    signal=9.80665*np.sin(2*np.pi*64*t)
    path=tmp_path/'bundle.csv'
    export_bundle(path,[signal],fs,t,['CH1'],['频段 RMS','ASD'],'g',50,80)
    with path.open(encoding='utf-8-sig') as f:
        rows=list(csv.reader(f))
    rms=[row for row in rows if len(row)>1 and row[1]=='频段 RMS'][0]
    assert float(rms[3])==pytest.approx(1/np.sqrt(2),rel=.001)
    assert rms[4]=='g'
    asd=[row for row in rows if len(row)>1 and row[1]=='ASD']
    assert all(50<=float(row[2])<=80 for row in asd)
    assert all(row[4]=='g/√Hz' for row in asd)

def test_named_segments_have_independent_band_rms(tmp_path):
    import csv
    from vibrationlab.core.export_bundle import export_named_segments
    fs=1024
    segments=[]
    for name,start,end,freq,amplitude,low,high in [('起飞',1,2,64,1,50,80),('巡航',4,5,128,2,100,160),('降落',6,9,256,3,220,300)]:
        times=np.arange(start*fs,end*fs)/fs
        signal=9.80665*amplitude*np.sin(2*np.pi*freq*times)
        segments.append(dict(name=name,start=start,end=end,low=low,high=high,fs=fs,times=times,signals=[signal]))
    path=tmp_path/'segments.csv'
    export_named_segments(path,segments,['CH1'],['频段 RMS'],'g',include_metadata=False)
    with path.open(encoding='utf-8-sig') as f: rows=list(csv.DictReader(f))
    rms=[row for row in rows if row['quantity']=='频段 RMS']
    assert [row['segment_name'] for row in rms]==['起飞','巡航','降落']
    for amplitude,row in enumerate(rms,1):
        assert float(row['value'])==pytest.approx(amplitude/np.sqrt(2),rel=.001)
        assert row['unit']=='g'
        assert row['effective_nperseg']=='1024'
    assert [row['frequency_low_hz'] for row in rms]==['50','100','220']
