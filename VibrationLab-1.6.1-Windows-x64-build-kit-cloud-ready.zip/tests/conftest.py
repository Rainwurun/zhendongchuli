"""Keep automated UI checks away from the user's saved preferences."""
import os
os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
import pytest
from PySide6 import QtCore, QtWidgets


@pytest.fixture(scope='session',autouse=True)
def application():
    # Match the production entry point before creating any native menus.
    QtWidgets.QApplication.setAttribute(QtCore.Qt.AA_DontUseNativeMenuBar, True)
    app = QtWidgets.QApplication.instance() or QtWidgets.QApplication([])
    app.setStyle('Fusion')
    yield app


@pytest.fixture(scope='session',autouse=True)
def isolated_preferences(tmp_path_factory):
    original=QtCore.QSettings.defaultFormat()
    QtCore.QSettings.setDefaultFormat(QtCore.QSettings.IniFormat)
    QtCore.QSettings.setPath(QtCore.QSettings.IniFormat,QtCore.QSettings.UserScope,str(tmp_path_factory.mktemp('preferences')))
    yield
    QtCore.QSettings.setDefaultFormat(original)
