"""Analytic reference cases for the formulas described in offline help."""
import numpy as np
import pytest
from vibrationlab.core.analysis import (
    apply_filter,band_rms_from_psd,convert_acceleration,
    fft_spectrum,time_statistics,welch_psd,
)


@pytest.mark.parametrize('count',[1023,1024])
@pytest.mark.parametrize('window',['hann','boxcar'])
def test_fft_peak_normalization_and_dc_removal(count,window):
    fs=2048; t=np.arange(count)/fs; frequency=64*fs/count
    f,a=fft_spectrum(7+2*np.sin(2*np.pi*frequency*t),fs,window)
    assert f[np.argmax(a)]==pytest.approx(frequency)
    assert a.max()==pytest.approx(2,rel=1e-10)
    assert a[0]<1e-12


def test_dc_rms_and_population_std():
    t=np.arange(4096)/1024; x=3+2*np.sin(2*np.pi*64*t)
    stats=time_statistics(x)
    assert stats['rms']==pytest.approx(np.sqrt(11))
    assert stats['std']==pytest.approx(np.sqrt(2))
    assert stats['rms']**2==pytest.approx(stats['std']**2+stats['mean']**2)
    f,p=welch_psd(x,1024,nperseg=1024)
    _,rms=band_rms_from_psd(f,p)
    assert rms==pytest.approx(np.sqrt(2),rel=1e-10)


@pytest.mark.parametrize('unit,scale',[('g',1.),('m/s²',9.80665),('mm/s²',9806.65)])
@pytest.mark.parametrize('segment',[256,512,1024])
def test_band_energy_across_units_and_resolution(unit,scale,segment):
    fs=1024; t=np.arange(4096)/fs
    signal=convert_acceleration(9.80665*np.sin(2*np.pi*64*t),'m/s²',unit)
    f,p=welch_psd(signal,fs,nperseg=segment)
    area,rms=band_rms_from_psd(f,p,40,90)
    assert rms==pytest.approx(scale/np.sqrt(2),rel=1e-10)
    assert area==pytest.approx(scale**2/2,rel=1e-10)


def test_partial_bin_integral_uses_interpolated_bounds():
    f=np.arange(11,dtype=float); p=2*f+1; a,b=1.25,8.75
    area,rms=band_rms_from_psd(f,p,a,b)
    expected=(b*b+b)-(a*a+a)
    assert area==pytest.approx(expected)
    assert rms==pytest.approx(np.sqrt(expected))


@pytest.mark.parametrize('low,high',[(-1,5),(5,4),(1,12),(2,2)])
def test_invalid_integral_band_rejected(low,high):
    with pytest.raises(ValueError): band_rms_from_psd(np.arange(11),np.ones(11),low,high)


def test_noise_psd_estimates_variance():
    x=np.random.default_rng(87).normal(size=65536)
    f,p=welch_psd(x,2048,nperseg=1024)
    area,_=band_rms_from_psd(f,p)
    assert area==pytest.approx(np.var(x),rel=.03)


@pytest.mark.parametrize('kind,low,high,pass_hz,reject_hz',[
    ('lowpass',0,128,64,512),('highpass',256,0,512,64),('bandpass',32,128,64,512),
])
def test_filter_retains_passband_and_rejects_outside(kind,low,high,pass_hz,reject_hz):
    fs=2048; t=np.arange(8192)/fs
    y=apply_filter(np.sin(2*np.pi*64*t)+np.sin(2*np.pi*512*t),fs,kind,low,high)
    f,a=fft_spectrum(y,fs)
    assert a[np.argmin(abs(f-pass_hz))]>.9
    assert a[np.argmin(abs(f-reject_hz))]<.02
