import csv
import numpy as np
from vibrationlab.core.export_bundle import export_bundle,export_named_segments
from vibrationlab.core.export_table import prepare_table


def test_rms_and_mean_square_are_independent():
    fs=1024; t=np.arange(fs)/fs; x=np.sin(2*np.pi*64*t)
    rows=export_bundle(None,[x],fs,t,['CH1'],['频段 RMS'],'g',return_rows=True)
    assert len(rows)==1 and rows[0][1]=='频段 RMS'
    rows=export_bundle(None,[x],fs,t,['CH1'],['均方值'],'g',return_rows=True)
    assert len(rows)==1 and rows[0][1]=='均方值'


def test_filtered_wide_csv_matches_preview(tmp_path):
    fs=1024; t=np.arange(fs)/fs; x=9.80665*np.sin(2*np.pi*64*t)
    segments=[dict(name='起飞',start=1,end=2,low=50,high=80,fs=fs,times=t+1,signals=[x,2*x])]
    options=dict(fields=['segment_name','channel','value','unit'],layout='wide')
    headers,rows,meta=export_named_segments(None,segments,['CH1','CH2'],['频段 RMS'],'g',return_table=True)
    preview=prepare_table(headers,rows,meta,options)
    path=tmp_path/'simple.csv'
    export_named_segments(path,segments,['CH1','CH2'],['频段 RMS'],'g',include_metadata=False,output_options=options)
    with path.open(encoding='utf-8-sig') as f: actual=list(csv.reader(f))
    assert actual[0]==preview[0]==['segment_name','unit','CH1 value','CH2 value']
    assert len(actual)==2
    assert np.allclose(list(map(float,actual[1][2:])),[1/np.sqrt(2),2/np.sqrt(2)])
    assert actual[1]==[str(v) for v in preview[1][0]]


def test_hidden_identity_fields_do_not_merge_different_results():
    headers=['segment_name','channel','quantity','value','unit']
    rows=[['A','CH1','频段 RMS',1,'g'],['B','CH1','频段 RMS',2,'g']]
    output=prepare_table(headers,rows,{},dict(fields=['value'],layout='wide'))
    assert output[1]==[[1],[2]]


def test_export_preferences_restore_and_cancel():
    import os
    os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
    from unittest.mock import patch
    from PySide6 import QtWidgets
    from vibrationlab.ui.export_dialog import ExportDialog
    app=QtWidgets.QApplication.instance() or QtWidgets.QApplication([])
    class Store:
        data={}
        def value(self,key,default=''): return self.data.get(key,default)
        def setValue(self,key,value): self.data[key]=value
    store=Store()
    with patch('vibrationlab.ui.export_dialog.QtCore.QSettings',return_value=store):
        first=ExportDialog(['CH1']); first.preset.setCurrentText('工程记录'); first.output_layout.setCurrentIndex(1); first.validate_and_accept()
        restored=ExportDialog(['CH1'])
        assert restored.output_options()==first.output_options()
        assert restored.metadata.isChecked()
        before=dict(store.data); restored.preset.setCurrentText('精简结果'); restored.reject()
        assert store.data==before
