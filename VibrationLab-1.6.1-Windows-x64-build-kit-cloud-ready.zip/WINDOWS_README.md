# VibrationLab 1.6.1 Windows x64（待 Windows 构建）

开发人员：rain。目标使用环境：Windows 10/11，Intel/AMD 64 位电脑。  
本文件随 Windows 构建工具包提供，当前 Mac 环境尚未生成或实测 Windows exe。

## 在 Windows 电脑构建

1. 解压整个构建包到本地文件夹。
2. 安装 Python 3.11 的 Windows 64 位版本，保留 Python Launcher 选项。
3. 双击 BUILD_WINDOWS.cmd，第一次需要联网安装构建依赖。
4. 脚本会建立独立环境，运行测试，打包并执行包内验收，最后生成 Windows 便携 ZIP。
5. 构建结束后打开 outputs 中的 VibrationLab-1.6.1-windows-x64 目录，进入 VibrationLab 文件夹，双击 VibrationLab.exe。

发生错误时，请保留命令窗口信息和 work/build-windows.log，以便排查。  
如输出目录已存在，脚本会停止；请改名保留原输出后重试，不会自动删除旧包。

## 使用

Ctrl 多选通道，Shift 连续选择；菜单固定在软件窗口顶部。  
使用 Windows 文件选择窗口导入 TXT。关于窗口自动显示实际 Windows 版本和架构。  
功能包括 FFT、PSD/ASD、频段 RMS、游标、多通道和命名多分段导出；保留已确认的窗口内菜单方案。

生成软件后，日常运行无需 Python。分发时发送整个生成的便携 ZIP，必须保留 exe 旁边的 \_internal 目录。  
当前为未签名的便携应用，没有制作安装程序；遇到系统安全提示请核对来源，不要关闭系统保护。

## 验收范围

脚本运行源码测试及 exe 内的菜单、参数窗口、导入、频谱和 RMS 检查。  
随后仍须在 Windows 桌面检查：六个菜单可点击，中文路径 TXT 导入，Ctrl 多选，单位换算，图像及 CSV 导出，100%/150%/200% 显示缩放。  
Windows 10 和 11 的兼容性需分别在相应系统中实际验证。

## 离线使用

构建成功后，将 outputs/VibrationLab-1.6.1-windows-x64.zip 复制到不联网的目标电脑。
完整解压后打开 VibrationLab/VibrationLab.exe，无需安装 Python、pip 或联网下载依赖。
不能只复制 EXE，也不能直接在 ZIP 内运行。构建电脑需联网，日常使用电脑无需联网。
请在目标电脑断网验证启动、导入、RMS、CSV、批量图片 PNG/PDF/SVG。
已保存时间段关联原始数据的绝对路径，跨电脑请重新关联目标文件的时间段。

## 只有 Mac 时的云端构建

资料包含 .github/workflows/windows-portable.yml，只手动触发，不自动发布。
经源码所有者同意后，将构建资料上传到 GitHub 仓库，在 Actions 手动运行
“Build Windows offline portable package”。成功后下载 VibrationLab-Windows-x64-offline 构建产物，
解开外层 ZIP，其中包含完整软件便携 ZIP。失败时下载 Windows-build-diagnostics 日志。

当前仅准备资料，没有上传源码或执行云端构建，也没有生成或验证 Windows EXE。
云端检查不能代替实际 Windows 10/11 目标电脑的离线验收。
